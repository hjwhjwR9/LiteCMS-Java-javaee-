import os
files = {}

files[r'D:\360安全浏览器下载\vite-project\vite-project\src\views\ArticleDetail.vue'] = r'''<template>
  <div class="article-detail-container">
    <el-card class="mb-6">
      <h1 class="article-title text-2xl font-bold mb-4">{{ article.title }}</h1>
      <div class="article-meta text-gray-500 mb-4">
        <span>栏目：{{ article.categoryName }}</span>
        <span class="mx-3">|</span>
        <span>作者：{{ article.authorNickname }}</span>
        <span class="mx-3">|</span>
        <span>发布时间：{{ formatTime(article.publishedAt) }}</span>
        <span class="mx-3">|</span>
        <span>浏览：{{ article.viewCount }}</span>
        <span class="mx-3">|</span>
        <span>点赞：{{ article.likeCount }}</span>
        <span class="mx-3">|</span>
        <span>评论：{{ article.commentCount }}</span>
      </div>
      <img
        v-if="article.coverUrl"
        :src="article.coverUrl"
        class="article-cover mb-4"
        alt="文章封面"
      />
      <div class="article-content" v-html="article.content"></div>
      <el-button
        type="primary"
        icon="Heart"
        @click="handleLike"
        class="mt-4"
        :disabled="isLiked"
      >
        {{ isLiked ? "已点赞" : "点赞" }}
      </el-button>
    </el-card>

    <CommentList :article-id="article.id" />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import axios from '../utils/axios'
import CommentList from '../components/CommentList.vue'

const route = useRoute()
const articleId = route.params.id
const article = ref({})
const isLiked = ref(false)

const getArticleDetail = async () => {
  const data = await axios.get('/article/' + articleId)
  article.value = data || {}
  const liked = await axios.get('/article/checkLike', { params: { articleId } })
  isLiked.value = !!liked
}

const handleLike = async () => {
  await axios.post('/article/like?articleId=' + articleId)
  article.value.likeCount = (article.value.likeCount || 0) + 1
  isLiked.value = true
  ElMessage.success('点赞成功')
}

const formatTime = (time) => {
  if (!time) return '暂无'
  return new Date(time).toLocaleString()
}

onMounted(async () => {
  await getArticleDetail()
})
</script>

<style scoped>
.article-detail-container {
  max-width: 1200px;
  margin: 2rem auto;
  padding: 0 1rem;
}
.article-cover {
  width: 100%;
  max-height: 400px;
  object-fit: cover;
}
.article-content {
  line-height: 2;
  font-size: 16px;
}
.article-content img {
  max-width: 100%;
  margin: 1rem 0;
}
</style>
'''

for path, content in files.items():
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print('OK:', path)
