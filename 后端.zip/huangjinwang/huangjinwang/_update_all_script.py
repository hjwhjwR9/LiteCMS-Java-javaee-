import os

BASE = r'D:\360安全浏览器下载\vite-project\vite-project\src'

files = {}

# ===== ArticleEdit.vue =====
files[r'%s\views\ArticleEdit.vue' % BASE] = r'''<template>
  <div class="article-edit-page">
    <el-card>
      <h2 class="mb-4">文章编辑</h2>
      <el-form :model="articleForm" :rules="rules" ref="formRef" label-width="80px">
        <el-form-item label="所属栏目" prop="categoryId">
          <el-select v-model="articleForm.categoryId" placeholder="请选择栏目">
            <el-option
              v-for="item in categories"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="文章标题" prop="title">
          <el-input v-model="articleForm.title" placeholder="请输入标题" />
        </el-form-item>

        <el-form-item label="文章摘要">
          <el-input v-model="articleForm.summary" placeholder="请输入摘要" type="textarea" rows="3" />
        </el-form-item>

        <el-form-item label="封面图">
          <el-input v-model="articleForm.coverUrl" placeholder="请输入封面图片URL" />
        </el-form-item>

        <el-form-item label="文章内容" prop="content">
          <el-input
            v-model="articleForm.content"
            type="textarea"
            :rows="12"
            placeholder="请输入文章内容"
          />
        </el-form-item>

        <el-form-item label="发布状态">
          <el-radio-group v-model="articleForm.status">
            <el-radio label="0">草稿</el-radio>
            <el-radio label="1">提交审核</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="handleSubmit">保存</el-button>
          <el-button @click="router.back()">取消</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted, getCurrentInstance } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'

const { proxy } = getCurrentInstance()
const router = useRouter()
const route = useRoute()
const formRef = ref(null)
const articleId = route.params.id

const categories = ref([])
const articleForm = ref({
  id: null,
  categoryId: '',
  title: '',
  summary: '',
  coverUrl: '',
  content: '',
  status: '0'
})
const rules = {
  categoryId: [{ required: true, message: '请选择栏目', trigger: 'blur' }],
  title: [{ required: true, message: '请输入标题', trigger: 'blur' }],
  content: [{ required: true, message: '请输入内容', trigger: 'blur' }]
}

onMounted(async () => {
  const cateData = await proxy.$axios.get('/category/list')
  categories.value = cateData || []

  if (articleId) {
    const data = await proxy.$axios.get('/article/' + articleId)
    if (data) {
      articleForm.value = {
        id: data.id,
        categoryId: data.categoryId,
        title: data.title,
        summary: data.summary || '',
        coverUrl: data.coverUrl || '',
        content: data.content || '',
        status: String(data.status ?? '0')
      }
    }
  }
})

const handleSubmit = async () => {
  await formRef.value.validate()
  try {
    if (articleId) {
      await proxy.$axios.put('/article', articleForm.value)
      ElMessage.success('编辑成功')
    } else {
      await proxy.$axios.post('/article', articleForm.value)
      ElMessage.success('创建成功')
    }
    router.push('/article/manage')
  } catch (err) {
    // 错误由拦截器处理
  }
}
</script>

<style scoped>
.article-edit-page {
  padding: 1rem;
}
</style>
'''

# ===== ArticleManage.vue =====
files[r'%s\views\ArticleManage.vue' % BASE] = r'''<template>
  <el-card class="article-manage-container">
    <div class="flex justify-between mb-4">
      <h3>我的文章</h3>
      <el-button type="primary" @click="toAdd">新增文章</el-button>
    </div>
    <el-table :data="articleList" border>
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column prop="title" label="文章标题" min-width="200" />
      <el-table-column
        prop="categoryId"
        label="所属栏目"
        width="120"
        :formatter="formatCategory"
      />
      <el-table-column
        prop="status"
        label="状态"
        width="100"
        :formatter="formatStatus"
      />
      <el-table-column prop="viewCount" label="浏览量" width="80" />
      <el-table-column prop="createdAt" label="创建时间" width="160" />
      <el-table-column label="操作" width="160">
        <template #default="scope">
          <el-button size="small" @click="toEdit(scope.row.id)">编辑</el-button>
          <el-button size="small" type="danger" @click="deleteArticle(scope.row.id)" class="ml-1">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      @current-change="changePage"
      :current-page="currentPage"
      :page-size="pageSize"
      :total="total"
      layout="prev, pager, next, jumper"
      class="mt-4 text-center"
    />
  </el-card>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import axios from '../utils/axios'

const router = useRouter()
const articleList = ref([])
const categories = ref([])
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)

const getMyArticles = async () => {
  const data = await axios.get('/article/my', {
    params: { pageNum: currentPage.value, pageSize: pageSize.value }
  })
  const result = data || {}
  articleList.value = result.records || []
  total.value = result.total || 0
}

const getCategories = async () => {
  const data = await axios.get('/category/list')
  categories.value = data || []
}

const flatten = (list) => {
  const result = []
  const walk = (items) => {
    for (const item of items || []) {
      result.push(item)
      if (item.children && item.children.length) walk(item.children)
    }
  }
  walk(list)
  return result
}

const formatCategory = (row) => {
  const flat = flatten(categories.value)
  const cat = flat.find(item => item.id === row.categoryId)
  return cat ? cat.name : '未知'
}

const formatStatus = (row) => {
  const statusMap = { 0: '草稿', 1: '待审核', 2: '已发布', 3: '已驳回', 4: '已下架' }
  return statusMap[row.status] || '未知'
}

const toAdd = () => {
  router.push('/article/edit')
}

const toEdit = (id) => {
  router.push(`/article/edit/${id}`)
}

const deleteArticle = async (id) => {
  try {
    await ElMessageBox.confirm('确定要删除这篇文章吗？', '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await axios.delete('/article/' + id)
    ElMessage.success('删除成功')
    getMyArticles()
  } catch (err) {
    // 取消操作或请求失败由拦截器处理
  }
}

const changePage = (page) => {
  currentPage.value = page
  getMyArticles()
}

onMounted(async () => {
  await getCategories()
  await getMyArticles()
})
</script>

<style scoped>
.article-manage-container {
  max-width: 1200px;
  margin: 2rem auto;
  padding: 0 1rem;
}
</style>
'''

# ===== CategoryManage.vue =====
files[r'%s\views\CategoryManage.vue' % BASE] = r'''<template>
  <el-card class="category-manage-container">
    <div class="flex justify-between mb-4">
      <h3>栏目管理</h3>
      <el-button type="primary" @click="openDialog">新增栏目</el-button>
    </div>
    <el-tree
      :data="categoryTree"
      :props="treeProps"
      node-key="id"
      default-expand-all
      class="category-tree"
    >
      <template #default="{ node, data }">
        <span class="tree-node">
          <span>{{ data.name }}</span>
          <span class="node-actions ml-4">
            <el-button size="small" @click.stop="editCategory(data)">编辑</el-button>
            <el-button size="small" type="danger" @click.stop="deleteCategory(data.id)">删除</el-button>
          </span>
        </span>
      </template>
    </el-tree>

    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="categoryForm" :rules="formRules" ref="formRef" label-width="80px">
        <el-form-item label="栏目名称" prop="name">
          <el-input v-model="categoryForm.name" />
        </el-form-item>
        <el-form-item label="父栏目" prop="parentId">
          <el-select v-model="categoryForm.parentId" placeholder="选择父栏目" clearable>
            <el-option label="无（一级栏目）" value="" />
            <el-option
              v-for="cat in allCategories"
              :key="cat.id"
              :label="cat.name"
              :value="cat.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="排序" prop="sortOrder">
          <el-input v-model.number="categoryForm.sortOrder" placeholder="越小越靠前" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveCategory">确定</el-button>
      </template>
    </el-dialog>
  </el-card>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import axios from '../utils/axios'

const allCategories = ref([])
const categoryTree = ref([])
const dialogVisible = ref(false)
const dialogTitle = ref('新增栏目')
const formRef = ref(null)
const categoryForm = ref({ id: null, name: '', parentId: '', sortOrder: 0 })
const treeProps = { children: 'children', label: 'name' }
const formRules = {
  name: [{ required: true, message: '请输入栏目名称', trigger: 'blur' }],
  sortOrder: [{ required: true, message: '请输入排序值', trigger: 'blur' }]
}

const getCategories = async () => {
  const data = await axios.get('/category/list')
  const list = data || []
  allCategories.value = flatten(list)
  categoryTree.value = list
}

const flatten = (list) => {
  const result = []
  const walk = (items) => {
    for (const item of items || []) {
      result.push(item)
      if (item.children && item.children.length) walk(item.children)
    }
  }
  walk(list)
  return result
}

const openDialog = () => {
  categoryForm.value = { id: null, name: '', parentId: '', sortOrder: 0 }
  dialogTitle.value = '新增栏目'
  dialogVisible.value = true
}

const editCategory = (data) => {
  categoryForm.value = {
    id: data.id,
    name: data.name,
    parentId: data.parentId || '',
    sortOrder: data.sortOrder ?? 0
  }
  dialogTitle.value = '编辑栏目'
  dialogVisible.value = true
}

const saveCategory = async () => {
  await formRef.value.validate()
  try {
    if (categoryForm.value.id) {
      await axios.put('/category/update', categoryForm.value)
      ElMessage.success('编辑成功')
    } else {
      await axios.post('/category/add', categoryForm.value)
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    getCategories()
  } catch (err) {
    // 错误由拦截器处理
  }
}

const deleteCategory = async (id) => {
  try {
    await ElMessageBox.confirm('确定删除该栏目吗？子栏目也会被删除', '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await axios.delete('/category/' + id)
    ElMessage.success('删除成功')
    getCategories()
  } catch (err) {
    // 取消操作或请求失败由拦截器处理
  }
}

onMounted(async () => {
  await getCategories()
})
</script>

<style scoped>
.category-manage-container {
  max-width: 800px;
  margin: 2rem auto;
  padding: 0 1rem;
}
.category-tree {
  border: 1px solid #eee;
  border-radius: 4px;
  padding: 1rem;
}
.tree-node {
  display: flex;
  align-items: center;
  width: 100%;
}
.node-actions {
  margin-left: auto;
}
</style>
'''

# ===== CommentManage.vue =====
files[r'%s\views\CommentManage.vue' % BASE] = r'''<template>
  <el-card class="comment-manage-container">
    <h3 class="mb-4">评论管理</h3>
    <el-table :data="commentList" border>
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column
        prop="articleId"
        label="所属文章"
        width="200"
        :formatter="formatArticle"
      />
      <el-table-column prop="userNickname" label="评论用户" width="120" />
      <el-table-column prop="content" label="评论内容" min-width="300" />
      <el-table-column
        prop="status"
        label="状态"
        width="100"
        :formatter="formatStatus"
      />
      <el-table-column prop="createdAt" label="评论时间" width="160" />
      <el-table-column label="操作" width="200">
        <template #default="scope">
          <el-button
            size="small"
            type="success"
            @click="updateStatus(scope.row.id, 1)"
            v-if="scope.row.status === 0"
          >
            通过
          </el-button>
          <el-button
            size="small"
            type="danger"
            @click="updateStatus(scope.row.id, 2)"
            v-if="scope.row.status === 0"
          >
            驳回
          </el-button>
          <el-button
            size="small"
            type="danger"
            @click="deleteComment(scope.row.id)"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import axios from '../utils/axios'

const commentList = ref([])
const articles = ref([])

const getComments = async () => {
  const data = await axios.get('/comment/all')
  commentList.value = data || []
}

const getArticles = async () => {
  const data = await axios.get('/article/list', {
    params: { pageNum: 1, pageSize: 100 }
  })
  const result = data || {}
  articles.value = result.records || []
}

const formatArticle = (row) => {
  const article = articles.value.find(item => item.id === row.articleId)
  return article ? article.title : '未知文章'
}

const formatStatus = (row) => {
  const statusMap = { 0: '待审核', 1: '已通过', 2: '已驳回', 3: '已删除' }
  return statusMap[row.status] || '未知'
}

const updateStatus = async (id, status) => {
  await axios.put('/comment/status', { id, status })
  ElMessage.success('操作成功')
  getComments()
}

const deleteComment = async (id) => {
  try {
    await ElMessageBox.confirm('确定删除该评论吗？', '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await axios.delete('/comment/' + id)
    ElMessage.success('删除成功')
    getComments()
  } catch (err) {
    // 错误由拦截器处理
  }
}

onMounted(async () => {
  await getArticles()
  await getComments()
})
</script>

<style scoped>
.comment-manage-container {
  max-width: 1200px;
  margin: 2rem auto;
  padding: 0 1rem;
}
</style>
'''

# ===== ReviewArticle.vue =====
files[r'%s\views\ReviewArticle.vue' % BASE] = r'''<template>
  <div class="review-container">
    <el-row :gutter="16" class="stat-cards">
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-icon pending"><el-icon><Clock /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.pending }}</div>
            <div class="stat-label">待审核</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-icon approved"><el-icon><CircleCheck /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.approved }}</div>
            <div class="stat-label">已通过</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-icon rejected"><el-icon><CircleClose /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.rejected }}</div>
            <div class="stat-label">已驳回</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-icon total"><el-icon><Document /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.total }}</div>
            <div class="stat-label">总记录</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-card class="mt-4">
      <template #header>
        <div class="card-header">
          <span class="title">文章审核</span>
          <div class="header-actions">
            <el-select v-model="filterType" placeholder="审核状态" clearable style="width: 120px; margin-right: 12px">
              <el-option label="全部" value="" />
              <el-option label="待审核" :value="0" />
              <el-option label="已通过" :value="2" />
              <el-option label="已驳回" :value="3" />
            </el-select>
            <el-button @click="handleBatchApprove" type="success" :disabled="selectedRows.length === 0">批量通过</el-button>
            <el-button @click="handleBatchReject" type="danger" :disabled="selectedRows.length === 0">批量驳回</el-button>
          </div>
        </div>
      </template>

      <el-table :data="articleList" v-loading="loading" @selection-change="handleSelectionChange" stripe>
        <el-table-column type="selection" width="50" />
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column label="封面" width="100">
          <template #default="{ row }">
            <el-image :src="row.coverUrl" fit="cover" style="width: 80px; height: 50px; border-radius: 4px" />
          </template>
        </el-table-column>
        <el-table-column prop="title" label="文章标题" min-width="200" show-overflow-tooltip />
        <el-table-column prop="authorNickname" label="作者" width="100" />
        <el-table-column prop="categoryName" label="栏目" width="120" />
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">{{ getStatusText(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="submittedAt" label="提交时间" width="160">
          <template #default="{ row }">
            {{ formatTime(row.submittedAt) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="240" fixed="right">
          <template #default="{ row }">
            <el-button size="small" type="primary" @click="handleView(row)">查看</el-button>
            <el-button size="small" type="success" @click="handleApprove(row)" v-if="row.status === 0 || row.status === 1">通过</el-button>
            <el-button size="small" type="danger" @click="handleReject(row)" v-if="row.status === 0 || row.status === 1">驳回</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>

    <el-dialog v-model="detailDialogVisible" title="文章详情" width="800px">
      <div v-if="currentArticle" class="article-detail">
        <h2 class="detail-title">{{ currentArticle.title }}</h2>
        <div class="detail-meta">
          <span>作者：{{ currentArticle.authorNickname }}</span>
          <span>栏目：{{ currentArticle.categoryName }}</span>
          <span>提交时间：{{ formatTime(currentArticle.submittedAt) }}</span>
        </div>
        <el-image v-if="currentArticle.coverUrl" :src="currentArticle.coverUrl" class="detail-cover" />
        <div class="detail-content" v-html="currentArticle.content"></div>
      </div>
      <template #footer>
        <el-button @click="detailDialogVisible = false">关闭</el-button>
        <el-button type="success" @click="handleApproveFromDetail" v-if="currentArticle && (currentArticle.status === 0 || currentArticle.status === 1)">通过</el-button>
        <el-button type="danger" @click="handleRejectFromDetail" v-if="currentArticle && (currentArticle.status === 0 || currentArticle.status === 1)">驳回</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="rejectDialogVisible" title="驳回原因" width="500px">
      <el-form :model="rejectForm" label-width="80px">
        <el-form-item label="驳回原因">
          <el-input v-model="rejectForm.reason" type="textarea" :rows="4" placeholder="请输入驳回原因（可选）" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="rejectDialogVisible = false">取消</el-button>
        <el-button type="danger" @click="confirmReject">确认驳回</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import axios from '../utils/axios'

const stats = ref({ pending: 0, approved: 0, rejected: 0, total: 0 })
const loading = ref(false)
const articleList = ref([])
const filterType = ref('')
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)

const selectedRows = ref([])

const detailDialogVisible = ref(false)
const currentArticle = ref(null)

const rejectDialogVisible = ref(false)
const rejectForm = ref({ reason: '', id: null })

const statusMap = { 0: '待审核', 1: '待审核', 2: '已通过', 3: '已驳回', 4: '已下架' }
const statusTypeMap = { 0: 'warning', 1: 'warning', 2: 'success', 3: 'danger', 4: 'info' }

const getStatusText = (status) => statusMap[status] || '未知'
const getStatusType = (status) => statusTypeMap[status] || 'info'

const formatTime = (time) => {
  if (!time) return '-'
  const d = new Date(time)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  const hh = String(d.getHours()).padStart(2, '0')
  const mm = String(d.getMinutes()).padStart(2, '0')
  return `${y}-${m}-${day} ${hh}:${mm}`
}

const getArticleList = async () => {
  loading.value = true
  try {
    const params = { pageNum: currentPage.value, pageSize: pageSize.value }
    if (filterType.value !== '' && filterType.value !== null) {
      params.status = filterType.value
    }
    const data = await axios.get('/review/article', { params })
    const result = data || {}
    articleList.value = result.records || []
    total.value = result.total || 0

    let pending = 0, approved = 0, rejected = 0
    articleList.value.forEach(a => {
      if (a.status === 0 || a.status === 1) pending++
      else if (a.status === 2) approved++
      else if (a.status === 3) rejected++
    })
    stats.value = {
      pending,
      approved,
      rejected,
      total: total.value
    }
  } catch (err) {
    console.error('获取审核列表失败:', err)
  } finally {
    loading.value = false
  }
}

const handleSelectionChange = (rows) => {
  selectedRows.value = rows
}

const handlePageChange = (page) => {
  currentPage.value = page
  getArticleList()
}

const handleSizeChange = (size) => {
  pageSize.value = size
  getArticleList()
}

const handleView = (row) => {
  currentArticle.value = row
  detailDialogVisible.value = true
}

const handleApprove = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要通过文章《${row.title}》吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'success'
    })
    await axios.put('/review/article/' + row.id + '/approve')
    ElMessage.success('审核通过')
    getArticleList()
  } catch (err) {
    // 取消或错误由拦截器处理
  }
}

const handleApproveFromDetail = async () => {
  await handleApprove(currentArticle.value)
  detailDialogVisible.value = false
}

const handleReject = (row) => {
  rejectForm.value.id = row.id
  rejectForm.value.reason = ''
  rejectDialogVisible.value = true
}

const handleRejectFromDetail = () => {
  rejectForm.value.id = currentArticle.value.id
  rejectDialogVisible.value = true
  detailDialogVisible.value = false
}

const confirmReject = async () => {
  try {
    await axios.put('/review/article/' + rejectForm.value.id + '/reject', { reason: rejectForm.value.reason })
    ElMessage.success('已驳回')
    rejectDialogVisible.value = false
    getArticleList()
  } catch (err) {
    // 错误由拦截器处理
  }
}

const handleBatchApprove = async () => {
  if (selectedRows.value.length === 0) return
  try {
    await ElMessageBox.confirm(`确定要通过选中的 ${selectedRows.value.length} 篇文章吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'success'
    })
    await axios.post('/review/article/batch-approve', { ids: selectedRows.value.map(r => r.id) })
    ElMessage.success('批量通过成功')
    getArticleList()
  } catch (err) {
    // 取消或错误由拦截器处理
  }
}

const handleBatchReject = async () => {
  if (selectedRows.value.length === 0) return
  try {
    await ElMessageBox.confirm(`确定要驳回选中的 ${selectedRows.value.length} 篇文章吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await axios.post('/review/article/batch-reject', { ids: selectedRows.value.map(r => r.id) })
    ElMessage.success('批量驳回成功')
    getArticleList()
  } catch (err) {
    // 取消或错误由拦截器处理
  }
}

onMounted(async () => {
  await getArticleList()
})
</script>

<style scoped>
.review-container {
  padding: 0;
}
.stat-cards {
  margin-bottom: 16px;
}
.stat-card {
  display: flex;
  align-items: center;
  padding: 16px;
}
.stat-icon {
  width: 60px;
  height: 60px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  margin-right: 16px;
}
.stat-icon.pending { background-color: #fdf6ec; color: #e6a23c; }
.stat-icon.approved { background-color: #f0f9eb; color: #67c23a; }
.stat-icon.rejected { background-color: #fef0f0; color: #f56c6c; }
.stat-icon.total { background-color: #ecf5ff; color: #409eff; }
.stat-info { flex: 1; }
.stat-value { font-size: 28px; font-weight: bold; color: #303133; }
.stat-label { font-size: 14px; color: #909399; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
.title { font-size: 16px; font-weight: 600; }
.header-actions { display: flex; align-items: center; }
.pagination-wrapper { margin-top: 20px; display: flex; justify-content: flex-end; }
.mt-4 { margin-top: 16px; }
.article-detail { max-height: 60vh; overflow-y: auto; }
.detail-title { font-size: 20px; font-weight: 600; margin-bottom: 16px; }
.detail-meta { display: flex; gap: 24px; color: #909399; font-size: 14px; margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid #eee; }
.detail-cover { width: 100%; max-height: 300px; object-fit: cover; border-radius: 8px; margin-bottom: 16px; }
.detail-content { line-height: 2; font-size: 15px; }
</style>
'''

# ===== CommentList.vue =====
files[r'%s\components\CommentList.vue' % BASE] = r'''<template>
  <div class="comment-container">
    <h3 class="mb-4">评论区</h3>
    <el-card class="mb-4" v-if="isLogin">
      <el-input
        v-model="commentContent"
        type="textarea"
        rows="3"
        placeholder="请输入评论..."
        maxlength="1000"
        class="mb-2"
      />
      <el-button
        type="primary"
        @click="submitComment"
        :disabled="!commentContent.trim()"
      >
        提交评论
      </el-button>
    </el-card>

    <div class="comment-item" v-for="comment in topComments" :key="comment.id">
      <div class="comment-header">
        <img :src="comment.userAvatar || 'https://placehold.co/40x40'" class="avatar" alt="头像" />
        <span class="nickname ml-2">{{ comment.userNickname }}</span>
        <span class="time ml-4 text-gray-500">{{ formatTime(comment.createdAt) }}</span>
      </div>
      <div class="comment-content mt-2">{{ comment.content }}</div>
      <div class="comment-action mt-2">
        <span @click="replyComment(comment.id)" class="text-primary cursor-pointer">回复</span>
      </div>

      <div class="sub-comment-list mt-3" v-if="comment.subComments.length">
        <div class="sub-comment" v-for="sub in comment.subComments" :key="sub.id">
          <div class="sub-comment-header">
            <span class="sub-nickname">{{ sub.userNickname }}</span>
            <span class="sub-time ml-2 text-gray-500">{{ formatTime(sub.createdAt) }}</span>
          </div>
          <div class="sub-comment-content">{{ sub.content }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { ElMessage } from 'element-plus'
import axios from '../utils/axios'

const props = defineProps({
  articleId: { type: Number, required: true }
})

const commentContent = ref('')
const allComments = ref([])
const isLogin = ref(!!localStorage.getItem('token'))

const getComments = async () => {
  const data = await axios.get('/comment/list', {
    params: { articleId: props.articleId }
  })
  allComments.value = data || []
}

const topComments = computed(() => {
  const tops = (allComments.value || [])
    .filter(item => !item.parentId)
    .map(item => ({ ...item, subComments: [] }))
  const parentMap = {}
  tops.forEach(item => parentMap[item.id] = item)
  ;(allComments.value || []).forEach(item => {
    if (item.parentId && parentMap[item.parentId]) {
      parentMap[item.parentId].subComments.push(item)
    }
  })
  return tops
})

const submitComment = async () => {
  await axios.post('/comment/add', {
    articleId: props.articleId,
    content: commentContent.value,
    parentId: null
  })
  commentContent.value = ''
  ElMessage.success('评论提交成功，待审核')
  getComments()
}

const replyComment = (parentId) => {
  ElMessage.info('回复功能待实现')
}

const formatTime = (time) => {
  if (!time) return '暂无'
  return new Date(time).toLocaleString()
}

onMounted(async () => {
  await getComments()
})
</script>

<style scoped>
.comment-container {
  max-width: 1200px;
  margin: 0 auto;
}
.comment-item {
  padding: 1rem 0;
  border-bottom: 1px solid #eee;
}
.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
}
.sub-comment-list {
  margin-left: 2rem;
  padding-left: 1rem;
  border-left: 2px solid #eee;
}
.sub-comment {
  padding: 0.5rem 0;
}
</style>
'''

for path, content in files.items():
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print('OK:', path)
