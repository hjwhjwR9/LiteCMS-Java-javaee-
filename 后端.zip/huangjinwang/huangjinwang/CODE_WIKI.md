# CMS内容管理系统 Code Wiki

## 1. 项目概述

- **项目名称**: cms-content
- **项目版本**: 0.0.1-SNAPSHOT
- **项目描述**: 仅使用MySQL数据库的CMS文章管理系统
- **Java版本**: 17
- **构建工具**: Maven

## 2. 技术栈

| 技术 | 版本 | 说明 |
|------|------|------|
| Spring Boot | 3.2.5 | 核心框架 |
| MyBatis-Plus | 3.5.8 | ORM框架 |
| MySQL | - | 唯一数据库 |
| JWT | 0.11.5 | 身份认证 |
| Knife4j | 4.3.0 | 接口文档 |
| Hutool | 5.8.27 | 工具库 |
| Lombok | - | 注解生成 |

## 3. 项目架构

```
com.cms
├── CmsApplication.java          # 启动类
├── common/                       # 公共模块
│   ├── config/                   # 配置类
│   │   ├── CorsConfig.java       # 跨域配置
│   │   ├── Knife4jConfig.java    # Knife4j文档配置
│   │   ├── MyBatisPlusConfig.java # MyBatis-Plus分页配置
│   │   └── WebConfig.java        # Web配置（拦截器）
│   ├── constant/                 # 常量
│   │   ├── CmsConstant.java     # 业务常量
│   │   └── ResultCode.java       # 响应码常量
│   ├── exception/                # 异常处理
│   │   ├── BusinessException.java    # 业务异常
│   │   └── GlobalExceptionHandler.java # 全局异常处理
│   ├── interceptor/              # 拦截器
│   │   └── JwtInterceptor.java   # JWT认证拦截器
│   ├── result/                   # 响应结果
│   │   ├── PageResult.java       # 分页结果
│   │   └── Result.java           # 统一响应格式
│   └── util/                     # 工具类
│       ├── JwtUtil.java         # JWT工具类
│       ├── LoginUserUtil.java   # 登录用户工具类
│       └── PasswordUtil.java     # 密码加密工具类
├── controller/                   # 控制器层
│   └── UserController.java      # 用户控制器
├── dto/                          # 数据传输对象
│   └── user/
│       ├── UserLoginDTO.java    # 登录参数
│       ├── UserQueryDTO.java    # 查询参数
│       └── UserSaveDTO.java     # 保存/编辑参数
├── entity/                       # 实体类
│   ├── CmsArticle.java          # 文章实体
│   ├── CmsArticleAuditRecord.java # 文章审核记录实体
│   ├── CmsArticleLike.java       # 文章点赞实体
│   ├── CmsCategory.java         # 栏目实体
│   ├── CmsComment.java          # 评论实体
│   └── CmsUser.java             # 用户实体
├── mapper/                       # 数据访问层
│   ├── CmsArticleAuditRecordMapper.java
│   ├── CmsArticleLikeMapper.java
│   ├── CmsArticleMapper.java
│   ├── CmsCategoryMapper.java
│   ├── CmsCommentMapper.java
│   └── CmsUserMapper.java
├── service/                      # 服务层
│   ├── CmsUserService.java      # 用户服务接口
│   └── impl/
│       └── CmsUserServiceImpl.java # 用户服务实现
└── vo/                           # 视图对象
    └── user/
        └── UserVO.java          # 用户返回数据
```

## 4. 模块职责

### 4.1 控制器层 (Controller)

#### UserController
- **路径**: `/api/user`
- **模块**: 用户模块
- **接口**:
  - `POST /api/user/login` - 用户登录

### 4.2 服务层 (Service)

#### CmsUserService
| 方法 | 说明 |
|------|------|
| `login(UserLoginDTO)` | 用户登录验证 |
| `updateLoginTime(Long userId)` | 更新登录时间 |
| `pageList(UserQueryDTO)` | 分页查询用户列表 |

#### CmsUserServiceImpl
- 继承 `ServiceImpl<CmsUserMapper, CmsUser>`
- 实现 `CmsUserService` 接口
- 使用LambdaQueryWrapper进行条件查询
- 使用密码工具类进行BCrypt密码校验

### 4.3 数据访问层 (Mapper)

所有Mapper继承 `BaseMapper<T>`，使用MyBatis-Plus提供的通用CRUD方法。

| Mapper | 实体 | 说明 |
|--------|------|------|
| CmsUserMapper | CmsUser | 用户数据访问 |
| CmsArticleMapper | CmsArticle | 文章数据访问 |
| CmsCategoryMapper | CmsCategory | 栏目数据访问 |
| CmsCommentMapper | CmsComment | 评论数据访问 |
| CmsArticleLikeMapper | CmsArticleLike | 点赞数据访问 |
| CmsArticleAuditRecordMapper | CmsArticleAuditRecord | 审核记录数据访问 |

### 4.4 公共模块 (Common)

#### 配置类
- **CorsConfig**: 配置跨域资源共享，允许所有来源的GET/POST/PUT/DELETE请求
- **WebConfig**: 配置JWT拦截器，放行登录接口和文档资源
- **MyBatisPlusConfig**: 配置MyBatis-Plus分页插件
- **Knife4jConfig**: 配置Knife4j OpenAPI文档

#### 工具类
- **JwtUtil**: JWT令牌生成与验证
- **PasswordUtil**: BCrypt密码加密与校验
- **LoginUserUtil**: 获取当前登录用户信息

#### 异常处理
- **BusinessException**: 业务异常，可指定错误码和消息
- **GlobalExceptionHandler**: 全局异常处理器，统一返回Result格式

## 5. 实体类说明

### CmsUser (用户)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 主键自增 |
| username | String | 用户账号 |
| passwordHash | String | 密码哈希(BCrypt) |
| nickname | String | 昵称 |
| phone | String | 手机号 |
| email | String | 邮箱 |
| avatarUrl | String | 头像URL |
| role | Integer | 角色(0普通/1管理员/2审核员) |
| status | Integer | 状态(0禁用/1正常) |
| lastLoginAt | LocalDateTime | 最后登录时间 |
| createdAt | LocalDateTime | 创建时间 |
| updatedAt | LocalDateTime | 更新时间 |

### CmsArticle (文章)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 主键自增 |
| categoryId | Long | 栏目ID |
| authorId | Long | 作者ID |
| title | String | 标题 |
| summary | String | 摘要 |
| coverUrl | String | 封面图URL |
| content | String | 正文内容 |
| status | Integer | 状态(0草稿/1待审核/2已发布/3已驳回/4已下线) |
| viewCount | Long | 浏览数 |
| likeCount | Long | 点赞数 |
| commentCount | Long | 评论数 |
| submittedAt | LocalDateTime | 提交时间 |
| publishedAt | LocalDateTime | 发布时间 |
| offlineAt | LocalDateTime | 下线时间 |
| createdAt | LocalDateTime | 创建时间 |
| updatedAt | LocalDateTime | 更新时间 |

### CmsCategory (栏目)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 主键自增 |
| parentId | Long | 父栏目ID |
| name | String | 栏目名称 |
| sortOrder | Integer | 排序 |
| status | Integer | 状态 |
| createdAt | LocalDateTime | 创建时间 |
| updatedAt | LocalDateTime | 更新时间 |

### CmsComment (评论)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 主键自增 |
| articleId | Long | 文章ID |
| userId | Long | 用户ID |
| parentId | Long | 父评论ID(回复) |
| content | String | 评论内容 |
| status | Integer | 状态(0待审核/1通过/2驳回/3删除) |
| createdAt | LocalDateTime | 创建时间 |
| updatedAt | LocalDateTime | 更新时间 |

### CmsArticleLike (文章点赞)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 主键自增 |
| articleId | Long | 文章ID |
| userId | Long | 用户ID |
| createdAt | LocalDateTime | 点赞时间 |

### CmsArticleAuditRecord (文章审核记录)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 主键自增 |
| articleId | Long | 文章ID |
| auditorId | Long | 审核员ID |
| auditResult | Integer | 审核结果(1通过/2驳回) |
| auditRemark | String | 审核备注 |
| createdAt | LocalDateTime | 审核时间 |

## 6. 常量定义

### CmsConstant
```java
// 用户角色
USER_ROLE_NORMAL = 0    // 普通用户
USER_ROLE_ADMIN = 1    // 管理员
USER_ROLE_AUDIT = 2    // 审核员

// 用户状态
USER_STATUS_DISABLE = 0  // 禁用
USER_STATUS_NORMAL = 1   // 正常

// 文章状态
ARTICLE_DRAFT = 0        // 草稿
ARTICLE_WAIT_AUDIT = 1   // 待审核
ARTICLE_PUBLISH = 2      // 已发布
ARTICLE_REJECT = 3       // 已驳回
ARTICLE_OFFLINE = 4      // 已下线

// 审核结果
AUDIT_PASS = 1          // 通过
AUDIT_REJECT = 2        // 驳回

// 评论状态
COMMENT_WAIT = 0        // 待审核
COMMENT_PASS = 1        // 通过
COMMENT_REJECT = 2      // 驳回
COMMENT_DELETE = 3      // 删除
```

### ResultCode
```java
SUCCESS = 200           // 成功
UNAUTHORIZED = 401      // 未授权
FORBIDDEN = 403         // 禁止访问
PARAM_ERROR = 400       // 参数错误
BUSINESS_ERROR = 500    // 业务错误
```

## 7. API接口

### 用户模块

#### 登录
- **URL**: `POST /api/user/login`
- **是否需要Token**: 否
- **请求参数**:
```json
{
  "username": "账号",
  "password": "密码"
}
```
- **响应**:
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": "JWT Token"
}
```

## 8. 依赖关系

```
Spring Boot
├── spring-boot-starter-web
├── spring-boot-starter-security
├── spring-boot-starter-test
├── mybatis-plus-boot-starter
├── mysql-connector-j
├── jjwt-api/impl/jackson
├── hutool-all
├── knife4j-openapi3-jakarta-spring-boot-starter
└── lombok
```

## 9. 配置文件

### application.yml 关键配置

```yaml
server:
  port: 8080
  servlet:
    context-path: /api

spring:
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://127.0.0.1:3306/cms_content
    username: root
    password: 123456

jwt:
  secret: cms-mysql-only-secret-key-2026-longstring123456
  expire-time: 86400000  # 1天

mybatis-plus:
  mapper-locations: classpath:mapper/**/*.xml
  type-aliases-package: com.cms.entity
  configuration:
    map-underscore-to-camel-case: true
```

## 10. 运行方式

### 10.1 环境要求
- JDK 17+
- Maven 3.x
- MySQL 5.7+

### 10.2 数据库初始化
```sql
CREATE DATABASE cms_content DEFAULT CHARACTER SET utf8mb4;
```

### 10.3 启动项目
```bash
cd d:\360安全浏览器下载\huangjinwang\huangjinwang\huangjinwang
mvn spring-boot:run
```

### 10.4 访问接口文档
- 启动后访问: `http://localhost:8080/api/doc.html`

## 11. 项目特点

1. **纯MySQL实现**: 无Redis缓存，JWT令牌存储在客户端
2. **统一响应格式**: 所有接口返回统一的 `Result<T>` 格式
3. **全局异常处理**: 通过 `GlobalExceptionHandler` 统一处理异常
4. **JWT认证**: 使用拦截器实现接口鉴权
5. **BCrypt密码加密**: 使用Hutool的BCrypt实现密码安全存储
6. **Knife4j文档**: 自动生成OpenAPI 3.0接口文档
