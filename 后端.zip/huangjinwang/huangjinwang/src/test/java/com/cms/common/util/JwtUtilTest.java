package com.cms.common.util;

import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThat;

class JwtUtilTest {

    @Test
    void supportsPlainTextSecretContainingDashes() {
        JwtUtil jwtUtil = new JwtUtil();
        ReflectionTestUtils.setField(jwtUtil, "secret", "cms-mysql-only-secret-key-2026-longstring123456");
        ReflectionTestUtils.setField(jwtUtil, "expireTime", 86400000L);

        String token = jwtUtil.generateToken(1L, 1);

        assertThat(jwtUtil.verifyToken(token)).isTrue();
        assertThat(jwtUtil.getUserId(token)).isEqualTo("1");
        assertThat(jwtUtil.getUserRole(token)).isEqualTo(1);
    }
}
