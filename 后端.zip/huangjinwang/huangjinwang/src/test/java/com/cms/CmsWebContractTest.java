package com.cms;

import com.cms.common.config.WebConfig;
import com.cms.common.exception.GlobalExceptionHandler;
import com.cms.common.interceptor.JwtInterceptor;
import com.cms.common.result.PageResult;
import com.cms.common.util.JwtUtil;
import com.cms.controller.ArticleController;
import com.cms.controller.UserController;
import com.cms.entity.CmsUser;
import com.cms.service.ArticleService;
import com.cms.service.CmsUserService;
import com.cms.vo.article.ArticleVO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = CmsWebContractTest.TestApplication.class)
@AutoConfigureMockMvc
class CmsWebContractTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CmsUserService userService;

    @MockBean
    private ArticleService articleService;

    @MockBean
    private JwtUtil jwtUtil;

    @SpringBootConfiguration
    @EnableAutoConfiguration
    @Import({
            UserController.class,
            ArticleController.class,
            WebConfig.class,
            JwtInterceptor.class,
            GlobalExceptionHandler.class
    })
    static class TestApplication {
    }

    @Test
    void loginIsPublicUnderApiContextPath() throws Exception {
        CmsUser user = new CmsUser();
        user.setId(1L);
        user.setRole(1);

        when(userService.login(any())).thenReturn(user);
        when(jwtUtil.generateToken(1L, 1)).thenReturn("login-token");

        mockMvc.perform(post("/api/user/login")
                        .contextPath("/api")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"123456\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data").value("login-token"));
    }

    @Test
    void articleListAcceptsTokenHeaderUnderApiContextPath() throws Exception {
        ArticleVO article = new ArticleVO();
        article.setId(1L);
        article.setTitle("Vue 3.5正式发布");

        when(jwtUtil.verifyToken("good-token")).thenReturn(true);
        when(jwtUtil.getUserId("good-token")).thenReturn("1");
        when(jwtUtil.getUserRole("good-token")).thenReturn(1);
        when(articleService.pageList(any())).thenReturn(PageResult.build(1L, 1L, List.of(article)));

        mockMvc.perform(get("/api/article/list")
                        .contextPath("/api")
                        .header("token", "good-token"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data.records[0].title").value("Vue 3.5正式发布"));
    }
}
