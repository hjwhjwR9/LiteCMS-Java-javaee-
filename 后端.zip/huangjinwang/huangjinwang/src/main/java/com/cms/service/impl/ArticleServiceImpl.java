package com.cms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cms.common.util.LoginUserUtil;
import com.cms.dto.article.ArticleDTO;
import com.cms.dto.article.ArticleQueryDTO;
import com.cms.entity.CmsArticle;
import com.cms.entity.CmsArticleLike;
import com.cms.entity.CmsUser;
import com.cms.mapper.CmsArticleMapper;
import com.cms.mapper.CmsArticleLikeMapper;
import com.cms.mapper.CmsUserMapper;
import com.cms.common.exception.BusinessException;
import com.cms.common.result.PageResult;
import com.cms.service.ArticleService;
import com.cms.service.CategoryService;
import com.cms.vo.article.ArticleVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ArticleServiceImpl extends ServiceImpl<CmsArticleMapper, CmsArticle> implements ArticleService {

    @Autowired
    private CategoryService categoryService;
    @Autowired
    private CmsArticleLikeMapper articleLikeMapper;
    @Autowired
    private CmsUserMapper userMapper;

    @Override
    public PageResult<ArticleVO> pageList(ArticleQueryDTO dto) {
        Page<CmsArticle> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        LambdaQueryWrapper<CmsArticle> wrapper = new LambdaQueryWrapper<>();
        wrapper.in(CmsArticle::getStatus, 2);
        if (dto.getKeyword() != null && !dto.getKeyword().isEmpty()) {
            wrapper.like(CmsArticle::getTitle, dto.getKeyword());
        }
        wrapper.orderByDesc(CmsArticle::getCreatedAt);
        IPage<CmsArticle> pageData = page(page, wrapper);
        return convertToPageResult(pageData);
    }

    @Override
    public PageResult<ArticleVO> pageMyList(ArticleQueryDTO dto) {
        Long userId = LoginUserUtil.getLoginUserId();
        Page<CmsArticle> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        LambdaQueryWrapper<CmsArticle> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CmsArticle::getAuthorId, userId);
        if (dto.getStatus() != null) {
            wrapper.eq(CmsArticle::getStatus, dto.getStatus());
        }
        wrapper.orderByDesc(CmsArticle::getCreatedAt);
        IPage<CmsArticle> pageData = page(page, wrapper);
        return convertToPageResult(pageData);
    }

    private PageResult<ArticleVO> convertToPageResult(IPage<CmsArticle> pageData) {
        List<ArticleVO> records = new ArrayList<>();
        for (CmsArticle article : pageData.getRecords()) {
            ArticleVO vo = new ArticleVO();
            BeanUtils.copyProperties(article, vo);
            vo.setCategoryName(categoryService.getCategoryName(article.getCategoryId()));
            CmsUser user = userMapper.selectById(article.getAuthorId());
            if (user != null) vo.setAuthorNickname(user.getNickname());
            records.add(vo);
        }
        return PageResult.build(pageData.getTotal(), pageData.getPages(), records);
    }

    @Override
    public ArticleVO getDetail(Long id) {
        CmsArticle article = getById(id);
        if (article == null) {
            throw new BusinessException("文章不存在");
        }
        if (article.getViewCount() == null) article.setViewCount(0L);
        article.setViewCount(article.getViewCount() + 1);
        updateById(article);
        ArticleVO vo = new ArticleVO();
        BeanUtils.copyProperties(article, vo);
        vo.setCategoryName(categoryService.getCategoryName(article.getCategoryId()));
        CmsUser user = userMapper.selectById(article.getAuthorId());
        if (user != null) vo.setAuthorNickname(user.getNickname());
        return vo;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void create(ArticleDTO dto) {
        Long userId = LoginUserUtil.getLoginUserId();
        CmsArticle article = new CmsArticle();
        BeanUtils.copyProperties(dto, article);
        article.setAuthorId(userId);
        article.setStatus(dto.getStatus() != null ? dto.getStatus() : 0);
        article.setViewCount(0L);
        article.setLikeCount(0L);
        article.setCommentCount(0L);
        article.setCreatedAt(LocalDateTime.now());
        article.setUpdatedAt(LocalDateTime.now());
        if (article.getStatus() != null && article.getStatus() == 2) {
            article.setPublishedAt(LocalDateTime.now());
        }
        save(article);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(ArticleDTO dto) {
        CmsArticle article = getById(dto.getId());
        if (article == null) {
            throw new BusinessException("文章不存在");
        }
        if (dto.getCategoryId() != null) article.setCategoryId(dto.getCategoryId());
        if (dto.getTitle() != null) article.setTitle(dto.getTitle());
        if (dto.getSummary() != null) article.setSummary(dto.getSummary());
        if (dto.getCoverUrl() != null) article.setCoverUrl(dto.getCoverUrl());
        if (dto.getContent() != null) article.setContent(dto.getContent());
        if (dto.getStatus() != null) {
            Integer oldStatus = article.getStatus();
            article.setStatus(dto.getStatus());
            if (dto.getStatus() == 2 && (oldStatus == null || oldStatus != 2)) {
                article.setPublishedAt(LocalDateTime.now());
            }
        }
        article.setUpdatedAt(LocalDateTime.now());
        updateById(article);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        CmsArticle article = getById(id);
        if (article == null) {
            throw new BusinessException("文章不存在");
        }
        Long userId = LoginUserUtil.getLoginUserId();
        if (!article.getAuthorId().equals(userId)) {
            throw new BusinessException("只能删除自己的文章");
        }
        removeById(id);
    }

    @Override
    public void submitForReview(Long id) {
        CmsArticle article = getById(id);
        if (article == null) {
            throw new BusinessException("文章不存在");
        }
        article.setStatus(1);
        article.setSubmittedAt(LocalDateTime.now());
        article.setUpdatedAt(LocalDateTime.now());
        updateById(article);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void like(Long articleId) {
        Long userId = LoginUserUtil.getLoginUserId();
        LambdaQueryWrapper<CmsArticleLike> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CmsArticleLike::getArticleId, articleId).eq(CmsArticleLike::getUserId, userId);
        CmsArticleLike exist = articleLikeMapper.selectOne(wrapper);
        if (exist != null) {
            throw new BusinessException("已点赞");
        }
        CmsArticleLike like = new CmsArticleLike();
        like.setArticleId(articleId);
        like.setUserId(userId);
        like.setCreatedAt(LocalDateTime.now());
        articleLikeMapper.insert(like);
        CmsArticle article = getById(articleId);
        if (article != null) {
            if (article.getLikeCount() == null) article.setLikeCount(0L);
            article.setLikeCount(article.getLikeCount() + 1);
            updateById(article);
        }
    }

    @Override
    public boolean checkLike(Long articleId) {
        Long userId = LoginUserUtil.getLoginUserId();
        LambdaQueryWrapper<CmsArticleLike> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CmsArticleLike::getArticleId, articleId).eq(CmsArticleLike::getUserId, userId);
        return articleLikeMapper.selectCount(wrapper) > 0;
    }
}
