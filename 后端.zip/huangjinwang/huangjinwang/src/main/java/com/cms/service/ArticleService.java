package com.cms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cms.dto.article.ArticleDTO;
import com.cms.dto.article.ArticleQueryDTO;
import com.cms.entity.CmsArticle;
import com.cms.common.result.PageResult;
import com.cms.vo.article.ArticleVO;

public interface ArticleService extends IService<CmsArticle> {
    PageResult<ArticleVO> pageList(ArticleQueryDTO dto);
    PageResult<ArticleVO> pageMyList(ArticleQueryDTO dto);
    ArticleVO getDetail(Long id);
    void create(ArticleDTO dto);
    void update(ArticleDTO dto);
    void delete(Long id);
    void submitForReview(Long id);
    void like(Long articleId);
    boolean checkLike(Long articleId);
}
