package com.cms.common.result;

import lombok.Data;
import java.util.List;

@Data
public class PageResult<T> {
    private Long total;
    private Long pages;
    private List<T> records;

    public static <T> PageResult<T> build(Long total, Long pages, List<T> list) {
        PageResult<T> page = new PageResult<>();
        page.setTotal(total);
        page.setPages(pages);
        page.setRecords(list);
        return page;
    }
}