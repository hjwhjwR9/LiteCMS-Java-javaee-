package com.cms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cms.common.util.LoginUserUtil;
import com.cms.dto.comment.CommentDTO;
import com.cms.dto.comment.CommentStatusDTO;
import com.cms.entity.CmsArticle;
import com.cms.entity.CmsComment;
import com.cms.entity.CmsUser;
import com.cms.mapper.CmsArticleMapper;
import com.cms.mapper.CmsCommentMapper;
import com.cms.mapper.CmsUserMapper;
import com.cms.common.exception.BusinessException;
import com.cms.service.CommentService;
import com.cms.vo.comment.CommentVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class CommentServiceImpl extends ServiceImpl<CmsCommentMapper, CmsComment> implements CommentService {

    @Autowired
    private CmsUserMapper userMapper;
    @Autowired
    private CmsArticleMapper articleMapper;

    @Override
    public List<CommentVO> listByArticle(Long articleId) {
        LambdaQueryWrapper<CmsComment> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CmsComment::getArticleId, articleId).in(CmsComment::getStatus, 1, 0).orderByDesc(CmsComment::getCreatedAt);
        return convertToVOList(list(wrapper));
    }

    @Override
    public List<CommentVO> listAll() {
        LambdaQueryWrapper<CmsComment> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByDesc(CmsComment::getCreatedAt);
        return convertToVOList(list(wrapper));
    }

    private List<CommentVO> convertToVOList(List<CmsComment> comments) {
        List<CommentVO> voList = new ArrayList<>();
        for (CmsComment comment : comments) {
            CommentVO vo = new CommentVO();
            BeanUtils.copyProperties(comment, vo);
            CmsUser user = userMapper.selectById(comment.getUserId());
            if (user != null) vo.setUserNickname(user.getNickname());
            voList.add(vo);
        }
        return voList;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void add(CommentDTO dto) {
        Long userId = LoginUserUtil.getLoginUserId();
        CmsComment comment = new CmsComment();
        comment.setArticleId(dto.getArticleId());
        comment.setUserId(userId);
        comment.setParentId(dto.getParentId());
        comment.setContent(dto.getContent());
        comment.setStatus(0);
        comment.setCreatedAt(LocalDateTime.now());
        comment.setUpdatedAt(LocalDateTime.now());
        save(comment);
        CmsArticle article = articleMapper.selectById(dto.getArticleId());
        if (article != null) {
            if (article.getCommentCount() == null) article.setCommentCount(0L);
            article.setCommentCount(article.getCommentCount() + 1);
            articleMapper.updateById(article);
        }
    }

    @Override
    public void updateStatus(CommentStatusDTO dto) {
        CmsComment comment = getById(dto.getId());
        if (comment == null) {
            throw new BusinessException("评论不存在");
        }
        comment.setStatus(dto.getStatus());
        comment.setUpdatedAt(LocalDateTime.now());
        updateById(comment);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        CmsComment comment = getById(id);
        if (comment == null) {
            throw new BusinessException("评论不存在");
        }
        removeById(id);
        CmsArticle article = articleMapper.selectById(comment.getArticleId());
        if (article != null && article.getCommentCount() != null && article.getCommentCount() > 0) {
            article.setCommentCount(article.getCommentCount() - 1);
            articleMapper.updateById(article);
        }
    }
}
