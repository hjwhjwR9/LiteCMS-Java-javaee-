package com.cms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cms.dto.category.CategoryDTO;
import com.cms.entity.CmsCategory;
import com.cms.vo.category.CategoryVO;
import java.util.List;

public interface CategoryService extends IService<CmsCategory> {
    List<CategoryVO> listAll();
    void add(CategoryDTO dto);
    void update(CategoryDTO dto);
    void delete(Long id);
    String getCategoryName(Long id);
}
