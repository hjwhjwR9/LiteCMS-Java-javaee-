package com.cms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cms.dto.user.UserLoginDTO;
import com.cms.dto.user.UserQueryDTO;
import com.cms.dto.user.UserSaveDTO;
import com.cms.entity.CmsUser;
import com.cms.common.exception.BusinessException;
import com.cms.mapper.CmsUserMapper;
import com.cms.common.result.PageResult;
import com.cms.service.CmsUserService;
import com.cms.common.util.PasswordUtil;
import com.cms.vo.user.UserVO;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

import org.springframework.beans.BeanUtils;
import java.util.List;
import java.util.stream.Collectors;
@Service
public class CmsUserServiceImpl extends ServiceImpl<CmsUserMapper, CmsUser> implements CmsUserService {

    @Override
    public CmsUser login(UserLoginDTO dto) {
        CmsUser user = lambdaQuery().eq(CmsUser::getUsername, dto.getUsername()).one();
        if(user == null){
            throw new BusinessException("账号不存在");
        }
        if(!PasswordUtil.match(dto.getPassword(),user.getPasswordHash())){
            throw new BusinessException("密码错误");
        }
        return user;
    }

    @Override
    public void updateLoginTime(Long userId) {
        lambdaUpdate()
                .set(CmsUser::getLastLoginAt, LocalDateTime.now())
                .eq(CmsUser::getId,userId)
                .update();
    }


    @Override
    public PageResult<UserVO> pageList(UserQueryDTO dto) {
        Page<CmsUser> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        LambdaQueryWrapper<CmsUser> wrapper = new LambdaQueryWrapper<>();

        if (dto.getKeyword() != null && !dto.getKeyword().isEmpty()) {
            wrapper.and(w -> w
                    .like(CmsUser::getUsername, dto.getKeyword())
                    .or()
                    .like(CmsUser::getNickname, dto.getKeyword())
            );
        }
        if (dto.getRole() != null) {
            wrapper.eq(CmsUser::getRole, dto.getRole());
        }
        if (dto.getStatus() != null) {
            wrapper.eq(CmsUser::getStatus, dto.getStatus());
        }
        wrapper.orderByDesc(CmsUser::getCreatedAt);

        IPage<CmsUser> pageData = page(page, wrapper);

        // Entity 转 VO
        List<UserVO> voList = pageData.getRecords().stream().map(user -> {
            UserVO vo = new UserVO();
            BeanUtils.copyProperties(user, vo);
            return vo;
        }).collect(Collectors.toList());

        return PageResult.build(pageData.getTotal(), pageData.getPages(), voList);
    }

    @Override
    public void register(UserSaveDTO dto) {
        if (lambdaQuery().eq(CmsUser::getUsername, dto.getUsername()).one() != null) {
            throw new BusinessException("用户名已存在");
        }
        CmsUser user = new CmsUser();
        user.setUsername(dto.getUsername());
        user.setPasswordHash(PasswordUtil.encrypt(dto.getPassword()));
        user.setNickname(dto.getNickname() != null ? dto.getNickname() : dto.getUsername());
        user.setPhone(dto.getPhone());
        user.setEmail(dto.getEmail());
        user.setRole(dto.getRole() != null ? dto.getRole() : 0);
        user.setStatus(1);
        user.setCreatedAt(LocalDateTime.now());
        save(user);
    }

    @Override
    public void updateUser(UserSaveDTO dto) {
        CmsUser user = getById(dto.getId());
        if (user == null) {
            throw new BusinessException("用户不存在");
        }
        if (dto.getNickname() != null) user.setNickname(dto.getNickname());
        if (dto.getPhone() != null) user.setPhone(dto.getPhone());
        if (dto.getEmail() != null) user.setEmail(dto.getEmail());
        if (dto.getRole() != null) user.setRole(dto.getRole());
        if (dto.getPassword() != null && !dto.getPassword().isEmpty()) {
            user.setPasswordHash(PasswordUtil.encrypt(dto.getPassword()));
        }
        user.setUpdatedAt(LocalDateTime.now());
        updateById(user);
    }

    @Override
    public void updateStatus(Long id, Integer status) {
        CmsUser user = getById(id);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }
        user.setStatus(status);
        user.setUpdatedAt(LocalDateTime.now());
        updateById(user);
    }
}