package com.cms.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("cms_article")
public class CmsArticle {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long categoryId;
    private Long authorId;
    private String title;
    private String summary;
    private String coverUrl;
    private String content;
    private Integer status;
    private Long viewCount;
    private Long likeCount;
    private Long commentCount;
    private LocalDateTime submittedAt;
    private LocalDateTime publishedAt;
    private LocalDateTime offlineAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}