package com.cms.dto.category;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "栏目参数")
public class CategoryDTO {
    @Schema(description = "ID")
    private Long id;
    @Schema(description = "父栏目ID")
    private Long parentId;
    @Schema(description = "栏目名称")
    private String name;
    @Schema(description = "排序，值越小越靠前")
    private Integer sortOrder;
}
