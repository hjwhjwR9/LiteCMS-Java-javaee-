package com.cms.common.util;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class LoginUserUtil {
    // 获取当前登录用户ID
    public static Long getLoginUserId() {
        HttpServletRequest request = getRequest();
        return (Long) request.getAttribute("loginUserId");
    }
    // 获取当前登录角色
    public static Integer getLoginRole() {
        HttpServletRequest request = getRequest();
        return (Integer) request.getAttribute("loginUserRole");
    }
    private static HttpServletRequest getRequest() {
        RequestAttributes attr = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes servletAttr = (ServletRequestAttributes) attr;
        return servletAttr.getRequest();
    }
}