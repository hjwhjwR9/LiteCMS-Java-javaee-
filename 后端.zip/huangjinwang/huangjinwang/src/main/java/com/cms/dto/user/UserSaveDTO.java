package com.cms.dto.user;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "新增/编辑用户")
public class UserSaveDTO {
    @Schema(description = "用户ID，新增不传")
    private Long id;
    @Schema(description = "账号")
    private String username;
    @Schema(description = "密码")
    private String password;
    @Schema(description = "昵称")
    private String nickname;
    @Schema(description = "手机号")
    private String phone;
    @Schema(description = "邮箱")
    private String email;
    @Schema(description = "角色0普通1管理员2审核员")
    private Integer role;
    @Schema(description = "状态0禁用1正常")
    private Integer status;
}