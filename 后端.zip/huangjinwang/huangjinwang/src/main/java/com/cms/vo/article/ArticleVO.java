package com.cms.vo.article;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Schema(description = "文章返回数据")
public class ArticleVO {
    private Long id;
    private Long categoryId;
    private String categoryName;
    private Long authorId;
    private String authorNickname;
    private String title;
    private String summary;
    private String coverUrl;
    private String content;
    private Integer status;
    private Long viewCount;
    private Long likeCount;
    private Long commentCount;
    private LocalDateTime submittedAt;
    private LocalDateTime publishedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
