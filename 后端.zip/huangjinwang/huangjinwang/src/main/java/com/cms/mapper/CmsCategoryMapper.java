package com.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cms.entity.CmsCategory;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CmsCategoryMapper extends BaseMapper<CmsCategory> {
}
