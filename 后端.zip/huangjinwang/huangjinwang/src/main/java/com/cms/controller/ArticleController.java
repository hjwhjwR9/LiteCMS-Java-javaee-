package com.cms.controller;

import com.cms.common.result.PageResult;
import com.cms.common.result.Result;
import com.cms.dto.article.ArticleDTO;
import com.cms.dto.article.ArticleQueryDTO;
import com.cms.service.ArticleService;
import com.cms.vo.article.ArticleVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/article")
@Tag(name = "文章模块")
public class ArticleController {

    @Resource
    private ArticleService articleService;

    @GetMapping("/list")
    @Operation(summary = "获取已发布文章列表")
    public Result<PageResult<ArticleVO>> list(
            @RequestParam(required = false) Long pageNum,
            @RequestParam(required = false) Long pageSize,
            @RequestParam(required = false) String keyword) {
        ArticleQueryDTO dto = new ArticleQueryDTO();
        if (pageNum != null) dto.setPageNum(pageNum);
        if (pageSize != null) dto.setPageSize(pageSize);
        if (keyword != null) dto.setKeyword(keyword);
        return Result.success(articleService.pageList(dto));
    }

    @GetMapping("/my")
    @Operation(summary = "获取我的文章列表")
    public Result<PageResult<ArticleVO>> myList(
            @RequestParam(required = false) Long pageNum,
            @RequestParam(required = false) Long pageSize,
            @RequestParam(required = false) Integer status) {
        ArticleQueryDTO dto = new ArticleQueryDTO();
        if (pageNum != null) dto.setPageNum(pageNum);
        if (pageSize != null) dto.setPageSize(pageSize);
        if (status != null) dto.setStatus(status);
        return Result.success(articleService.pageMyList(dto));
    }

    @GetMapping("/{id}")
    @Operation(summary = "获取文章详情")
    public Result<ArticleVO> getDetail(@PathVariable Long id) {
        return Result.success(articleService.getDetail(id));
    }

    @PostMapping("")
    @Operation(summary = "创建文章")
    public Result<Void> create(@RequestBody ArticleDTO dto) {
        articleService.create(dto);
        return Result.success();
    }

    @PutMapping("")
    @Operation(summary = "更新文章")
    public Result<Void> update(@RequestBody ArticleDTO dto) {
        articleService.update(dto);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除文章")
    public Result<Void> delete(@PathVariable Long id) {
        articleService.delete(id);
        return Result.success();
    }

    @PostMapping("/like")
    @Operation(summary = "点赞文章")
    public Result<Void> like(@RequestParam Long articleId) {
        articleService.like(articleId);
        return Result.success();
    }

    @GetMapping("/checkLike")
    @Operation(summary = "检查是否已点赞")
    public Result<Boolean> checkLike(@RequestParam Long articleId) {
        return Result.success(articleService.checkLike(articleId));
    }
}
