package com.cms.common.constant;

public class CmsConstant {
    // 用户角色
    public static final int USER_ROLE_NORMAL = 0;  // 普通用户
    public static final int USER_ROLE_ADMIN = 1;   // 管理员
    public static final int USER_ROLE_AUDIT = 2;   // 审核员
    // 用户状态
    public static final int USER_STATUS_DISABLE = 0;
    public static final int USER_STATUS_NORMAL = 1;

    // 文章状态
    public static final int ARTICLE_DRAFT = 0;
    public static final int ARTICLE_WAIT_AUDIT = 1;
    public static final int ARTICLE_PUBLISH = 2;
    public static final int ARTICLE_REJECT = 3;
    public static final int ARTICLE_OFFLINE = 4;

    // 审核结果
    public static final int AUDIT_PASS = 1;
    public static final int AUDIT_REJECT = 2;

    // 评论状态
    public static final int COMMENT_WAIT = 0;
    public static final int COMMENT_PASS = 1;
    public static final int COMMENT_REJECT = 2;
    public static final int COMMENT_DELETE = 3;
}