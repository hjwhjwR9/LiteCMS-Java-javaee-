package com.cms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cms.dto.category.CategoryDTO;
import com.cms.entity.CmsCategory;
import com.cms.mapper.CmsCategoryMapper;
import com.cms.service.CategoryService;
import com.cms.vo.category.CategoryVO;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl extends ServiceImpl<CmsCategoryMapper, CmsCategory> implements CategoryService {

    @Override
    public List<CategoryVO> listAll() {
        List<CmsCategory> list = list(new LambdaQueryWrapper<CmsCategory>().orderByAsc(CmsCategory::getSortOrder));
        List<CategoryVO> voList = list.stream().map(item -> {
            CategoryVO vo = new CategoryVO();
            BeanUtils.copyProperties(item, vo);
            return vo;
        }).collect(Collectors.toList());
        return buildTree(voList);
    }

    private List<CategoryVO> buildTree(List<CategoryVO> list) {
        List<CategoryVO> roots = new ArrayList<>();
        for (CategoryVO item : list) {
            if (item.getParentId() == null || item.getParentId() == 0) {
                item.setChildren(getChildren(item.getId(), list));
                roots.add(item);
            }
        }
        return roots;
    }

    private List<CategoryVO> getChildren(Long id, List<CategoryVO> list) {
        List<CategoryVO> children = new ArrayList<>();
        for (CategoryVO item : list) {
            if (item.getParentId() != null && item.getParentId().equals(id)) {
                item.setChildren(getChildren(item.getId(), list));
                children.add(item);
            }
        }
        return children;
    }

    @Override
    public void add(CategoryDTO dto) {
        CmsCategory category = new CmsCategory();
        BeanUtils.copyProperties(dto, category);
        category.setStatus(1);
        category.setCreatedAt(LocalDateTime.now());
        category.setUpdatedAt(LocalDateTime.now());
        save(category);
    }

    @Override
    public void update(CategoryDTO dto) {
        CmsCategory category = getById(dto.getId());
        if (category == null) {
            throw new com.cms.common.exception.BusinessException("栏目不存在");
        }
        if (dto.getName() != null) category.setName(dto.getName());
        if (dto.getParentId() != null) category.setParentId(dto.getParentId());
        if (dto.getSortOrder() != null) category.setSortOrder(dto.getSortOrder());
        category.setUpdatedAt(LocalDateTime.now());
        updateById(category);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        List<Long> idsToDelete = new ArrayList<>();
        collectChildIds(id, idsToDelete);
        idsToDelete.add(id);
        removeByIds(idsToDelete);
    }

    private void collectChildIds(Long parentId, List<Long> ids) {
        List<CmsCategory> children = list(new LambdaQueryWrapper<CmsCategory>().eq(CmsCategory::getParentId, parentId));
        for (CmsCategory child : children) {
            ids.add(child.getId());
            collectChildIds(child.getId(), ids);
        }
    }

    @Override
    public String getCategoryName(Long id) {
        if (id == null) return "";
        CmsCategory category = getById(id);
        return category != null ? category.getName() : "";
    }
}
