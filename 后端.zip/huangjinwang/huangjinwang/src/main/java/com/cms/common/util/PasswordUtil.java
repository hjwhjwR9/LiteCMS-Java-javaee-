package com.cms.common.util;

import cn.hutool.crypto.digest.BCrypt;

public class PasswordUtil {
    // 加密
    public static String encrypt(String rawPwd) {
        return BCrypt.hashpw(rawPwd, BCrypt.gensalt());
    }
    // 校验
    public static boolean match(String rawPwd, String hash) {
        return BCrypt.checkpw(rawPwd, hash);
    }
}