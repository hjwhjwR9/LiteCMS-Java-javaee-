package com.cms.dto.article;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "文章参数")
public class ArticleDTO {
    @Schema(description = "ID")
    private Long id;
    @Schema(description = "栏目ID")
    private Long categoryId;
    @Schema(description = "标题")
    private String title;
    @Schema(description = "摘要")
    private String summary;
    @Schema(description = "封面URL")
    private String coverUrl;
    @Schema(description = "正文内容")
    private String content;
    @Schema(description = "状态：0草稿 1待审核 2已发布 3已驳回 4已下架")
    private Integer status;
}
