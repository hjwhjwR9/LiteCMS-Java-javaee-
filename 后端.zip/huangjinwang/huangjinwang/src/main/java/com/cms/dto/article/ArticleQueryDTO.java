package com.cms.dto.article;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "文章查询参数")
public class ArticleQueryDTO {
    @Schema(description = "页码")
    private Long pageNum = 1L;
    @Schema(description = "每页条数")
    private Long pageSize = 10L;
    @Schema(description = "状态过滤")
    private Integer status;
    @Schema(description = "关键字(标题)")
    private String keyword;
}
