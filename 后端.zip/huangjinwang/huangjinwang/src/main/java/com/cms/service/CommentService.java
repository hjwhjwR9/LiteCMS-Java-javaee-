package com.cms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cms.dto.comment.CommentDTO;
import com.cms.dto.comment.CommentStatusDTO;
import com.cms.entity.CmsComment;
import com.cms.vo.comment.CommentVO;
import java.util.List;

public interface CommentService extends IService<CmsComment> {
    List<CommentVO> listByArticle(Long articleId);
    List<CommentVO> listAll();
    void add(CommentDTO dto);
    void updateStatus(CommentStatusDTO dto);
    void delete(Long id);
}
