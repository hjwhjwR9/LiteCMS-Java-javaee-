package com.cms.vo.comment;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Schema(description = "评论返回数据")
public class CommentVO {
    private Long id;
    private Long articleId;
    private Long userId;
    private String userNickname;
    private Long parentId;
    private String content;
    private Integer status;
    private LocalDateTime createdAt;
}
