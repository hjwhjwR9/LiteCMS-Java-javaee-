package com.cms.common.util;

import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.UUID;

@Component
public class FileUtil {

    private static final Set<String> ALLOWED_IMAGE_TYPES = Set.of(
            "image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp"
    );

    /**
     * 验证是否为允许的图片类型
     */
    public static boolean isAllowedImageType(String contentType) {
        return contentType != null && ALLOWED_IMAGE_TYPES.contains(contentType.toLowerCase());
    }

    /**
     * 获取文件扩展名
     */
    public static String getExtension(String filename) {
        if (filename == null || !filename.contains(".")) {
            return "";
        }
        return filename.substring(filename.lastIndexOf("."));
    }

    /**
     * 生成唯一文件名
     */
    public static String generateUniqueFilename(String extension) {
        return UUID.randomUUID().toString().replace("-", "") + extension;
    }
}