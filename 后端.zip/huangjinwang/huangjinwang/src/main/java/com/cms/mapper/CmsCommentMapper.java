package com.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cms.entity.CmsComment;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CmsCommentMapper extends BaseMapper<CmsComment> {
}
