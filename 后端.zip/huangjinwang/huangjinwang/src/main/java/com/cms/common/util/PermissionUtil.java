package com.cms.common.util;

import com.cms.common.constant.ResultCode;
import com.cms.common.exception.BusinessException;

public class PermissionUtil {

    public static final int ROLE_ADMIN = 1;
    public static final int ROLE_REVIEWER = 2;
    public static final int ROLE_USER = 3;

    public static void checkAdmin() {
        Integer role = LoginUserUtil.getLoginRole();
        if (role == null || role != ROLE_ADMIN) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权操作，需要管理员权限");
        }
    }

    public static void checkReviewer() {
        Integer role = LoginUserUtil.getLoginRole();
        if (role == null || (role != ROLE_ADMIN && role != ROLE_REVIEWER)) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权操作，需要审核员权限");
        }
    }

    public static boolean isAdmin() {
        Integer role = LoginUserUtil.getLoginRole();
        return role != null && role == ROLE_ADMIN;
    }

    public static boolean isReviewer() {
        Integer role = LoginUserUtil.getLoginRole();
        return role != null && (role == ROLE_ADMIN || role == ROLE_REVIEWER);
    }
}