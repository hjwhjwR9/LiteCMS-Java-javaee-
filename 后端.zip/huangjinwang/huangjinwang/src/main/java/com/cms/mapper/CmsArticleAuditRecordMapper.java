package com.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cms.entity.CmsArticleAuditRecord;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CmsArticleAuditRecordMapper extends BaseMapper<CmsArticleAuditRecord> {
}
