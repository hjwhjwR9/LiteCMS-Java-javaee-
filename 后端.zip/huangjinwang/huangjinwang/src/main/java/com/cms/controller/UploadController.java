package com.cms.controller;

import com.cms.common.result.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@RestController
@RequestMapping("/upload")
@Tag(name = "文件上传模块")
public class UploadController {

    @PostMapping("/image")
    @Operation(summary = "上传图片")
    public Result<String> uploadImage(@RequestParam("file") MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return Result.fail(400, "请选择要上传的文件");
        }

        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            return Result.fail(400, "只能上传图片文件");
        }

        String originalFilename = file.getOriginalFilename();
        String ext = "";
        if (originalFilename != null && originalFilename.contains(".")) {
            ext = originalFilename.substring(originalFilename.lastIndexOf(".")).toLowerCase();
        }
        String newFilename = UUID.randomUUID().toString().replace("-", "") + ext;

        // 获取项目根目录并创建上传目录
        String projectRoot = System.getProperty("user.dir");
        String uploadDir = projectRoot + File.separator + "upload" + File.separator;

        try {
            // 确保目录存在
            Path uploadPath = Paths.get(uploadDir);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            File destFile = new File(uploadDir + newFilename);
            file.transferTo(destFile);

//            String fileUrl = "/upload/" + newFilename;
            String fileUrl = "/api/upload/" + newFilename;
            return Result.success(fileUrl);
        } catch (IOException e) {
            e.printStackTrace();
            return Result.fail(500, "文件上传失败: " + e.getMessage());
        }
    }

    @PostMapping("/cover")
    @Operation(summary = "上传封面图片")
    public Result<String> uploadCover(@RequestParam("file") MultipartFile file) {
        return uploadImage(file);
    }
}