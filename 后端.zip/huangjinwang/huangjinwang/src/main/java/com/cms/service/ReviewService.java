package com.cms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cms.dto.article.ArticleQueryDTO;
import com.cms.dto.review.ReviewBatchDTO;
import com.cms.dto.review.ReviewRejectDTO;
import com.cms.entity.CmsArticle;
import com.cms.common.result.PageResult;
import com.cms.vo.article.ArticleVO;

public interface ReviewService extends IService<CmsArticle> {
    PageResult<ArticleVO> pageList(ArticleQueryDTO dto);
    void approve(Long id);
    void reject(Long id, ReviewRejectDTO dto);
    void batchApprove(ReviewBatchDTO dto);
    void batchReject(ReviewBatchDTO dto);
}
