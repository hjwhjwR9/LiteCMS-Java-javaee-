package com.cms.controller;

import com.cms.common.result.PageResult;
import com.cms.common.result.Result;
import com.cms.dto.user.UserLoginDTO;
import com.cms.dto.user.UserQueryDTO;
import com.cms.dto.user.UserSaveDTO;
import com.cms.dto.user.UserStatusDTO;
import com.cms.entity.CmsUser;
import com.cms.service.CmsUserService;
import com.cms.common.util.JwtUtil;
import com.cms.vo.user.UserVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;
import com.cms.common.util.LoginUserUtil;
import com.cms.common.util.PermissionUtil;

@RestController
@RequestMapping("/user")
@Tag(name = "用户模块")
public class UserController {
    @Resource
    private CmsUserService userService;
    @Resource
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    @Operation(summary = "用户登录")
    public Result<String> login(@RequestBody UserLoginDTO dto) {
        CmsUser user = userService.login(dto);
        userService.updateLoginTime(user.getId());
        String token = jwtUtil.generateToken(user.getId(), user.getRole());
        return Result.success(token);
    }

    // 修改 list 方法的返回类型
    @GetMapping("/list")
    @Operation(summary = "获取用户列表")
    public Result<PageResult<UserVO>> list(
            @RequestParam(required = false) Long pageNum,
            @RequestParam(required = false) Long pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer role,
            @RequestParam(required = false) Integer status) {
        PermissionUtil.checkAdmin();
        UserQueryDTO dto = new UserQueryDTO();
        if (pageNum != null) dto.setPageNum(pageNum);
        if (pageSize != null) dto.setPageSize(pageSize);
        if (keyword != null) dto.setKeyword(keyword);
        if (role != null) dto.setRole(role);
        if (status != null) dto.setStatus(status);
        PageResult<UserVO> result = userService.pageList(dto);
        return Result.success(result);
    }

    @GetMapping("/{id}")
    @Operation(summary = "获取用户详情")
    public Result<CmsUser> getDetail(@PathVariable Long id) {
        PermissionUtil.checkAdmin();
        return Result.success(userService.getById(id));
    }

    @PostMapping("/register")
    @Operation(summary = "注册用户")
    public Result<Void> register(@RequestBody UserSaveDTO dto) {
        PermissionUtil.checkAdmin();
        userService.register(dto);
        return Result.success();
    }

    @PutMapping("/update")
    @Operation(summary = "更新用户")
    public Result<Void> update(@RequestBody UserSaveDTO dto) {
        PermissionUtil.checkAdmin();
        userService.updateUser(dto);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除用户")
    public Result<Void> delete(@PathVariable Long id) {
        PermissionUtil.checkAdmin();
        userService.removeById(id);
        return Result.success();
    }

    @PutMapping("/status")
    @Operation(summary = "更新用户状态")
    public Result<Void> updateStatus(@RequestBody UserStatusDTO dto) {
        PermissionUtil.checkAdmin();
        userService.updateStatus(dto.getId(), dto.getStatus());
        return Result.success();
    }

    @GetMapping("/info")
    @Operation(summary = "获取当前用户信息")
    public Result<CmsUser> getCurrentUserInfo() {
        Long userId = LoginUserUtil.getLoginUserId();
        return Result.success(userService.getById(userId));
    }
}