package com.cms.controller;

import com.cms.common.result.PageResult;
import com.cms.common.result.Result;
import com.cms.common.util.PermissionUtil;
import com.cms.dto.article.ArticleQueryDTO;
import com.cms.dto.review.ReviewBatchDTO;
import com.cms.dto.review.ReviewRejectDTO;
import com.cms.service.ReviewService;
import com.cms.vo.article.ArticleVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/review")
@Tag(name = "审核模块")
public class ReviewController {

    @Resource
    private ReviewService reviewService;

    @GetMapping("/article")
    @Operation(summary = "获取待审核文章列表")
    public Result<PageResult<ArticleVO>> list(
            @RequestParam(required = false) Long pageNum,
            @RequestParam(required = false) Long pageSize,
            @RequestParam(required = false) Integer status) {
        PermissionUtil.checkAdmin();
        ArticleQueryDTO dto = new ArticleQueryDTO();
        if (pageNum != null) dto.setPageNum(pageNum);
        if (pageSize != null) dto.setPageSize(pageSize);
        if (status != null) dto.setStatus(status);
        return Result.success(reviewService.pageList(dto));
    }

    @PutMapping("/article/{id}/approve")
    @Operation(summary = "审核通过")
    public Result<Void> approve(@PathVariable Long id) {
        PermissionUtil.checkAdmin();
        reviewService.approve(id);
        return Result.success();
    }

    @PutMapping("/article/{id}/reject")
    @Operation(summary = "审核驳回")
    public Result<Void> reject(@PathVariable Long id, @RequestBody(required = false) ReviewRejectDTO dto) {
        PermissionUtil.checkAdmin();
        reviewService.reject(id, dto);
        return Result.success();
    }

    @PostMapping("/article/batch-approve")
    @Operation(summary = "批量通过")
    public Result<Void> batchApprove(@RequestBody ReviewBatchDTO dto) {
        PermissionUtil.checkAdmin();
        reviewService.batchApprove(dto);
        return Result.success();
    }

    @PostMapping("/article/batch-reject")
    @Operation(summary = "批量驳回")
    public Result<Void> batchReject(@RequestBody ReviewBatchDTO dto) {
        PermissionUtil.checkAdmin();
        reviewService.batchReject(dto);
        return Result.success();
    }
}
