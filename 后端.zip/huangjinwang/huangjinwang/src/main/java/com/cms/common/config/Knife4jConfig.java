package com.cms.common.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Knife4jConfig {
    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("CMS内容管理系统接口文档")
                        .version("v1.0")
                        .description("仅MySQL实现，用户/栏目/文章/评论/点赞管理"));
    }
}