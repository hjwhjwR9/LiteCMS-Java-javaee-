package com.cms.common.exception;

import com.cms.common.constant.ResultCode;
import lombok.Data;

@Data
public class BusinessException extends RuntimeException {
    private Integer code;

    public BusinessException(String msg) {
        super(msg);
        this.code = ResultCode.BUSINESS_ERROR;
    }

    public BusinessException(Integer code, String msg) {
        super(msg);
        this.code = code;
    }
}