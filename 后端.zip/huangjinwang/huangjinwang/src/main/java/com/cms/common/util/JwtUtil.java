package com.cms.common.util;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {
    @Value("${jwt.secret}")
    private String secret;
    @Value("${jwt.expire-time}")
    private Long expireTime;

    public String generateToken(Long userId,Integer role) {
        Date now = new Date();
        Date expire = new Date(now.getTime() + expireTime);
        return Jwts.builder()
                .setSubject(userId.toString())
                .claim("role",role)
                .setIssuedAt(now)
                .setExpiration(expire)
                .signWith(signingKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    public String getUserId(String token) {
        Claims claims = Jwts.parser().setSigningKey(signingKey()).parseClaimsJws(token).getBody();
        return claims.getSubject();
    }

    public Integer getUserRole(String token) {
        Claims claims = Jwts.parser().setSigningKey(signingKey()).parseClaimsJws(token).getBody();
        return claims.get("role",Integer.class);
    }

    public boolean verifyToken(String token) {
        try{
            Jwts.parser().setSigningKey(signingKey()).parseClaimsJws(token);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    private Key signingKey() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }
}
