package com.cms.dto.role;

import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Schema(description = "角色DTO")
public class RoleDTO {
    @Schema(description = "角色ID（更新时必填）")
    private Long id;

    @Schema(description = "角色名称", required = true)
    private String name;

    @Schema(description = "角色标识")
    private String roleKey;

    @Schema(description = "角色描述")
    private String description;
}