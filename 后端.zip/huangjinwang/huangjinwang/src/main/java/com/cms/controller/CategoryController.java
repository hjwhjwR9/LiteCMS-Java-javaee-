package com.cms.controller;

import com.cms.common.result.Result;
import com.cms.dto.category.CategoryDTO;
import com.cms.service.CategoryService;
import com.cms.vo.category.CategoryVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/category")
@Tag(name = "栏目模块")
public class CategoryController {

    @Resource
    private CategoryService categoryService;

    @GetMapping("/list")
    @Operation(summary = "获取所有栏目列表")
    public Result<List<CategoryVO>> list() {
        return Result.success(categoryService.listAll());
    }

    @PostMapping("/add")
    @Operation(summary = "新增栏目")
    public Result<Void> add(@RequestBody CategoryDTO dto) {
        categoryService.add(dto);
        return Result.success();
    }

    @PutMapping("/update")
    @Operation(summary = "更新栏目")
    public Result<Void> update(@RequestBody CategoryDTO dto) {
        categoryService.update(dto);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除栏目（含子栏目）")
    public Result<Void> delete(@PathVariable Long id) {
        categoryService.delete(id);
        return Result.success();
    }
}
