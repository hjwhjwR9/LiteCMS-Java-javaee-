package com.cms.common.config;

import com.cms.common.util.PasswordUtil;
import com.cms.entity.CmsUser;
import com.cms.mapper.CmsUserMapper;
import jakarta.annotation.Resource;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class UserInitializer implements CommandLineRunner {

    @Resource
    private CmsUserMapper userMapper;

    @Override
    public void run(String... args) {
        // 初始化admin用户（如果不存在）
        CmsUser admin = userMapper.selectOne(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<CmsUser>()
                        .eq(CmsUser::getUsername, "admin")
        );
        if (admin == null) {
            CmsUser user = new CmsUser();
            user.setUsername("admin");
            user.setPasswordHash(PasswordUtil.encrypt("123456"));
            user.setNickname("系统管理员");
            user.setRole(1);
            user.setStatus(1);
            userMapper.insert(user);
            System.out.println("[CMS] 管理员账号初始化成功: admin / 123456");
        }

        // 初始化审核员账号
        CmsUser auditor = userMapper.selectOne(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<CmsUser>()
                        .eq(CmsUser::getUsername, "auditor")
        );
        if (auditor == null) {
            CmsUser user = new CmsUser();
            user.setUsername("auditor");
            user.setPasswordHash(PasswordUtil.encrypt("123456"));
            user.setNickname("审核员");
            user.setRole(2);
            user.setStatus(1);
            userMapper.insert(user);
            System.out.println("[CMS] 审核员账号初始化成功: auditor / 123456");
        }

        // 初始化普通用户
        CmsUser user01 = userMapper.selectOne(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<CmsUser>()
                        .eq(CmsUser::getUsername, "user01")
        );
        if (user01 == null) {
            CmsUser user = new CmsUser();
            user.setUsername("user01");
            user.setPasswordHash(PasswordUtil.encrypt("123456"));
            user.setNickname("普通用户");
            user.setRole(0);
            user.setStatus(1);
            userMapper.insert(user);
            System.out.println("[CMS] 普通用户账号初始化成功: user01 / 123456");
        }
    }
}
