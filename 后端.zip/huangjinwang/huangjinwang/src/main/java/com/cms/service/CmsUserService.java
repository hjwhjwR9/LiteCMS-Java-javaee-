package com.cms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cms.dto.user.UserLoginDTO;
import com.cms.dto.user.UserQueryDTO;
import com.cms.dto.user.UserSaveDTO;
import com.cms.entity.CmsUser;
import com.cms.common.result.PageResult;
import com.cms.vo.user.UserVO;

public interface CmsUserService extends IService<CmsUser> {
    CmsUser login(UserLoginDTO dto);
    void updateLoginTime(Long userId);
    PageResult<UserVO> pageList(UserQueryDTO dto);
    void register(UserSaveDTO dto);
    void updateUser(UserSaveDTO dto);
    void updateStatus(Long id, Integer status);
}