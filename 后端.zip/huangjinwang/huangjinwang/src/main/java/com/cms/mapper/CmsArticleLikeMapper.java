package com.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cms.entity.CmsArticleLike;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CmsArticleLikeMapper extends BaseMapper<CmsArticleLike> {
}
