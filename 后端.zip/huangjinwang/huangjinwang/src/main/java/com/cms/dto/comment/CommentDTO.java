package com.cms.dto.comment;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "评论参数")
public class CommentDTO {
    @Schema(description = "文章ID")
    private Long articleId;
    @Schema(description = "评论内容")
    private String content;
    @Schema(description = "父评论ID，可为空")
    private Long parentId;
}
