package com.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cms.entity.CmsUser;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CmsUserMapper extends BaseMapper<CmsUser> {
}