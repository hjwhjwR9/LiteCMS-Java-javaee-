package com.cms.dto.review;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.util.List;

@Data
@Schema(description = "批量审核参数")
public class ReviewBatchDTO {
    @Schema(description = "文章ID列表")
    private List<Long> ids;
}
