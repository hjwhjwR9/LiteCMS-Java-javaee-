package com.cms.common.constant;

public class ResultCode {
    public static final int SUCCESS = 200;
    public static final int UNAUTHORIZED = 401;
    public static final int FORBIDDEN = 403;
    public static final int PARAM_ERROR = 400;
    public static final int BUSINESS_ERROR = 500;
}