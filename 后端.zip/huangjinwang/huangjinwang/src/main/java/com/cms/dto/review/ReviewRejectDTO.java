package com.cms.dto.review;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "驳回参数")
public class ReviewRejectDTO {
    @Schema(description = "驳回原因")
    private String reason;
}
