package com.cms.common.interceptor;

import com.cms.common.constant.ResultCode;
import com.cms.common.exception.BusinessException;
import com.cms.common.util.JwtUtil;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class JwtInterceptor implements HandlerInterceptor {

    // 注入Jwt工具Bean，解决找不到符号、空指针问题
    @Resource
    private JwtUtil jwtUtil;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }
        String token = request.getHeader("token");
        // 兼容JDK8及以上所有版本，判断null、空字符串、全空格
        if (token == null || token.trim().length() == 0) {
            throw new BusinessException(ResultCode.UNAUTHORIZED, "未登录，请先登录");
        }
        // 使用注入实例校验token有效性
        if (!jwtUtil.verifyToken(token)) {
            throw new BusinessException(ResultCode.UNAUTHORIZED, "token失效，请重新登录");
        }
        // 解析用户ID、角色存入request域，Controller可直接获取
        Long userId = Long.valueOf(jwtUtil.getUserId(token));
        Integer role = jwtUtil.getUserRole(token);
        request.setAttribute("loginUserId", userId);
        request.setAttribute("loginUserRole", role);
        return true;
    }
}
