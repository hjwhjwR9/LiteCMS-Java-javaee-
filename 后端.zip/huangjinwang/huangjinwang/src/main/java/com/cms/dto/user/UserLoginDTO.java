package com.cms.dto.user;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "登录参数")
public class UserLoginDTO {
    @Schema(description = "账号",requiredMode = Schema.RequiredMode.REQUIRED)
    private String username;
    @Schema(description = "密码",requiredMode = Schema.RequiredMode.REQUIRED)
    private String password;
}