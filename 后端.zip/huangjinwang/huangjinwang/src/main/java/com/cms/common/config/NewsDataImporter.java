package com.cms.common.config;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.cms.entity.CmsArticle;
import com.cms.entity.CmsCategory;
import com.cms.entity.CmsUser;
import com.cms.mapper.CmsArticleMapper;
import com.cms.mapper.CmsCategoryMapper;
import com.cms.mapper.CmsUserMapper;
import com.cms.common.util.PasswordUtil;
import jakarta.annotation.Resource;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Component
@ConditionalOnProperty(name = "cms.data-import.enabled", havingValue = "true", matchIfMissing = true)
public class NewsDataImporter implements CommandLineRunner {

    @Resource
    private CmsCategoryMapper categoryMapper;
    @Resource
    private CmsArticleMapper articleMapper;
    @Resource
    private CmsUserMapper userMapper;

    private static final String IMPORT_FILE = "D:\\360安全浏览器下载\\vite-project\\vite-project\\news_assets\\data\\import_data.json";

    @Override
    public void run(String... args) {
        try {
            String content = cn.hutool.core.io.FileUtil.readString(IMPORT_FILE, "UTF-8");
            JSONObject data = JSONUtil.parseObj(content);

            Map<String, Long> categoryIdMap = importCategories(data.getJSONArray("categories"));
            importUsers(data.getJSONArray("users"));
            importNews(data.getJSONArray("news"), categoryIdMap);

            System.out.println("[CMS] 新闻数据导入完成！");
        } catch (Exception e) {
            System.err.println("[CMS] 新闻数据导入失败: " + e.getMessage());
        }
    }

    private Map<String, Long> importCategories(JSONArray categories) {
        Map<String, Long> nameToId = new HashMap<>();

        for (Object item : categories) {
            JSONObject cat = (JSONObject) item;
            String name = cat.getStr("name");

            CmsCategory existing = categoryMapper.selectOne(
                    new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<CmsCategory>()
                            .eq(CmsCategory::getName, name)
            );

            if (existing != null) {
                nameToId.put(name, existing.getId());
            } else {
                CmsCategory category = new CmsCategory();
                category.setParentId(null);
                category.setName(name);
                category.setSortOrder(cat.getInt("id", 0));
                category.setStatus(1);
                category.setCreatedAt(LocalDateTime.now());
                category.setUpdatedAt(LocalDateTime.now());
                categoryMapper.insert(category);
                nameToId.put(name, category.getId());
            }
        }
        return nameToId;
    }

    private void importUsers(JSONArray users) {
        for (Object item : users) {
            JSONObject user = (JSONObject) item;
            String username = user.getStr("username");

            CmsUser existing = userMapper.selectOne(
                    new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<CmsUser>()
                            .eq(CmsUser::getUsername, username)
            );

            if (existing == null) {
                CmsUser u = new CmsUser();
                u.setUsername(username);
                u.setPasswordHash(PasswordUtil.encrypt("123456"));
                u.setNickname(user.getStr("nickname"));
                u.setAvatarUrl(user.getStr("avatar"));
                u.setRole(0);
                u.setStatus(1);
                u.setCreatedAt(LocalDateTime.now());
                u.setUpdatedAt(LocalDateTime.now());
                userMapper.insert(u);
            }
        }
    }

    private void importNews(JSONArray newsList, Map<String, Long> categoryIdMap) {
        Long defaultCategoryId = categoryIdMap.getOrDefault("热点", 1L);
        Long defaultAuthorId = 1L;

        for (Object item : newsList) {
            JSONObject news = (JSONObject) item;
            String title = news.getStr("title");
            if (title == null || title.trim().isEmpty()) {
                continue;
            }

            CmsArticle existing = articleMapper.selectOne(
                    new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<CmsArticle>()
                            .eq(CmsArticle::getTitle, title)
            );

            if (existing != null) {
                continue;
            }

            CmsArticle article = new CmsArticle();
            article.setCategoryId(defaultCategoryId);
            article.setAuthorId(defaultAuthorId);
            article.setTitle(title);
            article.setSummary(news.getStr("summary", ""));
            article.setCoverUrl(news.getStr("coverUrl", ""));
            article.setContent("<p>来源: " + news.getStr("source", "") + "</p><p>热度: " + news.getStr("hot", "") + "</p>");
            article.setStatus(2);
            article.setViewCount(news.getLong("hot", 0L));
            article.setLikeCount(0L);
            article.setCommentCount(0L);
            article.setPublishedAt(LocalDateTime.now());
            article.setCreatedAt(LocalDateTime.now());
            article.setUpdatedAt(LocalDateTime.now());
            articleMapper.insert(article);
        }
    }
}