package com.cms.controller;

import com.cms.common.result.Result;
import com.cms.dto.role.RoleDTO;
import com.cms.entity.CmsRole;
import com.cms.entity.CmsRolePermission;
import com.cms.mapper.CmsRoleMapper;
import com.cms.mapper.CmsRolePermissionMapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/role")
@Tag(name = "角色模块")
public class RoleController {

    @Resource
    private CmsRoleMapper roleMapper;
    @Resource
    private CmsRolePermissionMapper rolePermissionMapper;

    @GetMapping("/list")
    @Operation(summary = "获取角色列表")
    public Result<List<CmsRole>> list() {
        return Result.success(roleMapper.selectList(null));
    }

    @GetMapping("/{id}")
    @Operation(summary = "获取角色详情")
    public Result<CmsRole> getDetail(@PathVariable Long id) {
        return Result.success(roleMapper.selectById(id));
    }

    @PostMapping("/add")
    @Operation(summary = "新增角色")
    public Result<Void> add(@RequestBody RoleDTO dto) {
        CmsRole role = new CmsRole();
        role.setName(dto.getName());
        role.setRoleKey(dto.getRoleKey());
        role.setDescription(dto.getDescription());
        role.setStatus(1);
        role.setCreatedAt(LocalDateTime.now());
        roleMapper.insert(role);
        return Result.success();
    }

    @PutMapping("/update")
    @Operation(summary = "更新角色")
    public Result<Void> update(@RequestBody RoleDTO dto) {
        CmsRole role = roleMapper.selectById(dto.getId());
        if (role != null) {
            role.setName(dto.getName());
            role.setRoleKey(dto.getRoleKey());
            role.setDescription(dto.getDescription());
            role.setUpdatedAt(LocalDateTime.now());
            roleMapper.updateById(role);
        }
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除角色")
    public Result<Void> delete(@PathVariable Long id) {
        roleMapper.deleteById(id);
        LambdaQueryWrapper<CmsRolePermission> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CmsRolePermission::getRoleId, id);
        rolePermissionMapper.delete(wrapper);
        return Result.success();
    }

    @GetMapping("/{id}/permissions")
    @Operation(summary = "获取角色权限ID列表")
    public Result<List<Long>> getPermissions(@PathVariable Long id) {
        LambdaQueryWrapper<CmsRolePermission> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CmsRolePermission::getRoleId, id);
        List<CmsRolePermission> permissions = rolePermissionMapper.selectList(wrapper);
        List<Long> permissionIds = permissions.stream()
                .map(CmsRolePermission::getPermissionId)
                .toList();
        return Result.success(permissionIds);
    }

    @PutMapping("/{id}/permissions")
    @Operation(summary = "配置角色权限")
    public Result<Void> setPermissions(@PathVariable Long id, @RequestBody List<Long> permissionIds) {
        LambdaQueryWrapper<CmsRolePermission> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CmsRolePermission::getRoleId, id);
        rolePermissionMapper.delete(wrapper);

        for (Long permissionId : permissionIds) {
            CmsRolePermission rp = new CmsRolePermission();
            rp.setRoleId(id);
            rp.setPermissionId(permissionId);
            rp.setCreatedAt(LocalDateTime.now());
            rolePermissionMapper.insert(rp);
        }
        return Result.success();
    }
}