package com.cms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cms.common.util.LoginUserUtil;
import com.cms.dto.article.ArticleQueryDTO;
import com.cms.dto.review.ReviewBatchDTO;
import com.cms.dto.review.ReviewRejectDTO;
import com.cms.entity.CmsArticle;
import com.cms.entity.CmsArticleAuditRecord;
import com.cms.entity.CmsUser;
import com.cms.mapper.CmsArticleAuditRecordMapper;
import com.cms.mapper.CmsArticleMapper;
import com.cms.mapper.CmsUserMapper;
import com.cms.common.exception.BusinessException;
import com.cms.common.result.PageResult;
import com.cms.service.ReviewService;
import com.cms.service.CategoryService;
import com.cms.vo.article.ArticleVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReviewServiceImpl extends ServiceImpl<CmsArticleMapper, CmsArticle> implements ReviewService {

    @Autowired
    private CategoryService categoryService;
    @Autowired
    private CmsUserMapper userMapper;
    @Autowired
    private CmsArticleAuditRecordMapper auditRecordMapper;

    @Override
    public PageResult<ArticleVO> pageList(ArticleQueryDTO dto) {
        Page<CmsArticle> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        LambdaQueryWrapper<CmsArticle> wrapper = new LambdaQueryWrapper<>();
        if (dto.getStatus() != null) {
            wrapper.eq(CmsArticle::getStatus, dto.getStatus());
        } else {
            wrapper.in(CmsArticle::getStatus, 0, 1, 2, 3);
        }
        wrapper.orderByDesc(CmsArticle::getSubmittedAt);
        wrapper.orderByDesc(CmsArticle::getCreatedAt);
        IPage<CmsArticle> pageData = page(page, wrapper);
        List<ArticleVO> records = new ArrayList<>();
        for (CmsArticle article : pageData.getRecords()) {
            ArticleVO vo = new ArticleVO();
            BeanUtils.copyProperties(article, vo);
            vo.setCategoryName(categoryService.getCategoryName(article.getCategoryId()));
            CmsUser user = userMapper.selectById(article.getAuthorId());
            if (user != null) vo.setAuthorNickname(user.getNickname());
            records.add(vo);
        }
        return PageResult.build(pageData.getTotal(), pageData.getPages(), records);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void approve(Long id) {
        Long auditorId = LoginUserUtil.getLoginUserId();
        CmsArticle article = getById(id);
        if (article == null) {
            throw new BusinessException("文章不存在");
        }
        article.setStatus(2);
        article.setPublishedAt(LocalDateTime.now());
        article.setUpdatedAt(LocalDateTime.now());
        updateById(article);
        CmsArticleAuditRecord record = new CmsArticleAuditRecord();
        record.setArticleId(id);
        record.setAuditorId(auditorId);
        record.setAuditResult(1);
        record.setCreatedAt(LocalDateTime.now());
        auditRecordMapper.insert(record);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void reject(Long id, ReviewRejectDTO dto) {
        Long auditorId = LoginUserUtil.getLoginUserId();
        CmsArticle article = getById(id);
        if (article == null) {
            throw new BusinessException("文章不存在");
        }
        article.setStatus(3);
        article.setUpdatedAt(LocalDateTime.now());
        updateById(article);
        CmsArticleAuditRecord record = new CmsArticleAuditRecord();
        record.setArticleId(id);
        record.setAuditorId(auditorId);
        record.setAuditResult(2);
        record.setAuditRemark(dto != null ? dto.getReason() : "");
        record.setCreatedAt(LocalDateTime.now());
        auditRecordMapper.insert(record);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void batchApprove(ReviewBatchDTO dto) {
        for (Long id : dto.getIds()) {
            approve(id);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void batchReject(ReviewBatchDTO dto) {
        ReviewRejectDTO rejectDTO = new ReviewRejectDTO();
        rejectDTO.setReason("批量驳回");
        for (Long id : dto.getIds()) {
            reject(id, rejectDTO);
        }
    }
}
