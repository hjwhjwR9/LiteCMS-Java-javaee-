package com.cms.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("cms_article_audit_record")
public class CmsArticleAuditRecord {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long articleId;
    private Long auditorId;
    private Integer auditResult;
    private String auditRemark;
    private LocalDateTime createdAt;
}