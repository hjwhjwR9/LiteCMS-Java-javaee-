package com.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cms.entity.CmsRolePermission;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CmsRolePermissionMapper extends BaseMapper<CmsRolePermission> {
}