package com.cms.controller;

import com.cms.common.result.Result;
import com.cms.dto.comment.CommentDTO;
import com.cms.dto.comment.CommentStatusDTO;
import com.cms.service.CommentService;
import com.cms.vo.comment.CommentVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/comment")
@Tag(name = "评论模块")
public class CommentController {

    @Resource
    private CommentService commentService;

    @GetMapping("/list")
    @Operation(summary = "获取文章评论列表")
    public Result<List<CommentVO>> list(@RequestParam Long articleId) {
        return Result.success(commentService.listByArticle(articleId));
    }

    @GetMapping("/all")
    @Operation(summary = "获取所有评论列表（后台管理）")
    public Result<List<CommentVO>> allList() {
        return Result.success(commentService.listAll());
    }

    @PostMapping("/add")
    @Operation(summary = "新增评论")
    public Result<Void> add(@RequestBody CommentDTO dto) {
        commentService.add(dto);
        return Result.success();
    }

    @PutMapping("/status")
    @Operation(summary = "更新评论状态")
    public Result<Void> updateStatus(@RequestBody CommentStatusDTO dto) {
        commentService.updateStatus(dto);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除评论")
    public Result<Void> delete(@PathVariable Long id) {
        commentService.delete(id);
        return Result.success();
    }
}
