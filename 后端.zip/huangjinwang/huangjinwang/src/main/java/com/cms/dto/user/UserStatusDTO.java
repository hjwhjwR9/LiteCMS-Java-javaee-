
package com.cms.dto.user;

import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Schema(description = "用户状态更新DTO")
public class UserStatusDTO {
    private Long id;
    private Integer status;
}