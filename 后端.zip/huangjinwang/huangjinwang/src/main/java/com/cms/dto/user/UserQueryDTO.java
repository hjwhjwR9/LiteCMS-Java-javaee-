package com.cms.dto.user;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "用户分页查询条件")
public class UserQueryDTO {
    @Schema(description = "页码",defaultValue = "1")
    private Long pageNum = 1L;
    @Schema(description = "每页条数",defaultValue = "10")
    private Long pageSize = 10L;
    @Schema(description = "账号/昵称模糊搜索")
    private String keyword;
    @Schema(description = "角色")
    private Integer role;

    @Schema(description = "状态")
    private Integer status;
}