package com.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cms.entity.CmsArticle;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CmsArticleMapper extends BaseMapper<CmsArticle> {
}
