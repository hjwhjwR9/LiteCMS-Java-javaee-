package com.cms.dto.comment;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "更新评论状态参数")
public class CommentStatusDTO {
    @Schema(description = "评论ID")
    private Long id;
    @Schema(description = "状态：0待审核 1已通过 2已驳回 3已删除")
    private Integer status;
}
