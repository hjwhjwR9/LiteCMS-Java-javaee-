import axios from 'axios'
import { ElMessage } from 'element-plus'

// 创建Axios实例 - 对接 huangjinwang 后端（通过Vite代理）
const instance = axios.create({
  baseURL: '/api', // 开发环境通过 vite proxy 代理到 http://localhost:8080/api
  timeout: 15000
})

// 请求拦截器：添加Token
instance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.token = token  // 后端使用 token header
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器：统一错误处理
instance.interceptors.response.use(
  (response) => {
    const res = response.data
    // 如果是后端标准 Result 格式
    if (res.code !== undefined) {
      if (res.code === 200 || res.code === 0) {
        return res.data !== undefined ? res.data : res
      } else {
        ElMessage.error(res.msg || res.message || '请求失败')
        return Promise.reject(res)
      }
    }
    return res
  },
  (error) => {
    // 处理 401 未授权
    if (error.response?.status === 401) {
      ElMessage.error('登录已过期，请重新登录')
      localStorage.clear()
      window.location.href = '/login'
      return Promise.reject(error)
    }
    // 处理其他错误
    const msg = error.response?.data?.msg || error.response?.data?.message || '网络请求失败'
    ElMessage.error(msg)
    return Promise.reject(error)
  }
)

export default instance
