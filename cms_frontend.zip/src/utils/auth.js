export const ROLE_ADMIN = 1
export const ROLE_REVIEWER = 2
export const ROLE_USER = 3

export function getUserInfo() {
  const userInfo = localStorage.getItem('userInfo')
  return userInfo ? JSON.parse(userInfo) : null
}

export function setUserInfo(info) {
  localStorage.setItem('userInfo', JSON.stringify(info))
}

export function clearUserInfo() {
  localStorage.removeItem('userInfo')
  localStorage.removeItem('token')
  localStorage.removeItem('isLogin')
  localStorage.removeItem('username')
  localStorage.removeItem('nickname')
}

export function getRole() {
  const info = getUserInfo()
  return info ? info.role : null
}

export function isAdmin() {
  return getRole() === ROLE_ADMIN
}

export function isReviewer() {
  const role = getRole()
  return role === ROLE_ADMIN || role === ROLE_REVIEWER
}

export function hasRole(roles) {
  if (!roles || roles.length === 0) return true
  const role = getRole()
  if (role == null) return false
  return roles.includes(role)
}

export const roleLabels = {
  1: '超级管理员',
  2: '审核员',
  3: '普通用户'
}

export function getRoleLabel(role) {
  return roleLabels[role] || '未知'
}
