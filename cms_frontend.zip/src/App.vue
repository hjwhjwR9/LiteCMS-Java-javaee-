<template>
    <!-- 路由出口：所有页面都会在这里渲染 -->
    <router-view />
  </template>
  
  <script setup>
  // 无需额外逻辑，仅作为路由容器
  </script>
  
  <style>
  /* 全局样式重置 */
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  body {
    font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
    background-color: #f5f7fa;
  }
  /* 适配Element Plus组件的全局样式 */
  .el-card {
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
  }
  .el-button {
    border-radius: 4px;
  }
  </style>
  