<template>
  <div class="comment-container">
    <h3 class="mb-4">评论区</h3>
    <el-card class="mb-4" v-if="isLogin">
      <el-input
        v-model="commentContent"
        type="textarea"
        rows="3"
        placeholder="请输入评论..."
        maxlength="1000"
        class="mb-2"
      />
      <el-button
        type="primary"
        @click="submitComment"
        :disabled="!commentContent.trim()"
      >
        提交评论
      </el-button>
    </el-card>

    <div class="comment-item" v-for="comment in topComments" :key="comment.id">
      <div class="comment-header">
        <img :src="comment.userAvatar || 'https://placehold.co/40x40'" class="avatar" alt="头像" />
        <span class="nickname ml-2">{{ comment.userNickname }}</span>
        <span class="time ml-4 text-gray-500">{{ formatTime(comment.createdAt) }}</span>
      </div>
      <div class="comment-content mt-2">{{ comment.content }}</div>
      <div class="comment-action mt-2">
        <span @click="replyComment(comment.id)" class="text-primary cursor-pointer">回复</span>
      </div>

      <div class="sub-comment-list mt-3" v-if="comment.subComments.length">
        <div class="sub-comment" v-for="sub in comment.subComments" :key="sub.id">
          <div class="sub-comment-header">
            <span class="sub-nickname">{{ sub.userNickname }}</span>
            <span class="sub-time ml-2 text-gray-500">{{ formatTime(sub.createdAt) }}</span>
          </div>
          <div class="sub-comment-content">{{ sub.content }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { ElMessage } from 'element-plus'
import axios from '../utils/axios'

const props = defineProps({
  articleId: { type: Number, required: true }
})

const commentContent = ref('')
const allComments = ref([])
const isLogin = ref(!!localStorage.getItem('token'))

const getComments = async () => {
  if (!props.articleId) {
    return
  }
  const data = await axios.get('/comment/list', {
    params: { articleId: props.articleId }
  })
  allComments.value = data || []
}

const topComments = computed(() => {
  const tops = (allComments.value || [])
    .filter(item => !item.parentId)
    .map(item => ({ ...item, subComments: [] }))
  const parentMap = {}
  tops.forEach(item => parentMap[item.id] = item)
  ;(allComments.value || []).forEach(item => {
    if (item.parentId && parentMap[item.parentId]) {
      parentMap[item.parentId].subComments.push(item)
    }
  })
  return tops
})

const submitComment = async () => {
  if (!props.articleId) {
    ElMessage.error('文章不存在，无法评论')
    return
  }
  await axios.post('/comment/add', {
    articleId: props.articleId,
    content: commentContent.value,
    parentId: null
  })
  commentContent.value = ''
  ElMessage.success('评论提交成功，待审核')
  getComments()
}

const replyComment = (parentId) => {
  ElMessage.info('回复功能待实现')
}

const formatTime = (time) => {
  if (!time) return '暂无'
  return new Date(time).toLocaleString()
}

onMounted(async () => {
  await getComments()
})
</script>

<style scoped>
.comment-container {
  max-width: 1200px;
  margin: 0 auto;
}
.comment-item {
  padding: 1rem 0;
  border-bottom: 1px solid #eee;
}
.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
}
.sub-comment-list {
  margin-left: 2rem;
  padding-left: 1rem;
  border-left: 2px solid #eee;
}
.sub-comment {
  padding: 0.5rem 0;
}
</style>
