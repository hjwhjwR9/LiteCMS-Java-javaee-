<template>
  <el-container class="layout-container" :class="{ 'no-sidebar': !isLoggedIn }">
    <!-- 侧边栏（仅登录时显示） -->
    <el-aside v-if="isLoggedIn" :width="isCollapse ? '64px' : '220px'" class="aside">
      <!-- Logo区域 -->
      <div class="logo-area">
        <img src="/icons.svg" alt="logo" class="logo-icon" v-if="!isCollapse" />
        <span v-if="!isCollapse" class="logo-text">CMS系统</span>
        <el-icon v-else class="collapse-icon"><component :is="'Fold'" /></el-icon>
      </div>

      <!-- 导航菜单 -->
      <el-menu
        :default-active="activeMenu"
        :collapse="isCollapse"
        :collapse-transition="false"
        router
        class="nav-menu"
        background-color="#304156"
        text-color="#bfcbd9"
        active-text-color="#409EFF"
      >
        <el-menu-item index="/home">
          <el-icon><House /></el-icon>
          <template #title>首页</template>
        </el-menu-item>

        <el-sub-menu index="/article">
          <template #title>
            <el-icon><Document /></el-icon>
            <span>文章管理</span>
          </template>
          <el-menu-item index="/article/list">文章列表</el-menu-item>
          <el-menu-item index="/article/publish" v-if="isLoggedIn">发布文章</el-menu-item>
          <el-menu-item index="/article/manage" v-if="showManageMenu">文章管理</el-menu-item>
        </el-sub-menu>

        <el-sub-menu index="/news">
          <template #title>
            <el-icon><Document /></el-icon>
            <span>新闻管理</span>
          </template>
          <el-menu-item index="/news/list">新闻列表</el-menu-item>
          <el-menu-item index="/news/publish" v-if="isLoggedIn">发布新闻</el-menu-item>
          <el-menu-item index="/news/manage" v-if="showManageMenu">新闻管理</el-menu-item>
        </el-sub-menu>

        <el-sub-menu index="/category" v-if="showSystemMenu">
          <template #title>
            <el-icon><Grid /></el-icon>
            <span>栏目管理</span>
          </template>
          <el-menu-item index="/category/manage">栏目列表</el-menu-item>
        </el-sub-menu>

        <el-sub-menu index="/review" v-if="showReviewMenu">
          <template #title>
            <el-icon><ChatLineSquare /></el-icon>
            <span>内容审核</span>
          </template>
          <el-menu-item index="/review/article">文章审核</el-menu-item>
          <el-menu-item index="/review/news">新闻审核</el-menu-item>
          <el-menu-item index="/review/comment">评论审核</el-menu-item>
        </el-sub-menu>

        <el-menu-item index="/interaction" v-if="showReviewMenu">
          <el-icon><Star /></el-icon>
          <template #title>互动管理</template>
        </el-menu-item>

        <el-menu-item index="/comment/manage" v-if="showReviewMenu">
          <el-icon><ChatDotRound /></el-icon>
          <template #title>评论管理</template>
        </el-menu-item>

        <el-sub-menu index="/system" v-if="showSystemMenu">
          <template #title>
            <el-icon><Setting /></el-icon>
            <span>系统设置</span>
          </template>
          <el-menu-item index="/system/user">用户管理</el-menu-item>
          <el-menu-item index="/system/role">角色管理</el-menu-item>
        </el-sub-menu>
      </el-menu>
    </el-aside>

    <el-container>
      <!-- 顶部导航 -->
      <el-header class="header">
        <div class="header-left">
          <el-icon v-if="isLoggedIn" class="collapse-btn" @click="toggleCollapse">
            <Fold v-if="!isCollapse" />
            <Expand v-else />
          </el-icon>
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item v-if="currentRoute.name">
              {{ currentRoute.name }}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </div>

        <div class="header-right">
          <!-- 消息通知（仅登录时显示） -->
          <template v-if="isLoggedIn">
            <el-badge :value="notificationCount" :hidden="notificationCount === 0" class="notification-badge">
              <el-icon class="header-icon" @click="showNotifications">
                <Bell />
              </el-icon>
            </el-badge>
          </template>

          <!-- 未登录：显示登录按钮 -->
          <el-button v-if="!isLoggedIn" type="primary" @click="toLogin">
            登录
          </el-button>

          <!-- 已登录：显示用户信息 -->
          <el-dropdown v-else @command="handleUserCommand">
            <span class="user-info">
              <el-avatar :size="32" class="user-avatar">
                {{ userInfo.nickname?.charAt(0) || 'U' }}
              </el-avatar>
              <span class="username">
                {{ userInfo.nickname || '用户' }}
                <el-tag v-if="userInfo.roleLabel" size="small" type="primary" effect="plain" class="role-tag">
                  {{ userInfo.roleLabel }}
                </el-tag>
              </span>
              <el-icon><ArrowDown /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">个人中心</el-dropdown-item>
                <el-dropdown-item command="settings">设置</el-dropdown-item>
                <el-dropdown-item divided command="logout">退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <!-- 主内容区 -->
      <el-main class="main-content">
        <router-view v-slot="{ Component }">
          <transition name="fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </el-main>
    </el-container>

    <!-- 通知抽屉 -->
    <el-drawer v-model="notificationDrawer" title="通知中心" size="400px">
      <div class="notification-list">
        <el-empty v-if="notifications.length === 0" description="暂无新通知" />
        <div v-else>
          <div
            v-for="item in notifications"
            :key="item.id"
            class="notification-item"
            :class="{ unread: !item.read }"
            @click="handleNotificationClick(item)"
          >
            <div class="notification-title">{{ item.title }}</div>
            <div class="notification-content">{{ item.content }}</div>
            <div class="notification-time">{{ formatTime(item.createTime) }}</div>
          </div>
        </div>
      </div>
    </el-drawer>
  </el-container>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { format } from 'date-fns'
import { isAdmin, isReviewer, getUserInfo, getRoleLabel, clearUserInfo } from '../utils/auth'

const router = useRouter()
const route = useRoute()

// 侧边栏折叠状态
const isCollapse = ref(false)

// 当前用户信息
const userInfo = computed(() => {
  const info = getUserInfo()
  return {
    nickname: info?.nickname || localStorage.getItem('nickname') || '用户',
    username: info?.username || localStorage.getItem('username') || '',
    role: info?.role,
    roleLabel: info ? getRoleLabel(info.role) : ''
  }
})

const isLoggedIn = computed(() => !!localStorage.getItem('token'))

const showReviewMenu = computed(() => isLoggedIn.value && isReviewer())
const showSystemMenu = computed(() => isLoggedIn.value && isAdmin())
const showManageMenu = computed(() => isLoggedIn.value && isReviewer())

// 通知相关
const notificationCount = ref(3)
const notificationDrawer = ref(false)
const notifications = ref([
  { id: 1, title: '评论审核提醒', content: '有3条评论待审核', createTime: new Date().toISOString(), read: false },
  { id: 2, title: '文章发布成功', content: '您的文章《Vue3最佳实践》已发布', createTime: new Date(Date.now() - 3600000).toISOString(), read: false },
  { id: 3, title: '系统更新', content: 'CMS系统已更新至v2.0版本', createTime: new Date(Date.now() - 86400000).toISOString(), read: true }
])

// 当前激活的菜单
const activeMenu = computed(() => route.path)

// 当前路由信息
const currentRoute = computed(() => ({
  name: route.meta?.title || route.name
}))

// 切换侧边栏折叠
const toggleCollapse = () => {
  isCollapse.value = !isCollapse.value
}

// 显示通知
const showNotifications = () => {
  notificationDrawer.value = true
}

// 处理通知点击
const handleNotificationClick = (item) => {
  item.read = true
  notificationCount.value = notifications.value.filter(n => !n.read).length
  // 根据通知类型跳转到对应页面
  if (item.title.includes('评论')) {
    router.push('/review/comment')
  }
}

// 跳转到登录页
const toLogin = () => {
  router.push('/login')
}

// 用户操作处理
const handleUserCommand = async (command) => {
  switch (command) {
    case 'profile':
      ElMessage.info('个人中心功能开发中')
      break
    case 'settings':
      ElMessage.info('设置功能开发中')
      break
    case 'logout':
      try {
        await ElMessageBox.confirm('确定要退出登录吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
        clearUserInfo()
        router.push('/login')
        ElMessage.success('已退出登录')
      } catch {
      }
      break
  }
}

// 时间格式化
const formatTime = (time) => {
  return time ? format(new Date(time), 'yyyy-MM-dd HH:mm') : ''
}

// 加载用户信息
onMounted(() => {
  // 如果需要从API获取用户信息，可以在这里调用
})
</script>

<style scoped>
.layout-container {
  height: 100vh;
}

.no-sidebar .header {
  padding: 0 24px;
}

.no-sidebar .main-content {
  padding: 24px;
}

.aside {
  background-color: #304156;
  transition: width 0.3s;
  overflow-x: hidden;
}

.logo-area {
  height: 60px;
  display: flex;
  align-items: center;
  padding: 0 16px;
  background-color: #263445;
  color: #fff;
  font-size: 18px;
  font-weight: bold;
}

.logo-icon {
  width: 32px;
  height: 32px;
  margin-right: 8px;
}

.logo-text {
  white-space: nowrap;
}

.collapse-icon {
  font-size: 20px;
  cursor: pointer;
}

.nav-menu {
  border-right: none;
}

.nav-menu:not(.el-menu--collapse) {
  width: 220px;
}

.header {
  background-color: #fff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
}

.header-left {
  display: flex;
  align-items: center;
}

.collapse-btn {
  font-size: 20px;
  cursor: pointer;
  margin-right: 16px;
  color: #606266;
}

.collapse-btn:hover {
  color: #409EFF;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 20px;
}

.header-icon {
  font-size: 20px;
  cursor: pointer;
  color: #606266;
}

.header-icon:hover {
  color: #409EFF;
}

.notification-badge {
  cursor: pointer;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}

.user-avatar {
  background-color: #409EFF;
}

.username {
  font-size: 14px;
  color: #606266;
  display: flex;
  align-items: center;
  gap: 6px;
}

.role-tag {
  margin-left: 4px;
}

.main-content {
  background-color: #f5f7fa;
  padding: 16px;
  overflow-y: auto;
}

.notification-list {
  padding: 0 8px;
}

.notification-item {
  padding: 12px;
  border-bottom: 1px solid #eee;
  cursor: pointer;
  transition: background-color 0.2s;
}

.notification-item:hover {
  background-color: #f5f7fa;
}

.notification-item.unread {
  background-color: #ecf5ff;
}

.notification-title {
  font-weight: 600;
  margin-bottom: 4px;
}

.notification-content {
  font-size: 13px;
  color: #666;
  margin-bottom: 4px;
}

.notification-time {
  font-size: 12px;
  color: #999;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
