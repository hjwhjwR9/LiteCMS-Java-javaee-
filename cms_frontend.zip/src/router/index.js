import { createRouter, createWebHistory } from 'vue-router'
import LayoutSidebar from '../components/LayoutSidebar.vue'
import Login from '../views/Login.vue'
import ArticleListFront from '../views/ArticleListFront.vue'
import ArticleDetail from '../views/ArticleDetail.vue'
import ArticleEdit from '../views/ArticleEdit.vue'
import ArticleManage from '../views/ArticleManage.vue'
import CategoryManage from '../views/CategoryManage.vue'
import CommentManage from '../views/CommentManage.vue'
import NewsList from '../views/NewsList.vue'
import NewsPublish from '../views/NewsPublish.vue'
import NewsManage from '../views/NewsManage.vue'
import ReviewArticle from '../views/ReviewArticle.vue'
import ReviewComment from '../views/ReviewComment.vue'
import ReviewNews from '../views/ReviewNews.vue'
import InteractionManage from '../views/InteractionManage.vue'
import UserManage from '../views/UserManage.vue'
import RoleManage from '../views/RoleManage.vue'
import { hasRole } from '../utils/auth'
import { ElMessage } from 'element-plus'

const ROLE_ADMIN = 1
const ROLE_REVIEWER = 2

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: Login,
      meta: { title: '登录', requiresAuth: false }
    },
    {
      path: '/',
      component: LayoutSidebar,
      redirect: '/home',
      children: [
        {
          path: '/home',
          name: 'home',
          component: ArticleListFront,
          meta: { title: '首页', icon: 'House', requiresAuth: false }
        },
        {
          path: '/article/list',
          name: 'articleList',
          component: ArticleListFront,
          meta: { title: '文章列表', icon: 'Document', requiresAuth: false }
        },
        {
          path: '/article/publish',
          name: 'articlePublish',
          component: ArticleEdit,
          meta: { title: '发布文章', icon: 'Document', requiresAuth: true }
        },
        {
          path: '/article/edit/:id',
          name: 'articleEdit',
          component: ArticleEdit,
          meta: { title: '编辑文章', icon: 'Document', requiresAuth: true }
        },
        {
          path: '/article/manage',
          name: 'articleManage',
          component: ArticleManage,
          meta: { title: '文章管理', icon: 'Management', requiresAuth: true, roles: [ROLE_ADMIN, ROLE_REVIEWER] }
        },
        {
          path: '/news/list',
          name: 'newsList',
          component: NewsList,
          meta: { title: '新闻列表', icon: 'News', requiresAuth: false }
        },
        {
          path: '/news/publish',
          name: 'newsPublish',
          component: NewsPublish,
          meta: { title: '发布新闻', icon: 'News', requiresAuth: true }
        },
        {
          path: '/news/edit/:id',
          name: 'newsEdit',
          component: NewsPublish,
          meta: { title: '编辑新闻', icon: 'News', requiresAuth: true }
        },
        {
          path: '/news/manage',
          name: 'newsManage',
          component: NewsManage,
          meta: { title: '新闻管理', icon: 'Management', requiresAuth: true, roles: [ROLE_ADMIN, ROLE_REVIEWER] }
        },
        {
          path: '/category/manage',
          name: 'categoryManage',
          component: CategoryManage,
          meta: { title: '栏目管理', icon: 'Grid', requiresAuth: true, roles: [ROLE_ADMIN] }
        },
        {
          path: '/review/article',
          name: 'reviewArticle',
          component: ReviewArticle,
          meta: { title: '文章审核', icon: 'ChatLineSquare', requiresAuth: true, roles: [ROLE_ADMIN, ROLE_REVIEWER] }
        },
        {
          path: '/review/comment',
          name: 'reviewComment',
          component: ReviewComment,
          meta: { title: '评论审核', icon: 'ChatLineSquare', requiresAuth: true, roles: [ROLE_ADMIN, ROLE_REVIEWER] }
        },
        {
          path: '/review/news',
          name: 'reviewNews',
          component: ReviewNews,
          meta: { title: '新闻审核', icon: 'ChatLineSquare', requiresAuth: true, roles: [ROLE_ADMIN, ROLE_REVIEWER] }
        },
        {
          path: '/interaction',
          name: 'interaction',
          component: InteractionManage,
          meta: { title: '互动管理', icon: 'Star', requiresAuth: true, roles: [ROLE_ADMIN, ROLE_REVIEWER] }
        },
        {
          path: '/comment/manage',
          name: 'commentManage',
          component: CommentManage,
          meta: { title: '评论管理', icon: 'ChatDotRound', requiresAuth: true, roles: [ROLE_ADMIN, ROLE_REVIEWER] }
        },
        {
          path: '/system/user',
          name: 'userManage',
          component: UserManage,
          meta: { title: '用户管理', icon: 'User', requiresAuth: true, roles: [ROLE_ADMIN] }
        },
        {
          path: '/system/role',
          name: 'roleManage',
          component: RoleManage,
          meta: { title: '角色管理', icon: 'Key', requiresAuth: true, roles: [ROLE_ADMIN] }
        },
        {
          path: '/article/detail/:id',
          name: 'articleDetailLayout',
          component: ArticleDetail,
          meta: { title: '文章详情', icon: 'Document', requiresAuth: false }
        }
      ]
    },
    {
      path: '/article/:id',
      name: 'articleDetail',
      component: ArticleDetail,
      meta: { title: '文章详情', requiresAuth: false }
    },
    {
      path: '/:pathMatch(.*)*',
      redirect: '/home'
    }
  ]
})

router.beforeEach((to, from) => {
  document.title = to.meta?.title ? `${to.meta.title} - CMS系统` : 'CMS系统'

  const isLoggedIn = !!localStorage.getItem('token')

  if (to.path === '/login' && isLoggedIn) {
    return '/home'
  }

  if (to.meta?.requiresAuth && !isLoggedIn) {
    ElMessage.warning('请先登录')
    return '/login'
  }

  if (to.meta?.roles && to.meta.roles.length > 0) {
    if (!hasRole(to.meta.roles)) {
      ElMessage.warning('无权访问该页面')
      return '/home'
    }
  }

  return true
})

export default router
