/**
 * API 服务层 - 对接 huangjinwang CMS 后端
 * 基于 Spring Boot + MySQL
 */

import request from '@/utils/axios'

// ==================== 用户认证 ====================

export const userApi = {
  /**
   * 用户登录
   * @param {Object} data - { username, password }
   * @returns {Promise<string>} token
   */
  login(data) {
    return request.post('/user/login', data)
  },

  /**
   * 获取用户列表
   * @param {Object} params - { pageNum, pageSize, keyword, role, status }
   */
  list(params) {
    return request.get('/user/list', { params })
  },

  /**
   * 获取用户详情
   * @param {Long} id - 用户ID
   */
  getDetail(id) {
    return request.get(`/user/${id}`)
  },

  /**
   * 注册用户
   * @param {Object} data - 用户信息
   */
  register(data) {
    return request.post('/user/register', data)
  },

  /**
   * 更新用户
   * @param {Object} data - 用户信息
   */
  update(data) {
    return request.put('/user/update', data)
  },

  /**
   * 删除用户
   * @param {Long} id - 用户ID
   */
  delete(id) {
    return request.delete(`/user/${id}`)
  },

  /**
   * 更新用户状态
   * @param {Object} data - { id, status }
   */
  updateStatus(data) {
    return request.put('/user/status', data)
  },

  /**
   * 获取当前登录用户信息
   */
  info() {
    return request.get('/user/info')
  }
}

// ==================== 文章管理 ====================

export const articleApi = {
  /**
   * 获取已发布文章列表
   * @param {Object} params - { pageNum, pageSize, keyword }
   */
  list(params) {
    return request.get('/article/list', { params })
  },

  /**
   * 获取我的文章列表
   * @param {Object} params - { pageNum, pageSize, status }
   */
  myList(params) {
    return request.get('/article/my', { params })
  },

  /**
   * 获取文章详情
   * @param {Long} id - 文章ID
   */
  getDetail(id) {
    return request.get(`/article/${id}`)
  },

  /**
   * 创建文章
   * @param {Object} data - ArticleDTO
   */
  create(data) {
    return request.post('/article', data)
  },

  /**
   * 更新文章
   * @param {Object} data - ArticleDTO
   */
  update(data) {
    return request.put('/article', data)
  },

  /**
   * 删除文章
   * @param {Long} id - 文章ID
   */
  delete(id) {
    return request.delete(`/article/${id}`)
  },

  /**
   * 点赞文章
   * @param {Long} articleId - 文章ID
   */
  like(articleId) {
    return request.post('/article/like', null, { params: { articleId } })
  },

  /**
   * 点赞文章（toggle模式，支持取消点赞）
   * @param {Long} articleId - 文章ID
   */
  toggleLike(articleId) {
    return request.post('/article/toggleLike', null, { params: { articleId } })
  },

  /**
   * 检查是否已点赞
   * @param {Long} articleId - 文章ID
   * @returns {Promise<boolean>}
   */
  checkLike(articleId) {
    return request.get('/article/checkLike', { params: { articleId } })
  }
}

// ==================== 栏目管理 ====================

export const categoryApi = {
  /**
   * 获取所有栏目列表
   * @returns {Promise<Array>}
   */
  list() {
    return request.get('/category/list')
  },

  /**
   * 新增栏目
   * @param {Object} data - CategoryDTO
   */
  add(data) {
    return request.post('/category/add', data)
  },

  /**
   * 更新栏目
   * @param {Object} data - CategoryDTO
   */
  update(data) {
    return request.put('/category/update', data)
  },

  /**
   * 删除栏目
   * @param {Long} id - 栏目ID
   */
  delete(id) {
    return request.delete(`/category/${id}`)
  }
}

// ==================== 评论管理 ====================

export const commentApi = {
  /**
   * 获取文章评论列表
   * @param {Long} articleId - 文章ID
   */
  list(articleId) {
    return request.get('/comment/list', { params: { articleId } })
  },

  /**
   * 获取所有评论（后台管理）
   */
  allList() {
    return request.get('/comment/all')
  },

  /**
   * 新增评论
   * @param {Object} data - CommentDTO
   */
  add(data) {
    return request.post('/comment/add', data)
  },

  /**
   * 更新评论状态
   * @param {Object} data - { id, status }
   */
  updateStatus(data) {
    return request.put('/comment/status', data)
  },

  /**
   * 删除评论
   * @param {Long} id - 评论ID
   */
  delete(id) {
    return request.delete(`/comment/${id}`)
  }
}

// ==================== 审核管理 ====================

export const reviewApi = {
  /**
   * 获取待审核文章列表
   * @param {Object} params - { pageNum, pageSize, status }
   */
  articleList(params) {
    return request.get('/review/article', { params })
  },

  /**
   * 审核通过文章
   * @param {Long} id - 文章ID
   */
  approveArticle(id) {
    return request.put(`/review/article/${id}/approve`)
  },

  /**
   * 审核驳回文章
   * @param {Object} data - { id, reason }
   */
  rejectArticle(data) {
    return request.put(`/review/article/${data.id}/reject`, { reason: data.reason })
  },

  /**
   * 批量通过文章
   * @param {Object} data - { ids: [] }
   */
  batchApprove(data) {
    return request.post('/review/article/batch-approve', data)
  },

  /**
   * 批量驳回文章
   * @param {Object} data - { ids: [], reason }
   */
  batchReject(data) {
    return request.post('/review/article/batch-reject', data)
  },

  /**
   * 获取待审核新闻列表
   * @param {Object} params - { pageNum, pageSize, status }
   */
  newsList(params) {
    return request.get('/review/news', { params })
  },

  /**
   * 审核通过新闻
   * @param {Long} id - 新闻ID
   */
  approveNews(id) {
    return request.put(`/review/news/${id}/approve`)
  },

  /**
   * 审核驳回新闻
   * @param {Object} data - { id, reason }
   */
  rejectNews(data) {
    return request.put(`/review/news/${data.id}/reject`, { reason: data.reason })
  },

  /**
   * 获取评论审核列表
   * @param {Object} params - { pageNum, pageSize, status, keyword }
   */
  commentList(params) {
    return request.get('/review/comment', { params })
  },

  /**
   * 审核通过评论
   * @param {Long} id - 评论ID
   */
  approveComment(id) {
    return request.put(`/review/comment/${id}/approve`)
  },

  /**
   * 审核驳回评论
   * @param {Object} data - { id, reason }
   */
  rejectComment(data) {
    return request.put(`/review/comment/${data.id}/reject`, { reason: data.reason })
  },

  /**
   * 批量通过评论
   * @param {Object} data - { ids: [] }
   */
  batchApproveComment(data) {
    return request.post('/review/comment/batch-approve', data)
  },

  /**
   * 批量驳回评论
   * @param {Object} data - { ids: [] }
   */
  batchRejectComment(data) {
    return request.post('/review/comment/batch-reject', data)
  }
}

// ==================== 角色管理 ====================

export const roleApi = {
  /**
   * 获取角色列表
   */
  list() {
    return request.get('/role/list')
  },

  /**
   * 获取角色详情
   * @param {Long} id - 角色ID
   */
  getDetail(id) {
    return request.get(`/role/${id}`)
  },

  /**
   * 新增角色
   * @param {Object} data - RoleDTO
   */
  add(data) {
    return request.post('/role/add', data)
  },

  /**
   * 更新角色
   * @param {Object} data - RoleDTO
   */
  update(data) {
    return request.put('/role/update', data)
  },

  /**
   * 删除角色
   * @param {Long} id - 角色ID
   */
  delete(id) {
    return request.delete(`/role/${id}`)
  },

  /**
   * 获取角色权限
   * @param {Long} id - 角色ID
   */
  getPermissions(id) {
    return request.get(`/role/${id}/permissions`)
  },

  /**
   * 配置角色权限
   * @param {Object} data - { roleId, permissionIds }
   */
  setPermissions(data) {
    return request.put(`/role/${data.roleId}/permissions`, { permissionIds: data.permissionIds })
  }
}

// ==================== 文件上传 ====================

export const uploadApi = {
  /**
   * 上传图片
   * @param {File} file - 图片文件
   * @returns {Promise<string>} 图片URL
   */
  uploadImage(file) {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/upload/image', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
  },

  /**
   * 上传封面图片
   * @param {File} file - 图片文件
   * @returns {Promise<string>} 图片URL
   */
  uploadCover(file) {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/upload/cover', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
  }
}

// ==================== 统计管理 ====================

export const statsApi = {
  /**
   * 获取互动统计数据
   */
  interaction() {
    return request.get('/stats/interaction')
  },

  /**
   * 获取点赞排行榜
   * @param {Object} params - { limit }
   */
  likeRank(params) {
    return request.get('/article/rank/likes', { params })
  },

  /**
   * 获取评论排行榜
   * @param {Object} params - { limit }
   */
  commentRank(params) {
    return request.get('/article/rank/comments', { params })
  },

  /**
   * 获取浏览量排行榜
   * @param {Object} params - { limit }
   */
  viewRank(params) {
    return request.get('/article/rank/views', { params })
  }
}
