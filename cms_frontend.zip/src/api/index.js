/**
 * API 统一导出
 * 对接 huangjinwang CMS 后端 (Spring Boot + MySQL)
 */

export { userApi, articleApi, categoryApi, commentApi, reviewApi, roleApi, statsApi } from './cms'
