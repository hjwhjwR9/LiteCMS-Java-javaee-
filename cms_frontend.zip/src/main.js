import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import axios from './utils/axios'
import { userApi, articleApi, categoryApi, commentApi, reviewApi } from './api'

const app = createApp(App)

// 注册Element Plus图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.use(router)
app.use(ElementPlus)

// 全局挂载
app.config.globalProperties.$axios = axios
app.config.globalProperties.$api = {
  user: userApi,
  article: articleApi,
  category: categoryApi,
  comment: commentApi,
  review: reviewApi
}

app.mount('#app')
