<template>
  <!-- 角色管理页面容器 -->
  <div class="role-manage-container">
    <el-card>
      <!-- 卡片头部 -->
      <template #header>
        <div class="card-header">
          <span class="title">角色管理</span>
          <!-- 新增角色按钮（仅管理员可见） -->
          <el-button type="primary" @click="handleAdd" v-if="canManage">
            <el-icon><Plus /></el-icon> 新增角色
          </el-button>
        </div>
      </template>

      <!-- 角色列表表格 -->
      <el-table :data="roleList" v-loading="loading" stripe border>
        <!-- ID列 -->
        <el-table-column prop="id" label="ID" width="80" />
        <!-- 角色名称列 -->
        <el-table-column prop="name" label="角色名称" width="150" />
        <!-- 角色标识列（标签显示） -->
        <el-table-column prop="roleKey" label="角色标识" width="150">
          <template #default="{ row }">
            <el-tag>{{ row.roleKey }}</el-tag>
          </template>
        </el-table-column>
        <!-- 角色描述列 -->
        <el-table-column prop="description" label="角色描述" min-width="200" show-overflow-tooltip />
        <!-- 用户数列 -->
        <el-table-column label="用户数" width="100">
          <template #default="{ row }">
            <el-tag type="info">{{ row.userCount || 0 }}</el-tag>
          </template>
        </el-table-column>
        <!-- 状态列（标签显示） -->
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : 'danger'">
              {{ row.status === 1 ? '正常' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        <!-- 操作列（编辑/权限/删除，超级管理员不可删除） -->
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button size="small" type="primary" @click="handleEdit(row)" v-if="canManage">编辑</el-button>
            <el-button size="small" type="warning" @click="handlePermission(row)" v-if="canManage">权限</el-button>
            <el-button size="small" type="danger" @click="handleDelete(row)" v-if="canManage && row.id !== 1">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 角色编辑/新增弹窗 -->
    <el-dialog v-model="dialogVisible" :title="isEdit ? '编辑角色' : '新增角色'" width="500px">
      <el-form :model="roleForm" :rules="rules" ref="formRef" label-width="100px">
        <!-- 角色名称 -->
        <el-form-item label="角色名称" prop="name">
          <el-input v-model="roleForm.name" placeholder="请输入角色名称" />
        </el-form-item>
        <!-- 角色标识（编辑时不可修改） -->
        <el-form-item label="角色标识" prop="roleKey">
          <el-input v-model="roleForm.roleKey" placeholder="如：admin, editor, user" :disabled="isEdit" />
        </el-form-item>
        <!-- 角色描述 -->
        <el-form-item label="角色描述" prop="description">
          <el-input v-model="roleForm.description" type="textarea" :rows="3" placeholder="请输入角色描述" />
        </el-form-item>
        <!-- 状态选择 -->
        <el-form-item label="状态" prop="status">
          <el-radio-group v-model="roleForm.status">
            <el-radio :label="1">正常</el-radio>
            <el-radio :label="0">禁用</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit" :loading="submitting">确定</el-button>
      </template>
    </el-dialog>

    <!-- 权限配置弹窗（树形结构） -->
    <el-dialog v-model="permissionVisible" title="配置权限" width="600px">
      <el-tree
        ref="menuTreeRef"
        :data="menuTree"
        :props="{ label: 'name', children: 'children' }"
        node-key="id"
        :default-expand-all="true"
        show-checkbox
      />
      <template #footer>
        <el-button @click="permissionVisible = false">取消</el-button>
        <el-button type="primary" @click="handlePermissionSubmit" :loading="submitting">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
/**
 * 角色管理页面组件
 * 管理员使用的角色管理界面，支持角色列表查看、新增、编辑、删除、权限配置
 * 超级管理员角色（ID=1）不可删除
 */
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { roleApi } from '../api'

// 加载状态
const loading = ref(false)
// 角色列表数据
const roleList = ref([])
// 是否有管理权限
const canManage = ref(true)
// 当前选中的角色（用于权限配置）
const currentRole = ref(null)

// 弹窗相关
const dialogVisible = ref(false)       // 角色编辑弹窗显示状态
const permissionVisible = ref(false)   // 权限配置弹窗显示状态
const isEdit = ref(false)              // 是否为编辑模式
const submitting = ref(false)          // 提交中状态
const formRef = ref(null)              // 表单引用
const menuTree = ref([])               // 菜单树数据（权限树）
const menuTreeRef = ref(null)          // 菜单树引用

// 角色表单数据
const roleForm = ref({
  id: null,
  name: '',
  roleKey: '',
  description: '',
  status: 1
})

// 表单验证规则
const rules = {
  name: [{ required: true, message: '请输入角色名称', trigger: 'blur' }],
  roleKey: [{ required: true, message: '请输入角色标识', trigger: 'blur' }]
}

/**
 * 获取角色列表
 * 注：后端接口未实现时使用模拟数据
 */
const getRoleList = async () => {
  loading.value = true
  try {
    const data = await roleApi.list()
    roleList.value = data || []
  } catch (err) {
    console.error('获取角色列表失败:', err)
    // 后端接口未实现时使用模拟数据
    roleList.value = [
      { id: 1, name: '超级管理员', roleKey: 'admin', description: '系统超级管理员，拥有所有权限', userCount: 1, status: 1 },
      { id: 2, name: '审核员', roleKey: 'auditor', description: '负责审核文章和评论', userCount: 1, status: 1 },
      { id: 3, name: '编辑', roleKey: 'editor', description: '负责文章编辑和发布', userCount: 0, status: 1 },
      { id: 4, name: '普通用户', roleKey: 'user', description: '普通用户，只能浏览和评论', userCount: 0, status: 1 }
    ]
  } finally {
    loading.value = false
  }
}

/**
 * 获取菜单树数据（权限树）
 * 模拟后端返回的菜单数据，用于权限配置
 */
const getMenuTree = () => {
  menuTree.value = [
    {
      id: 1,
      name: '首页',
      children: []
    },
    {
      id: 2,
      name: '文章管理',
      children: [
        { id: 21, name: '文章列表' },
        { id: 22, name: '发布文章' },
        { id: 23, name: '文章管理' }
      ]
    },
    {
      id: 3,
      name: '新闻管理',
      children: [
        { id: 31, name: '新闻列表' },
        { id: 32, name: '发布新闻' },
        { id: 33, name: '新闻管理' }
      ]
    },
    {
      id: 4,
      name: '栏目管理',
      children: [
        { id: 41, name: '栏目列表' }
      ]
    },
    {
      id: 5,
      name: '内容审核',
      children: [
        { id: 51, name: '文章审核' },
        { id: 52, name: '评论审核' }
      ]
    },
    {
      id: 6,
      name: '互动管理',
      children: []
    },
    {
      id: 7,
      name: '系统设置',
      children: [
        { id: 71, name: '用户管理' },
        { id: 72, name: '角色管理' }
      ]
    }
  ]
}

/**
 * 新增角色（打开弹窗）
 */
const handleAdd = () => {
  isEdit.value = false
  roleForm.value = { id: null, name: '', roleKey: '', description: '', status: 1 }
  dialogVisible.value = true
}

/**
 * 编辑角色（打开弹窗）
 * @param {Object} row - 角色数据
 */
const handleEdit = (row) => {
  isEdit.value = true
  roleForm.value = { ...row }
  dialogVisible.value = true
}

/**
 * 提交表单（新增或编辑）
 */
const handleSubmit = async () => {
  // 表单验证
  await formRef.value.validate()
  submitting.value = true
  try {
    if (isEdit.value) {
      // 编辑模式
      await roleApi.update(roleForm.value)
      ElMessage.success('更新成功')
    } else {
      // 新增模式
      await roleApi.add(roleForm.value)
      ElMessage.success('添加成功')
    }
    dialogVisible.value = false
    getRoleList()
  } catch (err) {
    console.error('操作失败:', err)
  } finally {
    submitting.value = false
  }
}

/**
 * 删除角色（带确认，超级管理员不可删除）
 * @param {Object} row - 角色数据
 */
const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要删除角色【${row.name}】吗？`, '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await roleApi.delete(row.id)
    ElMessage.success('删除成功')
    getRoleList()
  } catch (err) {
    if (err !== 'cancel') {
      console.error('删除失败:', err)
    }
  }
}

/**
 * 配置权限（打开权限配置弹窗）
 * @param {Object} row - 角色数据
 */
const handlePermission = async (row) => {
  currentRole.value = row
  try {
    // 获取该角色已有的权限
    const permissions = await roleApi.getPermissions(row.id)
    if (permissions && menuTreeRef.value) {
      menuTreeRef.value.setCheckedKeys(permissions)
    }
  } catch (err) {
    console.error('获取权限失败:', err)
  }
  permissionVisible.value = true
}

/**
 * 提交权限配置
 */
const handlePermissionSubmit = async () => {
  submitting.value = true
  try {
    if (menuTreeRef.value && currentRole.value) {
      // 获取选中的权限ID列表
      const checkedKeys = menuTreeRef.value.getCheckedKeys()
      await roleApi.setPermissions({ roleId: currentRole.value.id, permissionIds: checkedKeys })
    }
    ElMessage.success('权限配置成功')
    permissionVisible.value = false
  } catch (err) {
    console.error('配置失败:', err)
    ElMessage.error('权限配置失败，可能后端接口未实现')
  } finally {
    submitting.value = false
  }
}

/**
 * 页面挂载时获取角色列表和菜单树数据
 */
onMounted(() => {
  getRoleList()
  getMenuTree()
})
</script>

<style scoped>
.role-manage-container {
  padding: 0;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.title {
  font-size: 16px;
  font-weight: 600;
}
</style>
