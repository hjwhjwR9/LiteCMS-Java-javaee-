<template>
  <!-- 互动管理页面容器 -->
  <div class="interaction-container">
    <!-- 统计卡片区域（总览数据） -->
    <el-row :gutter="16" class="stat-cards">
      <!-- 总点赞数卡片 -->
      <el-col :span="6">
        <div class="stat-card stat-likes" @click="goTo('likes')">
          <div class="stat-icon"><el-icon><Star /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ formatNumber(stats.totalLikes) }}</div>
            <div class="stat-label">总点赞数</div>
            <div class="stat-trend">
              <el-icon><Top /></el-icon> 较昨日 -
            </div>
          </div>
        </div>
      </el-col>
      <!-- 总评论数卡片 -->
      <el-col :span="6">
        <div class="stat-card stat-comments" @click="goTo('comments')">
          <div class="stat-icon"><el-icon><ChatLineSquare /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ formatNumber(stats.totalComments) }}</div>
            <div class="stat-label">总评论数</div>
            <div class="stat-trend">
              <el-icon><Top /></el-icon> 较昨日 -
            </div>
          </div>
        </div>
      </el-col>
      <!-- 总浏览量卡片 -->
      <el-col :span="6">
        <div class="stat-card stat-views" @click="goTo('views')">
          <div class="stat-icon"><el-icon><View /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ formatNumber(stats.totalViews) }}</div>
            <div class="stat-label">总浏览量</div>
            <div class="stat-trend">
              <el-icon><Top /></el-icon> 较昨日 -
            </div>
          </div>
        </div>
      </el-col>
      <!-- 文章总数卡片 -->
      <el-col :span="6">
        <div class="stat-card stat-articles" @click="goTo('articles')">
          <div class="stat-icon"><el-icon><Document /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ formatNumber(stats.totalArticles) }}</div>
            <div class="stat-label">文章总数</div>
            <div class="stat-trend">
              <el-icon><Top /></el-icon> 较昨日 -
            </div>
          </div>
        </div>
      </el-col>
    </el-row>

    <!-- 排行榜区域（点赞排行和评论排行） -->
    <el-row :gutter="16" class="mt-4">
      <!-- 点赞排行榜 -->
      <el-col :span="12">
        <el-card shadow="never" class="rank-card">
          <template #header>
            <div class="card-header">
              <div class="header-left">
                <el-icon class="header-icon" color="#f56c6c"><Star /></el-icon>
                <span class="title">点赞排行榜 TOP10</span>
              </div>
              <el-tag size="small" type="danger" effect="plain">
                <el-icon><Trophy /></el-icon> 热门内容
              </el-tag>
            </div>
          </template>
          <!-- 点赞排行列表 -->
          <div v-loading="loading" class="rank-list">
            <el-empty v-if="!loading && likeRankList.length === 0" description="暂无数据" :image-size="80" />
            <div v-for="(item, index) in likeRankList" :key="item.id" class="rank-item" @click="goArticle(item.id)">
              <div class="rank-num" :class="`rank-${index + 1}`">{{ index + 1 }}</div>
              <div class="rank-cover">
                <el-image :src="item.coverUrl || getPlaceholder(item.id)" fit="cover">
                  <template #error>
                    <div class="rank-cover-error"><el-icon><Picture /></el-icon></div>
                  </template>
                </el-image>
              </div>
              <div class="rank-info">
                <div class="rank-title line-clamp-1">{{ item.title }}</div>
                <div class="rank-meta">
                  <span><el-icon><User /></el-icon> {{ item.authorNickname || '匿名' }}</span>
                  <span><el-icon><Star /></el-icon> {{ item.likeCount || 0 }}</span>
                </div>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- 评论排行榜 -->
      <el-col :span="12">
        <el-card shadow="never" class="rank-card">
          <template #header>
            <div class="card-header">
              <div class="header-left">
                <el-icon class="header-icon" color="#409eff"><ChatLineSquare /></el-icon>
                <span class="title">评论排行榜 TOP10</span>
              </div>
              <el-tag size="small" type="primary" effect="plain">
                <el-icon><ChatDotRound /></el-icon> 活跃话题
              </el-tag>
            </div>
          </template>
          <!-- 评论排行列表 -->
          <div v-loading="loading" class="rank-list">
            <el-empty v-if="!loading && commentRankList.length === 0" description="暂无数据" :image-size="80" />
            <div v-for="(item, index) in commentRankList" :key="item.id" class="rank-item" @click="goArticle(item.id)">
              <div class="rank-num" :class="`rank-${index + 1}`">{{ index + 1 }}</div>
              <div class="rank-cover">
                <el-image :src="item.coverUrl || getPlaceholder(item.id)" fit="cover">
                  <template #error>
                    <div class="rank-cover-error"><el-icon><Picture /></el-icon></div>
                  </template>
                </el-image>
              </div>
              <div class="rank-info">
                <div class="rank-title line-clamp-1">{{ item.title }}</div>
                <div class="rank-meta">
                  <span><el-icon><User /></el-icon> {{ item.authorNickname || '匿名' }}</span>
                  <span><el-icon><ChatDotRound /></el-icon> {{ item.commentCount || 0 }}</span>
                </div>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 浏览量排行榜（表格形式） -->
    <el-card shadow="never" class="mt-4 view-rank-card">
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <el-icon class="header-icon" color="#e6a23c"><View /></el-icon>
            <span class="title">浏览量排行榜 TOP10</span>
          </div>
          <el-tag size="small" type="warning" effect="plain">
            <el-icon><DataLine /></el-icon> 流量数据
          </el-tag>
        </div>
      </template>
      <!-- 浏览量排行表格 -->
      <el-table :data="viewRankList" v-loading="loading" stripe :max-height="400">
        <!-- 排名列（带奖牌样式） -->
        <el-table-column type="index" label="排名" width="80" align="center">
          <template #default="{ $index }">
            <div class="rank-badge" :class="`rank-${$index + 1}`">{{ $index + 1 }}</div>
          </template>
        </el-table-column>
        <!-- 封面列（支持预览） -->
        <el-table-column label="封面" width="110" align="center">
          <template #default="{ row }">
            <el-image
              :src="row.coverUrl || getPlaceholder(row.id)"
              fit="cover"
              style="width: 90px; height: 56px; border-radius: 4px"
              :preview-src-list="row.coverUrl ? [row.coverUrl] : []"
              preview-teleported
            >
              <template #error>
                <div class="image-placeholder">
                  <el-icon><Picture /></el-icon>
                </div>
              </template>
            </el-image>
          </template>
        </el-table-column>
        <!-- 文章标题列（可点击跳转详情） -->
        <el-table-column prop="title" label="文章标题" min-width="240" show-overflow-tooltip>
          <template #default="{ row }">
            <span class="article-title" @click="goArticle(row.id)">{{ row.title }}</span>
          </template>
        </el-table-column>
        <!-- 浏览量列（可排序） -->
        <el-table-column prop="viewCount" label="浏览量" width="120" align="center" sortable>
          <template #default="{ row }">
            <span class="data-text views">
              <el-icon><View /></el-icon> {{ formatNumber(row.viewCount) }}
            </span>
          </template>
        </el-table-column>
        <!-- 点赞数列 -->
        <el-table-column prop="likeCount" label="点赞" width="100" align="center">
          <template #default="{ row }">
            <span class="data-text likes">
              <el-icon><Star /></el-icon> {{ formatNumber(row.likeCount) }}
            </span>
          </template>
        </el-table-column>
        <!-- 评论数列 -->
        <el-table-column prop="commentCount" label="评论" width="100" align="center">
          <template #default="{ row }">
            <span class="data-text comments">
              <el-icon><ChatDotRound /></el-icon> {{ formatNumber(row.commentCount) }}
            </span>
          </template>
        </el-table-column>
        <!-- 状态列 -->
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)" size="small">{{ getStatusText(row.status) }}</el-tag>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
/**
 * 互动管理页面组件
 * 展示平台互动数据统计和排行榜（点赞、评论、浏览量TOP10）
 * 通过统计卡片和排行榜帮助管理员了解热门内容和用户互动情况
 */
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { articleApi } from '../api'

// 路由实例
const router = useRouter()

// 加载状态
const loading = ref(false)

// 统计数据（总点赞数、总评论数、总浏览量、文章总数）
const stats = ref({
  totalLikes: 0,
  totalComments: 0,
  totalViews: 0,
  totalArticles: 0
})

// 排行榜数据
const likeRankList = ref([])     // 点赞排行榜 TOP10
const commentRankList = ref([])  // 评论排行榜 TOP10
const viewRankList = ref([])     // 浏览量排行榜 TOP10

// 状态映射表（文章状态：0=草稿, 1=待审核, 2=已通过, 3=已驳回, 4=已下架）
const statusMap = { 0: '草稿', 1: '待审核', 2: '已通过', 3: '已驳回', 4: '已下架' }
const statusTypeMap = { 0: 'info', 1: 'warning', 2: 'success', 3: 'danger', 4: 'warning' }

/**
 * 获取状态文本
 * @param {number} status - 状态码
 * @returns {string} 状态名称
 */
const getStatusText = (status) => statusMap[status] || '未知'

/**
 * 获取状态对应的标签类型
 * @param {number} status - 状态码
 * @returns {string} Element Plus标签类型
 */
const getStatusType = (status) => statusTypeMap[status] || 'info'

/**
 * 获取封面占位图（基于ID生成固定图片）
 * @param {number} id - 文章ID
 * @returns {string} 占位图URL
 */
const getPlaceholder = (id) => `https://picsum.photos/seed/${id}/120/72`

/**
 * 格式化数字（大于1万显示为w单位）
 * @param {number} num - 原始数字
 * @returns {string} 格式化后的数字字符串
 */
const formatNumber = (num) => {
  if (num === null || num === undefined) return 0
  return num >= 10000 ? (num / 10000).toFixed(1) + 'w' : num.toLocaleString()
}

/**
 * 点击统计卡片跳转对应页面
 * @param {string} type - 类型（likes/comments/views/articles）
 */
const goTo = (type) => {
  if (type === 'likes') router.push('/article/manage')
  else if (type === 'comments') router.push('/comment/manage')
  else if (type === 'views') router.push('/article/manage')
  else if (type === 'articles') router.push('/article/manage')
}

/**
 * 跳转到文章详情页
 * @param {number} id - 文章ID
 */
const goArticle = (id) => {
  router.push(`/article/${id}`)
}

/**
 * 获取统计数据和排行榜数据
 * 通过文章列表API获取前200条数据，前端计算统计和排行
 */
const getStats = async () => {
  loading.value = true
  try {
    // 获取文章列表（最多200条）
    const result = await articleApi.list({ pageNum: 1, pageSize: 200 })
    const list = result?.records || []

    // 计算总统计数据
    let totalLikes = 0, totalComments = 0, totalViews = 0
    list.forEach(item => {
      totalLikes += item.likeCount || 0
      totalComments += item.commentCount || 0
      totalViews += item.viewCount || 0
    })

    // 更新统计数据
    stats.value = {
      totalLikes,
      totalComments,
      totalViews,
      totalArticles: result?.total || list.length
    }

    // 计算点赞排行榜 TOP10
    likeRankList.value = [...list]
      .sort((a, b) => (b.likeCount || 0) - (a.likeCount || 0))
      .slice(0, 10)

    // 计算评论排行榜 TOP10
    commentRankList.value = [...list]
      .sort((a, b) => (b.commentCount || 0) - (a.commentCount || 0))
      .slice(0, 10)

    // 计算浏览量排行榜 TOP10
    viewRankList.value = [...list]
      .sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0))
      .slice(0, 10)
  } catch (err) {
    console.error('获取统计数据失败:', err)
  } finally {
    loading.value = false
  }
}

/**
 * 页面挂载时获取统计数据
 */
onMounted(() => {
  getStats()
})
</script>

<style scoped>
.interaction-container {
  padding: 0;
}

/* 统计卡片 */
.stat-cards {
  margin-bottom: 16px;
}

.stat-card {
  display: flex;
  align-items: center;
  padding: 20px;
  background: #fff;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s;
  border: 1px solid #ebeef5;
  position: relative;
  overflow: hidden;
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
}

.stat-icon {
  width: 64px;
  height: 64px;
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30px;
  margin-right: 16px;
  flex-shrink: 0;
}

.stat-likes .stat-icon { background: linear-gradient(135deg, #fef0f0, #fbc4c4); color: #f56c6c; }
.stat-comments .stat-icon { background: linear-gradient(135deg, #ecf5ff, #b3d8ff); color: #409eff; }
.stat-views .stat-icon { background: linear-gradient(135deg, #fdf6ec, #faecd8); color: #e6a23c; }
.stat-articles .stat-icon { background: linear-gradient(135deg, #f0f9eb, #c6e2bc); color: #67c23a; }

.stat-info {
  flex: 1;
  min-width: 0;
}

.stat-value {
  font-size: 28px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-label {
  font-size: 14px;
  color: #909399;
  margin-top: 4px;
}

.stat-trend {
  font-size: 12px;
  color: #67c23a;
  margin-top: 6px;
  display: flex;
  align-items: center;
  gap: 2px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.header-icon {
  font-size: 18px;
}

.title {
  font-size: 16px;
  font-weight: 600;
}

/* 排行榜卡片 */
.rank-card, .view-rank-card {
  border-radius: 8px;
}

.rank-list {
  max-height: 480px;
  overflow-y: auto;
}

.rank-item {
  display: flex;
  align-items: center;
  padding: 12px 8px;
  border-bottom: 1px solid #f5f7fa;
  cursor: pointer;
  transition: all 0.2s;
  border-radius: 4px;
}

.rank-item:hover {
  background: #ecf5ff;
  transform: translateX(4px);
}

.rank-item:last-child {
  border-bottom: none;
}

.rank-num {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  font-weight: bold;
  color: #909399;
  background: #f5f7fa;
  margin-right: 12px;
  flex-shrink: 0;
}

.rank-1 { background: linear-gradient(135deg, #ffd700, #ffb700); color: #fff; }
.rank-2 { background: linear-gradient(135deg, #c0c4cc, #909399); color: #fff; }
.rank-3 { background: linear-gradient(135deg, #cd7f32, #b87333); color: #fff; }

.rank-cover {
  width: 60px;
  height: 40px;
  border-radius: 4px;
  overflow: hidden;
  margin-right: 12px;
  flex-shrink: 0;
}

.rank-cover :deep(.el-image) {
  width: 100%;
  height: 100%;
}

.rank-cover-error {
  width: 100%;
  height: 100%;
  background: #f5f7fa;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #c0c4cc;
}

.rank-info {
  flex: 1;
  min-width: 0;
}

.rank-title {
  font-size: 14px;
  color: #303133;
  font-weight: 500;
  margin-bottom: 4px;
  transition: color 0.2s;
}

.rank-item:hover .rank-title {
  color: #409eff;
}

.rank-meta {
  display: flex;
  gap: 12px;
  font-size: 12px;
  color: #909399;
}

.rank-meta span {
  display: flex;
  align-items: center;
  gap: 3px;
}

/* 浏览量表格 */
.rank-badge {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  margin: 0 auto;
  color: #909399;
  background: #f5f7fa;
  font-size: 13px;
}

.article-title {
  cursor: pointer;
  color: #303133;
  font-weight: 500;
  transition: color 0.2s;
}

.article-title:hover {
  color: #409eff;
}

.data-text {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-weight: 600;
}

.data-text.views { color: #e6a23c; }
.data-text.likes { color: #f56c6c; }
.data-text.comments { color: #409eff; }

.image-placeholder {
  width: 90px;
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  border-radius: 4px;
  color: #c0c4cc;
}

.mt-4 {
  margin-top: 16px;
}

.line-clamp-1 {
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
