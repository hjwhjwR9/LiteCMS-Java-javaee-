<template>
  <!-- 用户管理页面容器 -->
  <div class="user-manage-container">
    <el-card>
      <!-- 卡片头部 -->
      <template #header>
        <div class="card-header">
          <span class="title">用户管理</span>
          <!-- 新增用户按钮 -->
          <el-button type="primary" @click="handleAdd">
            <el-icon><Plus /></el-icon> 新增用户
          </el-button>
        </div>
      </template>

      <!-- 筛选条件区域 -->
      <div class="filter-bar">
        <!-- 关键词搜索（用户名/昵称） -->
        <el-input
          v-model="searchKeyword"
          placeholder="搜索用户名/昵称"
          prefix-icon="Search"
          style="width: 200px; margin-right: 12px"
          clearable
          @clear="handleSearch"
          @keyup.enter="handleSearch"
        />
        <!-- 角色筛选 -->
        <el-select v-model="searchRole" placeholder="角色筛选" clearable style="width: 120px; margin-right: 12px" @change="handleSearch">
          <el-option label="全部" :value="''" />
          <el-option label="普通用户" :value="0" />
          <el-option label="审核员" :value="1" />
          <el-option label="管理员" :value="2" />
        </el-select>
        <!-- 状态筛选 -->
        <el-select v-model="searchStatus" placeholder="状态筛选" clearable style="width: 120px; margin-right: 12px" @change="handleSearch">
          <el-option label="全部" :value="''" />
          <el-option label="正常" :value="1" />
          <el-option label="禁用" :value="0" />
        </el-select>
        <!-- 重置按钮 -->
        <el-button @click="handleReset">重置</el-button>
      </div>

      <!-- 用户列表表格 -->
      <el-table :data="userList" v-loading="loading" stripe border>
        <!-- ID列 -->
        <el-table-column prop="id" label="ID" width="80" />
        <!-- 头像列 -->
        <el-table-column label="头像" width="80">
          <template #default="{ row }">
            <el-avatar :size="40" :src="row.avatarUrl">
              {{ row.nickname?.charAt(0) || row.username?.charAt(0) || 'U' }}
            </el-avatar>
          </template>
        </el-table-column>
        <!-- 用户名列 -->
        <el-table-column prop="username" label="用户名" width="120" />
        <!-- 昵称列 -->
        <el-table-column prop="nickname" label="昵称" width="120" />
        <!-- 角色列（标签显示） -->
        <el-table-column label="角色" width="100">
          <template #default="{ row }">
            <el-tag :type="getRoleType(row.role)">{{ getRoleText(row.role) }}</el-tag>
          </template>
        </el-table-column>
        <!-- 状态列（开关切换） -->
        <el-table-column label="状态" width="80">
          <template #default="{ row }">
            <el-switch
              v-model="row.status"
              :active-value="1"
              :inactive-value="0"
              @change="handleStatusChange(row)"
            />
          </template>
        </el-table-column>
        <!-- 最后登录时间 -->
        <el-table-column prop="lastLoginAt" label="最后登录" width="160">
          <template #default="{ row }">
            {{ row.lastLoginAt ? formatTime(row.lastLoginAt) : '-' }}
          </template>
        </el-table-column>
        <!-- 注册时间 -->
        <el-table-column prop="createdAt" label="注册时间" width="160">
          <template #default="{ row }">
            {{ formatTime(row.createdAt) }}
          </template>
        </el-table-column>
        <!-- 操作列（编辑/删除，管理员不可删除） -->
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button size="small" type="primary" @click="handleEdit(row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(row)" :disabled="row.role === 2">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页组件 -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>

    <!-- 用户编辑/新增弹窗 -->
    <el-dialog v-model="dialogVisible" :title="isEdit ? '编辑用户' : '新增用户'" width="500px">
      <el-form :model="userForm" :rules="rules" ref="formRef" label-width="80px">
        <!-- 用户名（编辑时不可修改） -->
        <el-form-item label="用户名" prop="username">
          <el-input v-model="userForm.username" :disabled="isEdit" placeholder="请输入用户名" />
        </el-form-item>
        <!-- 昵称 -->
        <el-form-item label="昵称" prop="nickname">
          <el-input v-model="userForm.nickname" placeholder="请输入昵称" />
        </el-form-item>
        <!-- 密码（编辑时可选） -->
        <el-form-item label="密码" :prop="isEdit ? '' : 'password'">
          <el-input v-model="userForm.password" type="password" :placeholder="isEdit ? '留空则不修改密码' : '请输入密码'" show-password />
        </el-form-item>
        <!-- 角色选择 -->
        <el-form-item label="角色" prop="role">
          <el-select v-model="userForm.role" placeholder="请选择角色" style="width: 100%">
            <el-option label="普通用户" :value="0" />
            <el-option label="审核员" :value="1" />
            <el-option label="管理员" :value="2" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit" :loading="submitting">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
/**
 * 用户管理页面组件
 * 管理员使用的用户管理界面，支持用户列表查看、新增、编辑、删除、状态切换
 * 支持按用户名/昵称搜索、角色筛选、状态筛选
 */
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { format } from 'date-fns'
import { userApi } from '../api'

// 加载状态
const loading = ref(false)
// 用户列表数据
const userList = ref([])
// 当前页码
const currentPage = ref(1)
// 每页条数
const pageSize = ref(10)
// 总条数
const total = ref(0)

// 筛选条件
const searchKeyword = ref('')  // 关键词（用户名/昵称）
const searchRole = ref('')     // 角色筛选
const searchStatus = ref('')   // 状态筛选

// 弹窗相关
const dialogVisible = ref(false)  // 弹窗显示状态
const isEdit = ref(false)         // 是否为编辑模式
const submitting = ref(false)     // 提交中状态
const formRef = ref(null)         // 表单引用

// 用户表单数据
const userForm = ref({
  id: null,
  username: '',
  nickname: '',
  password: '',
  role: 0
})

// 表单验证规则
const rules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  nickname: [{ required: true, message: '请输入昵称', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }, { min: 6, message: '密码至少6位', trigger: 'blur' }],
  role: [{ required: true, message: '请选择角色', trigger: 'change' }]
}

// 角色映射表（角色：0=普通用户, 1=审核员, 2=管理员）
const roleMap = { 0: '普通用户', 1: '审核员', 2: '管理员' }
const roleTypeMap = { 0: '', 1: 'warning', 2: 'danger' }

/**
 * 获取角色文本
 * @param {number} role - 角色码
 * @returns {string} 角色名称
 */
const getRoleText = (role) => roleMap[role] || '未知'

/**
 * 获取角色对应的标签类型
 * @param {number} role - 角色码
 * @returns {string} Element Plus标签类型
 */
const getRoleType = (role) => roleTypeMap[role] || ''

/**
 * 格式化时间
 * @param {string} time - ISO时间字符串
 * @returns {string} 格式化后的时间（yyyy-MM-dd HH:mm）
 */
const formatTime = (time) => {
  return time ? format(new Date(time), 'yyyy-MM-dd HH:mm') : '-'
}

/**
 * 获取用户列表（分页）
 */
const getUserList = async () => {
  loading.value = true
  try {
    const params = {
      pageNum: currentPage.value,
      pageSize: pageSize.value
    }
    // 添加关键词筛选
    if (searchKeyword.value) {
      params.keyword = searchKeyword.value
    }
    // 添加角色筛选
    if (searchRole.value !== '') {
      params.role = searchRole.value
    }
    // 添加状态筛选
    if (searchStatus.value !== '') {
      params.status = searchStatus.value
    }

    const result = await userApi.list(params)
    const pageResult = result || {}
    userList.value = pageResult.records || []
    total.value = pageResult.total || 0
  } catch (err) {
    console.error('获取用户列表失败:', err)
  } finally {
    loading.value = false
  }
}

/**
 * 处理搜索
 */
const handleSearch = () => {
  currentPage.value = 1
  getUserList()
}

/**
 * 重置筛选条件
 */
const handleReset = () => {
  searchKeyword.value = ''
  searchRole.value = ''
  searchStatus.value = ''
  currentPage.value = 1
  getUserList()
}

/**
 * 处理页码变化
 * @param {number} page - 新页码
 */
const handlePageChange = (page) => {
  currentPage.value = page
  getUserList()
}

/**
 * 处理每页条数变化
 * @param {number} size - 新的每页条数
 */
const handleSizeChange = (size) => {
  pageSize.value = size
  getUserList()
}

/**
 * 新增用户（打开弹窗）
 */
const handleAdd = () => {
  isEdit.value = false
  userForm.value = { id: null, username: '', nickname: '', password: '', role: 0 }
  dialogVisible.value = true
}

/**
 * 编辑用户（打开弹窗）
 * @param {Object} row - 用户数据
 */
const handleEdit = (row) => {
  isEdit.value = true
  userForm.value = {
    id: row.id,
    username: row.username,
    nickname: row.nickname,
    password: '',  // 编辑时密码留空表示不修改
    role: row.role
  }
  dialogVisible.value = true
}

/**
 * 提交表单（新增或编辑）
 */
const handleSubmit = async () => {
  // 表单验证
  await formRef.value.validate()
  submitting.value = true
  try {
    if (isEdit.value) {
      // 编辑模式：不传空密码
      const submitData = { ...userForm.value }
      if (!submitData.password) {
        delete submitData.password
      }
      await userApi.update(submitData)
      ElMessage.success('更新成功')
    } else {
      // 新增模式：直接提交
      await userApi.register(userForm.value)
      ElMessage.success('添加成功')
    }
    dialogVisible.value = false
    getUserList()
  } catch (err) {
    console.error('操作失败:', err)
  } finally {
    submitting.value = false
  }
}

/**
 * 删除用户（带确认）
 * @param {Object} row - 用户数据
 */
const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要删除用户【${row.nickname || row.username}】吗？`, '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await userApi.delete(row.id)
    ElMessage.success('删除成功')
    getUserList()
  } catch (err) {
    if (err !== 'cancel') {
      console.error('删除失败:', err)
    }
  }
}

/**
 * 状态切换（启用/禁用）
 * @param {Object} row - 用户数据
 */
const handleStatusChange = async (row) => {
  try {
    await userApi.updateStatus({ id: row.id, status: row.status })
    ElMessage.success(row.status === 1 ? '已启用' : '已禁用')
  } catch (err) {
    // 操作失败时恢复原状态
    row.status = row.status === 1 ? 0 : 1
    console.error('修改状态失败:', err)
  }
}

/**
 * 页面挂载时获取用户列表
 */
onMounted(() => {
  getUserList()
})
</script>

<style scoped>
.user-manage-container {
  padding: 0;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.title {
  font-size: 16px;
  font-weight: 600;
}

.filter-bar {
  margin-bottom: 16px;
  display: flex;
  align-items: center;
}

.pagination-wrapper {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>
