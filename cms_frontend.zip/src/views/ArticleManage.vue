<template>
  <!-- 文章管理页面容器 -->
  <el-card shadow="never" class="article-manage-container">
    <!-- 卡片头部 -->
    <template #header>
      <div class="card-header">
        <!-- 左侧标题区 -->
        <div class="header-left">
          <el-icon class="header-icon"><Document /></el-icon>
          <span class="title">我的文章</span>
          <el-tag size="small" type="info" effect="plain">共 {{ total }} 篇</el-tag>
        </div>
        <!-- 新增文章按钮 -->
        <el-button type="primary" @click="toAdd">
          <el-icon><Plus /></el-icon> 新增文章
        </el-button>
      </div>
    </template>

    <!-- 统计卡片 -->
    <el-row :gutter="16" class="stat-row">
      <!-- 草稿统计 -->
      <el-col :span="6">
        <div class="stat-card stat-0" @click="quickFilter(0)">
          <el-icon class="stat-icon"><DocumentCopy /></el-icon>
          <div class="stat-content">
            <div class="stat-value">{{ stats.draft }}</div>
            <div class="stat-label">草稿</div>
          </div>
        </div>
      </el-col>
      <!-- 待审核统计 -->
      <el-col :span="6">
        <div class="stat-card stat-1" @click="quickFilter(1)">
          <el-icon class="stat-icon"><Clock /></el-icon>
          <div class="stat-content">
            <div class="stat-value">{{ stats.pending }}</div>
            <div class="stat-label">待审核</div>
          </div>
        </div>
      </el-col>
      <!-- 已发布统计 -->
      <el-col :span="6">
        <div class="stat-card stat-2" @click="quickFilter(2)">
          <el-icon class="stat-icon"><CircleCheck /></el-icon>
          <div class="stat-content">
            <div class="stat-value">{{ stats.published }}</div>
            <div class="stat-label">已发布</div>
          </div>
        </div>
      </el-col>
      <!-- 已驳回统计 -->
      <el-col :span="6">
        <div class="stat-card stat-3" @click="quickFilter(3)">
          <el-icon class="stat-icon"><CircleClose /></el-icon>
          <div class="stat-content">
            <div class="stat-value">{{ stats.rejected }}</div>
            <div class="stat-label">已驳回</div>
          </div>
        </div>
      </el-col>
    </el-row>

    <!-- 筛选栏 -->
    <div class="filter-bar">
      <!-- 搜索输入框 -->
      <el-input
        v-model="searchKeyword"
        placeholder="搜索文章标题"
        prefix-icon="Search"
        style="width: 220px; margin-right: 12px"
        clearable
        @clear="handleFilterChange"
        @keyup.enter="handleFilterChange"
      />
      <!-- 状态筛选 -->
      <el-select v-model="filterStatus" placeholder="状态筛选" clearable style="width: 120px; margin-right: 12px" @change="handleFilterChange">
        <el-option label="草稿" :value="0" />
        <el-option label="待审核" :value="1" />
        <el-option label="已发布" :value="2" />
        <el-option label="已驳回" :value="3" />
      </el-select>
      <!-- 栏目筛选 -->
      <el-select v-model="filterCategory" placeholder="栏目筛选" clearable style="width: 150px; margin-right: 12px" @change="handleFilterChange">
        <el-option v-for="cat in categories" :key="cat.id" :label="cat.name" :value="cat.id" />
      </el-select>
      <!-- 重置按钮 -->
      <el-button @click="handleReset">
        <el-icon><RefreshLeft /></el-icon> 重置
      </el-button>
    </div>

    <!-- 文章列表表格 -->
    <el-table
      :data="articleList"
      v-loading="loading"
      stripe
      border
      :max-height="tableHeight"
      empty-text="暂无文章"
    >
      <!-- 序号列 -->
      <el-table-column type="index" label="#" width="55" align="center" />
      <!-- 封面列 -->
      <el-table-column label="封面" width="100" align="center">
        <template #default="{ row }">
          <el-image
            :src="row.coverUrl || getPlaceholder(row.id)"
            fit="cover"
            style="width: 80px; height: 50px; border-radius: 4px"
            :preview-src-list="row.coverUrl ? [row.coverUrl] : []"
            preview-teleported
          >
            <template #error>
              <div class="image-placeholder">
                <el-icon><Picture /></el-icon>
              </div>
            </template>
          </el-image>
        </template>
      </el-table-column>
      <!-- 标题列 -->
      <el-table-column prop="title" label="文章标题" min-width="220" show-overflow-tooltip>
        <template #default="{ row }">
          <span class="article-title" @click="toDetail(row.id)">{{ row.title }}</span>
        </template>
      </el-table-column>
      <!-- 栏目列 -->
      <el-table-column prop="categoryName" label="所属栏目" width="110" align="center">
        <template #default="{ row }">
          <el-tag v-if="row.categoryName" size="small" effect="plain">{{ row.categoryName }}</el-tag>
          <span v-else>-</span>
        </template>
      </el-table-column>
      <!-- 状态列 -->
      <el-table-column label="状态" width="100" align="center">
        <template #default="{ row }">
          <el-tag :type="getStatusType(row.status)" size="small">{{ getStatusText(row.status) }}</el-tag>
        </template>
      </el-table-column>
      <!-- 数据统计列 -->
      <el-table-column label="数据" width="170" align="center">
        <template #default="{ row }">
          <div class="data-cell">
            <span class="data-item"><el-icon><View /></el-icon> {{ row.viewCount || 0 }}</span>
            <span class="data-item"><el-icon><Star /></el-icon> {{ row.likeCount || 0 }}</span>
            <span class="data-item"><el-icon><ChatDotRound /></el-icon> {{ row.commentCount || 0 }}</span>
          </div>
        </template>
      </el-table-column>
      <!-- 创建时间列 -->
      <el-table-column prop="createdAt" label="创建时间" width="170" align="center">
        <template #default="{ row }">
          <span class="time-text">{{ formatTime(row.createdAt) }}</span>
        </template>
      </el-table-column>
      <!-- 操作列 -->
      <el-table-column label="操作" width="220" fixed="right" align="center">
        <template #default="{ row }">
          <el-button size="small" type="primary" link @click="toEdit(row.id)">编辑</el-button>
          <el-button size="small" type="success" link @click="handlePublish(row)" v-if="row.status === 0 || row.status === 3">提交审核</el-button>
          <el-button size="small" type="warning" link @click="handleOffline(row)" v-if="row.status === 2">下架</el-button>
          <el-button size="small" type="danger" link @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页组件 -->
    <div class="pagination-wrapper">
      <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next, jumper"
        background
        @size-change="handleSizeChange"
        @current-change="handlePageChange"
      />
    </div>
  </el-card>
</template>

<script setup>
/**
 * 文章管理页面组件
 * 管理自己发布的文章，支持新增、编辑、提交审核、下架、删除等操作
 * 包含统计卡片、状态筛选等功能
 */
import { ref, onMounted, onUnmounted, getCurrentInstance } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { format } from 'date-fns'

const { proxy } = getCurrentInstance()
const router = useRouter()

// 加载状态
const loading = ref(false)
// 文章列表数据
const articleList = ref([])
// 栏目列表
const categories = ref([])
// 当前页码
const currentPage = ref(1)
// 每页条数
const pageSize = ref(10)
// 总条数
const total = ref(0)
// 表格高度
const tableHeight = ref(500)

// 搜索关键词
const searchKeyword = ref('')
// 状态筛选
const filterStatus = ref('')
// 栏目筛选
const filterCategory = ref('')

// 统计数据（草稿/待审核/已发布/已驳回）
const stats = ref({ draft: 0, pending: 0, published: 0, rejected: 0 })

/**
 * 更新表格高度（响应窗口大小变化）
 */
const updateTableHeight = () => {
  tableHeight.value = window.innerHeight - 380
}

// 状态映射表
const statusMap = { 0: '草稿', 1: '待审核', 2: '已发布', 3: '已驳回', 4: '已下架' }
const statusTypeMap = { 0: 'info', 1: 'warning', 2: 'success', 3: 'danger', 4: 'warning' }

/**
 * 获取状态文本
 * @param {number} status - 状态码
 * @returns {string} 状态名称
 */
const getStatusText = (status) => statusMap[status] || '未知'

/**
 * 获取状态对应的标签类型
 * @param {number} status - 状态码
 * @returns {string} Element Plus标签类型
 */
const getStatusType = (status) => statusTypeMap[status] || 'info'

/**
 * 获取图片占位图（无封面时使用）
 * @param {number} id - 文章ID
 * @returns {string} 占位图URL
 */
const getPlaceholder = (id) => `https://picsum.photos/seed/article${id}/80/50`

/**
 * 格式化时间
 * @param {string} time - ISO时间字符串
 * @returns {string} 格式化后的时间
 */
const formatTime = (time) => {
  return time ? format(new Date(time), 'yyyy-MM-dd HH:mm') : '-'
}

/**
 * 计算统计数据（从文章列表中统计各状态数量）
 */
const calculateStats = () => {
  const s = { draft: 0, pending: 0, published: 0, rejected: 0 }
  articleList.value.forEach(item => {
    if (item.status === 0) s.draft++
    else if (item.status === 1) s.pending++
    else if (item.status === 2) s.published++
    else if (item.status === 3) s.rejected++
  })
  stats.value = s
}

/**
 * 获取我的文章列表
 */
const getMyArticles = async () => {
  loading.value = true
  try {
    const params = {
      pageNum: currentPage.value,
      pageSize: pageSize.value
    }
    if (searchKeyword.value) params.keyword = searchKeyword.value
    if (filterStatus.value !== '' && filterStatus.value !== null) params.status = filterStatus.value
    if (filterCategory.value) params.categoryId = filterCategory.value

    const result = await proxy.$api.article.myList(params)
    const pageResult = result || {}
    articleList.value = pageResult.records || []
    total.value = pageResult.total || 0
    calculateStats()
  } catch (err) {
    console.error('获取文章列表失败:', err)
  } finally {
    loading.value = false
  }
}

/**
 * 获取栏目列表
 */
const getCategories = async () => {
  try {
    const data = await proxy.$api.category.list()
    categories.value = data || []
  } catch (err) {
    console.error('获取栏目失败:', err)
  }
}

/**
 * 处理筛选条件变化
 */
const handleFilterChange = () => {
  currentPage.value = 1
  getMyArticles()
}

/**
 * 重置筛选条件
 */
const handleReset = () => {
  searchKeyword.value = ''
  filterStatus.value = ''
  filterCategory.value = ''
  currentPage.value = 1
  getMyArticles()
}

/**
 * 快速筛选（点击统计卡片）
 * @param {number} status - 状态码
 */
const quickFilter = (status) => {
  filterStatus.value = status
  currentPage.value = 1
  getMyArticles()
}

/**
 * 提交审核（草稿/驳回状态才能提交）
 * @param {Object} row - 文章数据
 */
const handlePublish = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要提交文章《${row.title}》进行审核吗？`, '提示', {
      type: 'info',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await proxy.$api.article.update({ ...row, status: 1 })
    ElMessage.success('提交成功，请等待审核')
    getMyArticles()
  } catch (err) {
    if (err !== 'cancel') console.error('提交失败:', err)
  }
}

/**
 * 下架文章（已发布状态才能下架）
 * @param {Object} row - 文章数据
 */
const handleOffline = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要下架文章《${row.title}》吗？`, '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await proxy.$api.article.update({ ...row, status: 4 })
    ElMessage.success('下架成功')
    getMyArticles()
  } catch (err) {
    if (err !== 'cancel') console.error('下架失败:', err)
  }
}

/**
 * 删除文章（带确认）
 * @param {Object} row - 文章数据
 */
const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要删除文章《${row.title}》吗？`, '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await proxy.$api.article.delete(row.id)
    ElMessage.success('删除成功')
    getMyArticles()
  } catch (err) {
    if (err !== 'cancel') console.error('删除失败:', err)
  }
}

/**
 * 跳转到新增文章页面
 */
const toAdd = () => {
  router.push('/article/edit')
}

/**
 * 跳转到编辑文章页面
 * @param {number} id - 文章ID
 */
const toEdit = (id) => {
  router.push(`/article/edit/${id}`)
}

/**
 * 跳转到文章详情页面
 * @param {number} id - 文章ID
 */
const toDetail = (id) => {
  router.push(`/article/${id}`)
}

/**
 * 处理页码变化
 * @param {number} page - 新页码
 */
const handlePageChange = (page) => {
  currentPage.value = page
  getMyArticles()
}

/**
 * 处理每页条数变化
 * @param {number} size - 新的每页条数
 */
const handleSizeChange = (size) => {
  pageSize.value = size
  currentPage.value = 1
  getMyArticles()
}

/**
 * 页面挂载时执行
 */
onMounted(async () => {
  updateTableHeight()
  window.addEventListener('resize', updateTableHeight)
  await Promise.all([getCategories(), getMyArticles()])
})

/**
 * 页面卸载时清理
 */
onUnmounted(() => {
  window.removeEventListener('resize', updateTableHeight)
})
</script>

<style scoped>
.article-manage-container {
  border-radius: 8px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
}

.header-icon {
  font-size: 18px;
  color: #409eff;
}

.title {
  font-size: 16px;
  font-weight: 600;
}

/* 统计卡片 */
.stat-row {
  margin-bottom: 20px;
}

.stat-card {
  display: flex;
  align-items: center;
  padding: 16px 20px;
  background: #fff;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  border: 1px solid #ebeef5;
}

.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.stat-icon {
  font-size: 32px;
  margin-right: 16px;
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
}

.stat-0 .stat-icon { background: #f4f4f5; color: #909399; }
.stat-1 .stat-icon { background: #fdf6ec; color: #e6a23c; }
.stat-2 .stat-icon { background: #f0f9eb; color: #67c23a; }
.stat-3 .stat-icon { background: #fef0f0; color: #f56c6c; }

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-label {
  font-size: 13px;
  color: #909399;
  margin-top: 4px;
}

.filter-bar {
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
}

.article-title {
  cursor: pointer;
  color: #303133;
  font-weight: 500;
  transition: color 0.2s;
}

.article-title:hover {
  color: #409eff;
}

.data-cell {
  display: flex;
  justify-content: center;
  gap: 10px;
}

.data-item {
  display: flex;
  align-items: center;
  gap: 3px;
  font-size: 12px;
  color: #606266;
}

.time-text {
  color: #606266;
  font-size: 13px;
}

.pagination-wrapper {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.image-placeholder {
  width: 80px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  border-radius: 4px;
  color: #c0c4cc;
}
</style>
