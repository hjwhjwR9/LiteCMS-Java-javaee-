<template>
  <div class="news-publish-container">
    <el-card shadow="never" class="main-card">
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <el-icon class="header-icon">
              <component :is="isEdit ? 'Edit' : 'EditPen'" />
            </el-icon>
            <span class="title">{{ isEdit ? '编辑新闻' : '发布新闻' }}</span>
          </div>
          <el-button @click="router.push('/news/manage')">
            <el-icon><Back /></el-icon> 返回列表
          </el-button>
        </div>
      </template>

      <el-form
        :model="newsForm"
        :rules="rules"
        ref="formRef"
        label-width="100px"
        label-position="right"
        v-loading="loading"
      >
        <el-row :gutter="24">
          <el-col :span="16">
            <el-form-item label="新闻标题" prop="title">
              <el-input
                v-model="newsForm.title"
                placeholder="请输入新闻标题"
                maxlength="100"
                show-word-limit
                size="large"
              />
            </el-form-item>

            <el-form-item label="新闻摘要" prop="summary">
              <el-input
                v-model="newsForm.summary"
                placeholder="请输入新闻摘要（可选，系统将自动提取）"
                type="textarea"
                :rows="3"
                maxlength="300"
                show-word-limit
              />
            </el-form-item>

            <el-form-item label="新闻内容" prop="content">
              <QuillEditor
                v-model:content="newsForm.content"
                content-type="html"
                :toolbar="quillToolbar"
                style="height: 500px;"
                theme="snow"
              />
            </el-form-item>
          </el-col>

          <el-col :span="8">
            <div class="sidebar-card">
              <div class="sidebar-title">发布设置</div>

              <el-form-item label="所属栏目" prop="categoryId" label-width="80px">
                <el-select v-model="newsForm.categoryId" placeholder="请选择栏目" style="width: 100%">
                  <el-option
                    v-for="item in categories"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  />
                </el-select>
              </el-form-item>

              <el-form-item label="发布状态" prop="status" label-width="80px">
                <el-radio-group v-model="newsForm.status">
                  <el-radio :value="0">草稿</el-radio>
                  <el-radio :value="1">提交审核</el-radio>
                  <el-radio :value="2">直接发布</el-radio>
                </el-radio-group>
              </el-form-item>

              <!-- 封面图片上传组件
                   - auto-upload="false"：关闭自动上传，选择文件后手动调用接口上传
                   - show-file-list="false"：不显示文件列表，只显示上传按钮/预览图
                   - on-change：文件选择变化时触发，在这里处理上传逻辑
                   - accept="image/*"：只允许选择图片文件
                   - 有图片时显示预览图，没图片时显示加号上传按钮 -->
              <el-form-item label="封面图片" label-width="80px">
                <div class="cover-upload-wrapper">
                  <el-upload
                    class="cover-uploader"
                    :auto-upload="false"
                    :show-file-list="false"
                    :on-change="handleCoverUpload"
                    accept="image/*"
                  >
                    <!-- 已上传封面：显示预览图 -->
                    <el-image
                      v-if="newsForm.coverUrl"
                      :src="newsForm.coverUrl"
                      fit="cover"
                      class="cover-image"
                    >
                      <!-- 图片加载失败时显示占位图 -->
                      <template #error>
                        <div class="cover-placeholder">
                          <el-icon :size="32"><Picture /></el-icon>
                          <span>图片加载失败</span>
                        </div>
                      </template>
                    </el-image>
                    <!-- 未上传封面：显示上传入口 -->
                    <div v-else class="cover-placeholder">
                      <el-icon :size="32"><Plus /></el-icon>
                      <span>上传封面</span>
                    </div>
                  </el-upload>
                  <div class="cover-tip">支持 JPG/PNG，建议尺寸 800x450</div>
                </div>
              </el-form-item>

              <el-form-item label="来源" label-width="80px">
                <el-input v-model="newsForm.source" placeholder="新闻来源" />
              </el-form-item>

              <el-form-item label="关键词" label-width="80px">
                <el-input v-model="newsForm.keywords" placeholder="多个用逗号分隔" />
              </el-form-item>
            </div>

            <div class="sidebar-card mt-3">
              <div class="sidebar-title">作者信息</div>
              <div class="author-info">
                <el-avatar :size="40" class="author-avatar">
                  {{ (userInfo.nickname || 'U').charAt(0) }}
                </el-avatar>
                <div class="author-detail">
                  <div class="author-name">{{ userInfo.nickname || '当前用户' }}</div>
                  <div class="author-tip">发布后将记录在作者名下</div>
                </div>
              </div>
            </div>
          </el-col>
        </el-row>

        <el-form-item class="submit-area">
          <el-button type="primary" size="large" @click="handleSubmit" :loading="submitting">
            <el-icon><Check /></el-icon> 保存
          </el-button>
          <el-button size="large" @click="handleSaveDraft">
            <el-icon><DocumentCopy /></el-icon> 保存为草稿
          </el-button>
          <el-button size="large" @click="router.back()">取消</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { QuillEditor } from '@vueup/vue-quill'
import { categoryApi, articleApi, uploadApi } from '../api/cms'
import '@vueup/vue-quill/dist/vue-quill.snow.css'

const router = useRouter()
const route = useRoute()
const newsId = route.params.id

const formRef = ref(null)
const loading = ref(false)
const submitting = ref(false)
const uploading = ref(false)
const isEdit = ref(!!newsId)

const categories = ref([])

const newsForm = ref({
  id: null,
  categoryId: '',
  title: '',
  keywords: '',
  summary: '',
  content: '',
  coverUrl: '',
  source: '原创',
  status: 2
})

const userInfo = ref({
  nickname: localStorage.getItem('nickname') || '管理员',
  username: localStorage.getItem('username') || 'admin'
})

const rules = {
  categoryId: [{ required: true, message: '请选择所属栏目', trigger: 'change' }],
  title: [{ required: true, message: '请输入新闻标题', trigger: 'blur' }],
  content: [{ required: true, message: '请输入新闻内容', trigger: 'blur' }]
}

const quillToolbar = [
  ['bold', 'italic', 'underline', 'strike'],
  ['blockquote', 'code-block'],
  [{ 'header': 1 }, { 'header': 2 }],
  [{ 'list': 'ordered' }, { 'list': 'bullet' }],
  [{ 'indent': '-1' }, { 'indent': '+1' }],
  [{ 'direction': 'rtl' }],
  [{ 'size': ['small', false, 'large', 'huge'] }],
  [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
  [{ 'color': [] }, { 'background': [] }],
  [{ 'font': [] }],
  [{ 'align': [] }],
  ['link', 'image', 'video'],
  ['clean']
]

const getCategories = async () => {
  try {
    const data = await categoryApi.list()
    categories.value = data || []
  } catch (err) {
    console.error('获取栏目失败:', err)
  }
}

const getNewsDetail = async () => {
  if (!newsId) return
  loading.value = true
  try {
    const data = await articleApi.getDetail(newsId)
    if (data) {
      newsForm.value = {
        id: data.id,
        categoryId: data.categoryId,
        title: data.title,
        keywords: data.keywords || '',
        summary: data.summary || '',
        content: data.content || '',
        coverUrl: data.coverUrl || '',
        source: data.source || '原创',
        status: data.status ?? 2
      }
    }
  } catch (err) {
    console.error('获取新闻详情失败:', err)
  } finally {
    loading.value = false
  }
}

/**
 * 封面图片上传处理函数
 * 在用户选择图片后触发（el-upload 的 on-change 事件）
 * 处理流程：
 *   1. 校验文件类型（必须是图片）
 *   2. 校验文件大小（不能超过5MB）
 *   3. 调用后端上传接口 uploadApi.uploadCover
 *   4. 上传成功后将返回的图片URL保存到表单
 * @param {Object} file - el-upload 返回的文件对象，file.raw 是原生 File 对象
 * @returns {boolean} 返回 false 阻止 el-upload 默认的上传行为（因为我们是手动上传）
 */
const handleCoverUpload = async (file) => {
  // 校验文件类型：必须是 image/ 开头的 MIME 类型
  const isImage = file.raw.type.startsWith('image/')
  // 校验文件大小：限制 5MB 以内
  const isLt5M = file.raw.size / 1024 / 1024 < 5

  // 类型校验不通过
  if (!isImage) {
    ElMessage.error('只能上传图片文件!')
    return false
  }
  // 大小校验不通过
  if (!isLt5M) {
    ElMessage.error('图片大小不能超过 5MB!')
    return false
  }

  // 开始上传，设置 loading 状态
  uploading.value = true
  try {
    // 调用后端上传接口，传入原生 File 对象
    const url = await uploadApi.uploadCover(file.raw)
    // 上传成功，把返回的图片URL保存到表单
    newsForm.value.coverUrl = url
    ElMessage.success('封面上传成功')
  } catch (err) {
    // 上传失败，打印错误并提示用户
    console.error('上传失败:', err)
    ElMessage.error('封面上传失败，请重试')
  } finally {
    // 无论成功失败，都关闭 loading 状态
    uploading.value = false
  }
  // 返回 false 阻止 el-upload 的自动上传行为（因为我们用的是手动上传模式）
  return false
}

const handleSubmit = async () => {
  await formRef.value.validate()
  await saveData(newsForm.value.status)
}

const handleSaveDraft = async () => {
  await saveData(0)
}

const saveData = async (status) => {
  submitting.value = true
  try {
    const submitData = { ...newsForm.value, status }
    if (newsForm.value.id) {
      await articleApi.update(submitData)
      ElMessage.success(status === 0 ? '已保存为草稿' : '更新成功')
    } else {
      await articleApi.create(submitData)
      ElMessage.success(status === 0 ? '已保存为草稿' : (status === 1 ? '已提交审核' : '发布成功'))
    }
    router.push('/news/manage')
  } catch (err) {
    console.error('保存失败:', err)
  } finally {
    submitting.value = false
  }
}

onMounted(async () => {
  await getCategories()
  if (isEdit.value) {
    await getNewsDetail()
  }
})
</script>

<style scoped>
.news-publish-container {
  padding: 0;
}

.main-card {
  border-radius: 8px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
}

.header-icon {
  font-size: 18px;
  color: #409eff;
}

.title {
  font-size: 16px;
  font-weight: 600;
}

.sidebar-card {
  background: #fafafa;
  border-radius: 8px;
  padding: 20px;
  border: 1px solid #ebeef5;
}

.sidebar-title {
  font-size: 15px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid #ebeef5;
  display: flex;
  align-items: center;
  gap: 6px;
}

.sidebar-title::before {
  content: '';
  width: 3px;
  height: 14px;
  background: #409eff;
  border-radius: 2px;
}

.cover-preview {
  margin-top: 8px;
}

.cover-upload-wrapper {
  width: 100%;
}

.cover-uploader {
  width: 100%;
  height: 160px;
  border: 1px dashed #d9d9d9;
  border-radius: 4px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: border-color 0.3s;
}

.cover-uploader:hover {
  border-color: #409eff;
}

.cover-uploader .el-image {
  width: 100%;
  height: 160px;
  display: block;
}

.cover-image {
  width: 100%;
  height: 160px;
}

.cover-placeholder {
  width: 100%;
  height: 160px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: #fafafa;
  color: #8c939d;
  gap: 8px;
}

.cover-placeholder span {
  font-size: 12px;
}

.cover-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 8px;
  line-height: 1.4;
}

.cover-error {
  width: 100%;
  height: 160px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  border-radius: 4px;
  color: #c0c4cc;
  gap: 8px;
  font-size: 12px;
}

.author-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.author-avatar {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
  font-weight: 600;
  flex-shrink: 0;
}

.author-detail {
  flex: 1;
}

.author-name {
  font-size: 14px;
  color: #303133;
  font-weight: 500;
}

.author-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 2px;
}

.mt-3 {
  margin-top: 16px;
}

.submit-area {
  margin-top: 24px;
  padding-top: 24px;
  border-top: 1px solid #ebeef5;
  margin-left: 100px;
}
</style>
