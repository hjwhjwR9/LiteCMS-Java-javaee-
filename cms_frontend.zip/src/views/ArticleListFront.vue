<template>
  <div class="article-list-page" ref="pageRef">
    <!-- 头部 Banner -->
    <div class="hero-banner">
      <div class="banner-content">
        <h1 class="banner-title">探索精彩内容</h1>
        <p class="banner-subtitle">发现最新、最热的文章与新闻</p>
        <div class="search-box">
          <el-input
            v-model="searchKeyword"
            placeholder="搜索感兴趣的文章..."
            size="large"
            clearable
            @keyup.enter="handleSearch"
            @clear="handleSearch"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
            <template #append>
              <el-button type="primary" @click="handleSearch">搜索</el-button>
            </template>
          </el-input>
        </div>
      </div>
    </div>

    <!-- 筛选栏 -->
    <div class="filter-section">
      <div class="filter-left">
        <span class="filter-label">栏目：</span>
        <el-radio-group v-model="filterCategory" @change="handleCategoryChange">
          <el-radio-button :value="''">全部</el-radio-button>
          <el-radio-button v-for="cat in categories" :key="cat.id" :value="cat.id">
            {{ cat.name }}
          </el-radio-button>
        </el-radio-group>
      </div>
      <div class="filter-right">
        <el-button :type="sortType === 'newest' ? 'primary' : ''" @click="changeSort('newest')" link>
          <el-icon><Clock /></el-icon> 最新
        </el-button>
        <el-button :type="sortType === 'hot' ? 'primary' : ''" @click="changeSort('hot')" link>
          <el-icon><TrendCharts /></el-icon> 最热
        </el-button>
      </div>
    </div>

    <!-- 文章列表 -->
    <!-- 说明：el-image 组件使用 lazy 属性启用图片懒加载，
         图片进入可视区域前不会加载，减少首屏资源请求
         error 插槽用于图片加载失败时显示占位图 -->
    <div class="article-content" v-loading="loading">
      <el-empty v-if="!loading && articleList.length === 0" description="暂无文章" />
      <el-row :gutter="20" v-else>
        <el-col :xs="24" :sm="12" :md="8" v-for="article in articleList" :key="article.id">
          <el-card class="article-card" shadow="hover" @click="toDetail(article.id)">
            <div class="article-cover">
              <!-- lazy 属性：启用图片懒加载，图片进入可视区域后才开始加载，
                   可减少首屏 HTTP 请求数，提升页面加载速度 -->
              <el-image
                :src="article.coverUrl || getCover(article.id)"
                fit="cover"
                class="cover-img"
                lazy
              >
                <template #error>
                  <div class="cover-error">
                    <el-icon :size="32"><Picture /></el-icon>
                  </div>
                </template>
              </el-image>
              <div class="cover-mask">
                <el-tag v-if="article.categoryName" size="small" type="warning" effect="dark">
                  {{ article.categoryName }}
                </el-tag>
              </div>
            </div>
            <div class="article-info">
              <h3 class="article-title line-clamp-2">{{ article.title }}</h3>
              <p class="article-summary line-clamp-2">
                {{ article.summary || '点击查看详情...' }}
              </p>
              <div class="article-meta">
                <div class="meta-left">
                  <el-avatar :size="20" class="author-avatar">
                    {{ (article.authorNickname || '匿').charAt(0) }}
                  </el-avatar>
                  <span class="author-name">{{ article.authorNickname || '匿名' }}</span>
                </div>
                <div class="meta-right">
                  <span class="meta-item"><el-icon><View /></el-icon> {{ article.viewCount || 0 }}</span>
                  <span class="meta-item"><el-icon><Star /></el-icon> {{ article.likeCount || 0 }}</span>
                </div>
              </div>
              <div class="article-date">
                <el-icon><Calendar /></el-icon> {{ formatTime(article.publishedAt) }}
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <!-- 加载状态 -->
    <div class="load-more-tip">
      <el-loading v-if="loadingMore" size="20px" />
      <span v-else-if="hasMore" class="load-tip">下拉加载更多</span>
      <span v-else-if="articleList.length > 0" class="no-more-tip">— 已经到底啦 —</span>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { articleApi, categoryApi } from '../api'
const router = useRouter()

const loading = ref(false)
const loadingMore = ref(false)   // 加载更多的loading状态，防止滚动触发多次请求
const articleList = ref([])       // 当前已加载的文章列表（分页展示的数据）
const categories = ref([])
const pageSize = ref(12)          // 每页加载的文章数量
const currentPage = ref(1)        // 当前已加载到第几页
const total = ref(0)              // 筛选后的文章总数
const allFilteredList = ref([])   // 筛选+排序后的全部文章数据（用于前端模拟分页）
const searchKeyword = ref('')
const filterCategory = ref('')
const sortType = ref('newest')

const hasMore = ref(true)    // 是否还有更多数据可加载，控制底部提示文案

const getCover = (id) => `https://picsum.photos/seed/article${id}/600/400`

const formatTime = (time) => {
  if (!time) return '未知时间'
  const d = new Date(time)
  const now = new Date()
  const diff = (now - d) / 1000
  if (diff < 60) return '刚刚'
  if (diff < 3600) return `${Math.floor(diff / 60)} 分钟前`
  if (diff < 86400) return `${Math.floor(diff / 3600)} 小时前`
  if (diff < 604800) return `${Math.floor(diff / 86400)} 天前`
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

/**
 * 拉取全部文章数据并初始化列表
 * 由于后端接口不支持 categoryId 参数，采用"一次拉取100条 + 前端模拟分页"的方案
 * 搜索、切换栏目、切换排序时都会调用此函数重置列表
 */
const fetchAllData = async () => {
  loading.value = true
  try {
    const params = {
      pageNum: 1,
      pageSize: 100
    }
    if (searchKeyword.value) params.keyword = searchKeyword.value

    const data = await articleApi.list(params)
    const result = data || {}
    let list = result.records || []

    if (filterCategory.value) {
      list = list.filter(a => a.categoryId === filterCategory.value)
    }

    if (sortType.value === 'hot') {
      list.sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0))
    } else {
      list.sort((a, b) => new Date(b.createdAt || b.publishedAt) - new Date(a.createdAt || a.publishedAt))
    }

    allFilteredList.value = list
    total.value = list.length
    currentPage.value = 1
    articleList.value = list.slice(0, pageSize.value)
    hasMore.value = articleList.value.length < total.value
  } catch (err) {
    console.error('获取文章列表失败：', err)
  } finally {
    loading.value = false
  }
}

/**
 * 加载更多文章（无限滚动核心函数）
 * 从 allFilteredList 中 slice 出下一页数据追加到 articleList
 * 使用 loadingMore 和 hasMore 状态位防止重复触发
 */
const loadMore = async () => {
  // 防抖：正在加载中 / 已经没有更多 / 主loading中 时直接返回
  if (loadingMore.value || !hasMore.value || loading.value) return

  loadingMore.value = true
  try {
    await nextTick()
    const nextPage = currentPage.value + 1
    const start = (nextPage - 1) * pageSize.value
    const end = start + pageSize.value
    const nextList = allFilteredList.value.slice(start, end)

    if (nextList.length > 0) {
      articleList.value = [...articleList.value, ...nextList]
      currentPage.value = nextPage
    }

    hasMore.value = articleList.value.length < total.value
  } catch (err) {
    console.error('加载更多失败：', err)
  } finally {
    loadingMore.value = false
  }
}

/**
 * 滚动事件监听函数
 * 检测页面滚动到底部附近（距底部200px）时触发加载更多
 * 200px 提前量是为了让用户感知不到等待，实现"无缝加载"的体验
 */
const handleScroll = () => {
  const scrollTop = document.documentElement.scrollTop || document.body.scrollTop
  const clientHeight = document.documentElement.clientHeight
  const scrollHeight = document.documentElement.scrollHeight

  if (scrollTop + clientHeight >= scrollHeight - 200) {
    loadMore()
  }
}

const getCategories = async () => {
  try {
    const data = await categoryApi.list()
    categories.value = data || []
  } catch (err) {
    console.error('获取栏目失败:', err)
  }
}

const handleSearch = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' })
  fetchAllData()
}

const handleCategoryChange = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' })
  fetchAllData()
}

const changeSort = (type) => {
  if (sortType.value === type) return
  sortType.value = type
  window.scrollTo({ top: 0, behavior: 'smooth' })
  fetchAllData()
}

const toDetail = (id) => {
  router.push(`/article/${id}`)
}

// 组件挂载：初始化数据 + 注册滚动事件监听
onMounted(async () => {
  await Promise.all([getCategories(), fetchAllData()])
  window.addEventListener('scroll', handleScroll)
})

// 组件卸载：移除滚动事件监听，防止内存泄漏
onBeforeUnmount(() => {
  window.removeEventListener('scroll', handleScroll)
})
</script>

<style scoped>
.article-list-page {
  padding: 0;
  max-width: 1280px;
  margin: 0 auto;
}

/* Hero Banner */
.hero-banner {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  padding: 48px 32px;
  margin-bottom: 24px;
  color: #fff;
  text-align: center;
  box-shadow: 0 4px 20px rgba(102, 126, 234, 0.2);
}

.banner-title {
  font-size: 32px;
  font-weight: 700;
  margin: 0 0 8px;
  letter-spacing: 1px;
}

.banner-subtitle {
  font-size: 16px;
  opacity: 0.9;
  margin: 0 0 24px;
}

.search-box {
  max-width: 600px;
  margin: 0 auto;
}

.search-box :deep(.el-input__wrapper) {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

/* 筛选 */
.filter-section {
  background: #fff;
  border-radius: 8px;
  padding: 16px 20px;
  margin-bottom: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
}

.filter-left {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: 1;
  overflow-x: auto;
}

.filter-label {
  font-size: 14px;
  color: #606266;
  font-weight: 600;
  white-space: nowrap;
}

.filter-right {
  display: flex;
  gap: 8px;
}

/* 卡片 */
.article-card {
  margin-bottom: 20px;
  border-radius: 8px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s;
  border: none;
}

.article-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}

.article-cover {
  position: relative;
  height: 180px;
  overflow: hidden;
}

.cover-img {
  width: 100%;
  height: 100%;
  transition: transform 0.4s;
}

.article-card:hover .cover-img {
  transform: scale(1.05);
}

.cover-mask {
  position: absolute;
  top: 8px;
  left: 8px;
  z-index: 2;
}

.cover-error {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  color: #c0c4cc;
}

.article-info {
  padding: 16px;
}

.article-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
  margin: 0 0 8px;
  line-height: 1.4;
  height: 44px;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow: hidden;
}

.article-card:hover .article-title {
  color: #409eff;
}

.article-summary {
  font-size: 13px;
  color: #909399;
  line-height: 1.5;
  margin: 0 0 12px;
  height: 40px;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow: hidden;
}

.article-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  border-top: 1px solid #f0f0f0;
}

.meta-left {
  display: flex;
  align-items: center;
  gap: 6px;
}

.author-avatar {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
  font-size: 11px;
}

.author-name {
  font-size: 12px;
  color: #606266;
}

.meta-right {
  display: flex;
  gap: 12px;
}

.meta-item {
  font-size: 12px;
  color: #909399;
  display: flex;
  align-items: center;
  gap: 3px;
}

.article-date {
  font-size: 12px;
  color: #c0c4cc;
  display: flex;
  align-items: center;
  gap: 4px;
  margin-top: 8px;
}

/* 加载更多 */
.load-more-tip {
  text-align: center;
  padding: 32px 0;
  color: #909399;
  font-size: 14px;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 60px;
}

.load-tip {
  color: #c0c4cc;
}

.no-more-tip {
  color: #dcdfe6;
}

.line-clamp-2 {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow: hidden;
}
</style>
