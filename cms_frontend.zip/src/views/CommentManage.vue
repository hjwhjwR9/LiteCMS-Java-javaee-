<template>
  <div class="comment-manage-container">
    <el-card shadow="never" class="main-card">
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <el-icon class="header-icon"><ChatDotRound /></el-icon>
            <span class="title">评论管理</span>
            <el-tag size="small" type="info" effect="plain">共 {{ total }} 条</el-tag>
          </div>
          <div class="header-actions">
            <el-button @click="handleRefresh">
              <el-icon><Refresh /></el-icon> 刷新
            </el-button>
          </div>
        </div>
      </template>

      <!-- 统计卡片 -->
      <el-row :gutter="16" class="stat-row">
        <el-col :span="6">
          <div class="stat-card stat-0" @click="quickFilter('')">
            <el-icon class="stat-icon"><ChatLineSquare /></el-icon>
            <div class="stat-content">
              <div class="stat-value">{{ stats.total }}</div>
              <div class="stat-label">全部</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-card stat-1" @click="quickFilter(0)">
            <el-icon class="stat-icon"><Clock /></el-icon>
            <div class="stat-content">
              <div class="stat-value">{{ stats.pending }}</div>
              <div class="stat-label">待审核</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-card stat-2" @click="quickFilter(1)">
            <el-icon class="stat-icon"><CircleCheck /></el-icon>
            <div class="stat-content">
              <div class="stat-value">{{ stats.approved }}</div>
              <div class="stat-label">已通过</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-card stat-3" @click="quickFilter(2)">
            <el-icon class="stat-icon"><CircleClose /></el-icon>
            <div class="stat-content">
              <div class="stat-value">{{ stats.rejected }}</div>
              <div class="stat-label">已驳回</div>
            </div>
          </div>
        </el-col>
      </el-row>

      <!-- 筛选 -->
      <div class="filter-bar">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索评论内容"
          prefix-icon="Search"
          style="width: 240px; margin-right: 12px"
          clearable
          @clear="handleFilterChange"
          @keyup.enter="handleFilterChange"
        />
        <el-select v-model="filterStatus" placeholder="状态筛选" clearable style="width: 120px; margin-right: 12px" @change="handleFilterChange">
          <el-option label="待审核" :value="0" />
          <el-option label="已通过" :value="1" />
          <el-option label="已驳回" :value="2" />
        </el-select>
        <el-button @click="handleReset">
          <el-icon><RefreshLeft /></el-icon> 重置
        </el-button>
      </div>

      <!-- 工具栏 -->
      <div class="table-toolbar" v-if="selectedIds.length > 0">
        <span class="selected-tip">已选 <b>{{ selectedIds.length }}</b> 项</span>
        <el-button type="success" @click="handleBatchApprove">
          <el-icon><CircleCheck /></el-icon> 批量通过
        </el-button>
        <el-button type="warning" @click="handleBatchReject">
          <el-icon><CircleClose /></el-icon> 批量驳回
        </el-button>
        <el-button type="danger" @click="handleBatchDelete">
          <el-icon><Delete /></el-icon> 批量删除
        </el-button>
      </div>

      <el-table
        :data="commentList"
        v-loading="loading"
        stripe
        border
        :max-height="tableHeight"
        @selection-change="handleSelectionChange"
        empty-text="暂无评论"
      >
        <el-table-column type="selection" width="50" />
        <el-table-column type="index" label="#" width="55" align="center" />
        <el-table-column label="用户" width="160" align="center">
          <template #default="{ row }">
            <div class="user-info">
              <el-avatar :size="32" class="user-avatar">
                {{ (row.userNickname || row.userName || '游').charAt(0) }}
              </el-avatar>
              <span class="user-name">{{ row.userNickname || row.userName || '游客' }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="评论内容" min-width="280">
          <template #default="{ row }">
            <div class="comment-content" :class="{ 'is-short': row.content?.length < 30 }">
              {{ row.content }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="所属文章" min-width="200" show-overflow-tooltip>
          <template #default="{ row }">
            <span class="article-title" @click="handleViewArticle(row.articleId)">
              <el-icon><Document /></el-icon>
              {{ row.articleTitle || '未知文章' }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)" size="small">{{ getStatusText(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="ipRegion" label="IP地区" width="110" align="center">
          <template #default="{ row }">
            <span class="ip-text">{{ row.ipRegion || '未知' }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="createdAt" label="评论时间" width="170" align="center">
          <template #default="{ row }">
            <span class="time-text">{{ formatTime(row.createdAt) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" type="success" link @click="updateStatus(row, 1)" v-if="row.status === 0">通过</el-button>
            <el-button size="small" type="warning" link @click="updateStatus(row, 2)" v-if="row.status === 0">驳回</el-button>
            <el-button size="small" type="primary" link @click="viewDetail(row)">查看</el-button>
            <el-button size="small" type="danger" link @click="deleteComment(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          background
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>

    <!-- 评论详情弹窗 -->
    <el-dialog v-model="detailDialogVisible" title="评论详情" width="600px" center>
      <div v-if="currentComment" class="comment-detail">
        <div class="detail-user">
          <el-avatar :size="48" class="detail-avatar">
            {{ (currentComment.userNickname || '游').charAt(0) }}
          </el-avatar>
          <div class="detail-user-info">
            <div class="detail-nickname">{{ currentComment.userNickname || '游客' }}</div>
            <div class="detail-meta">
              <span class="meta-item">
                <el-icon><Location /></el-icon> {{ currentComment.ipRegion || '未知地区' }}
              </span>
              <span class="meta-item">
                <el-icon><Clock /></el-icon> {{ formatTime(currentComment.createdAt) }}
              </span>
            </div>
          </div>
          <el-tag :type="getStatusType(currentComment.status)">{{ getStatusText(currentComment.status) }}</el-tag>
        </div>
        <el-divider />
        <div class="detail-article">
          <span class="label">评论文章：</span>
          <span class="article-link" @click="handleViewArticle(currentComment.articleId)">
            {{ currentComment.articleTitle }}
          </span>
        </div>
        <div class="detail-content">{{ currentComment.content }}</div>
      </div>
      <template #footer>
        <el-button @click="detailDialogVisible = false">关闭</el-button>
        <el-button type="danger" @click="deleteComment(currentComment); detailDialogVisible = false">删除评论</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, getCurrentInstance } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { format } from 'date-fns'

const { proxy } = getCurrentInstance()
const router = useRouter()

const loading = ref(false)
const commentList = ref([])
const searchKeyword = ref('')
const filterStatus = ref('')
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)
const tableHeight = ref(500)

const selectedRows = ref([])
const selectedIds = computed(() => selectedRows.value.map(r => r.id))

const detailDialogVisible = ref(false)
const currentComment = ref(null)

const stats = ref({ total: 0, pending: 0, approved: 0, rejected: 0 })

const updateTableHeight = () => {
  tableHeight.value = window.innerHeight - 380
}

const statusMap = { 0: '待审核', 1: '已通过', 2: '已驳回', 3: '已删除' }
const statusTypeMap = { 0: 'warning', 1: 'success', 2: 'danger', 3: 'info' }

const getStatusText = (status) => statusMap[status] || '未知'
const getStatusType = (status) => statusTypeMap[status] || 'info'

const formatTime = (time) => {
  return time ? format(new Date(time), 'yyyy-MM-dd HH:mm') : '-'
}

const calculateStats = (list) => {
  const s = { total: 0, pending: 0, approved: 0, rejected: 0 }
  list.forEach(item => {
    s.total++
    if (item.status === 0) s.pending++
    else if (item.status === 1) s.approved++
    else if (item.status === 2) s.rejected++
  })
  stats.value = s
}

const getComments = async () => {
  loading.value = true
  try {
    const data = await proxy.$api.comment.allList()
    let list = data || []
    if (searchKeyword.value) {
      list = list.filter(item => item.content?.includes(searchKeyword.value))
    }
    if (filterStatus.value !== '' && filterStatus.value !== null) {
      list = list.filter(item => item.status === filterStatus.value)
    }
    total.value = list.length
    // 简单分页
    const start = (currentPage.value - 1) * pageSize.value
    commentList.value = list.slice(start, start + pageSize.value)
    calculateStats(list)
  } catch (err) {
    console.error('获取评论列表失败:', err)
  } finally {
    loading.value = false
  }
}

const handleFilterChange = () => {
  currentPage.value = 1
  getComments()
}

const handleReset = () => {
  searchKeyword.value = ''
  filterStatus.value = ''
  currentPage.value = 1
  getComments()
}

const quickFilter = (status) => {
  filterStatus.value = status
  currentPage.value = 1
  getComments()
}

const handleRefresh = () => {
  getComments()
  ElMessage.success('刷新成功')
}

const handlePageChange = (page) => {
  currentPage.value = page
  getComments()
}

const handleSizeChange = (size) => {
  pageSize.value = size
  currentPage.value = 1
  getComments()
}

const handleSelectionChange = (rows) => {
  selectedRows.value = rows
}

const handleViewArticle = (articleId) => {
  router.push(`/article/${articleId}`)
}

const viewDetail = (row) => {
  currentComment.value = row
  detailDialogVisible.value = true
}

const updateStatus = async (row, status) => {
  const statusText = status === 1 ? '通过' : '驳回'
  try {
    await ElMessageBox.confirm(`确定${statusText}该评论吗？`, '提示', {
      type: 'info',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await proxy.$api.comment.updateStatus({ id: row.id, status })
    ElMessage.success(`${statusText}成功`)
    getComments()
  } catch (err) {
    if (err !== 'cancel') console.error('操作失败:', err)
  }
}

const deleteComment = async (row) => {
  try {
    await ElMessageBox.confirm('确定删除该评论吗？此操作不可恢复', '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await proxy.$api.comment.delete(row.id)
    ElMessage.success('删除成功')
    getComments()
  } catch (err) {
    if (err !== 'cancel') console.error('删除失败:', err)
  }
}

const handleBatchApprove = async () => {
  try {
    await ElMessageBox.confirm(`确定通过选中的 ${selectedIds.value.length} 条评论吗？`, '提示', {
      type: 'success',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await Promise.all(selectedRows.value.map(row =>
      proxy.$api.comment.updateStatus({ id: row.id, status: 1 })
    ))
    ElMessage.success('批量通过成功')
    getComments()
  } catch (err) {
    if (err !== 'cancel') console.error('批量操作失败:', err)
  }
}

const handleBatchReject = async () => {
  try {
    await ElMessageBox.confirm(`确定驳回选中的 ${selectedIds.value.length} 条评论吗？`, '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await Promise.all(selectedRows.value.map(row =>
      proxy.$api.comment.updateStatus({ id: row.id, status: 2 })
    ))
    ElMessage.success('批量驳回成功')
    getComments()
  } catch (err) {
    if (err !== 'cancel') console.error('批量操作失败:', err)
  }
}

const handleBatchDelete = async () => {
  try {
    await ElMessageBox.confirm(`确定删除选中的 ${selectedIds.value.length} 条评论吗？此操作不可恢复！`, '提示', {
      type: 'error',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await Promise.all(selectedIds.value.map(id => proxy.$api.comment.delete(id)))
    ElMessage.success('批量删除成功')
    getComments()
  } catch (err) {
    if (err !== 'cancel') console.error('批量删除失败:', err)
  }
}

onMounted(async () => {
  updateTableHeight()
  window.addEventListener('resize', updateTableHeight)
  await getComments()
})

onUnmounted(() => {
  window.removeEventListener('resize', updateTableHeight)
})
</script>

<style scoped>
.comment-manage-container {
  padding: 0;
}

.main-card {
  border-radius: 8px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
}

.header-icon {
  font-size: 18px;
  color: #409eff;
}

.title {
  font-size: 16px;
  font-weight: 600;
}

/* 统计卡片 */
.stat-row {
  margin-bottom: 20px;
}

.stat-card {
  display: flex;
  align-items: center;
  padding: 16px 20px;
  background: #fff;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  border: 1px solid #ebeef5;
}

.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.stat-icon {
  font-size: 32px;
  margin-right: 16px;
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
}

.stat-0 .stat-icon { background: #ecf5ff; color: #409eff; }
.stat-1 .stat-icon { background: #fdf6ec; color: #e6a23c; }
.stat-2 .stat-icon { background: #f0f9eb; color: #67c23a; }
.stat-3 .stat-icon { background: #fef0f0; color: #f56c6c; }

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-label {
  font-size: 13px;
  color: #909399;
  margin-top: 4px;
}

.filter-bar {
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
}

.table-toolbar {
  margin-bottom: 12px;
  padding: 12px 16px;
  background: #ecf5ff;
  border-radius: 6px;
  display: flex;
  align-items: center;
  gap: 10px;
}

.selected-tip {
  color: #606266;
  font-size: 13px;
}

.selected-tip b {
  color: #409eff;
  font-weight: 600;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
  justify-content: flex-start;
}

.user-avatar {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
  font-weight: 600;
}

.user-name {
  font-size: 13px;
  color: #303133;
}

.comment-content {
  color: #303133;
  line-height: 1.6;
  font-size: 13px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.article-title {
  cursor: pointer;
  color: #409eff;
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
}

.article-title:hover {
  text-decoration: underline;
}

.ip-text {
  font-family: 'Courier New', monospace;
  font-size: 12px;
  color: #909399;
  background: #f5f7fa;
  padding: 2px 6px;
  border-radius: 4px;
}

.time-text {
  color: #606266;
  font-size: 13px;
}

.pagination-wrapper {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

/* 详情弹窗 */
.comment-detail {
  padding: 0 8px;
}

.detail-user {
  display: flex;
  align-items: center;
  gap: 12px;
}

.detail-avatar {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
  font-weight: 600;
}

.detail-user-info {
  flex: 1;
}

.detail-nickname {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 4px;
}

.detail-meta {
  display: flex;
  gap: 16px;
  font-size: 13px;
  color: #909399;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 4px;
}

.detail-article {
  margin-bottom: 16px;
  font-size: 14px;
}

.label {
  color: #909399;
  margin-right: 4px;
}

.article-link {
  color: #409eff;
  cursor: pointer;
}

.article-link:hover {
  text-decoration: underline;
}

.detail-content {
  background: #f5f7fa;
  border-left: 4px solid #409eff;
  padding: 16px 20px;
  border-radius: 4px;
  font-size: 15px;
  line-height: 1.8;
  color: #303133;
  white-space: pre-wrap;
  word-break: break-word;
}
</style>
