<template>
  <!-- 评论审核页面容器 -->
  <div class="review-container">
    <!-- 统计卡片区域 -->
    <el-row :gutter="16" class="stat-cards">
      <!-- 待审核统计 -->
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card stat-pending" @click="quickFilter(0)">
          <div class="stat-icon"><el-icon><Clock /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.pending }}</div>
            <div class="stat-label">待审核</div>
          </div>
        </el-card>
      </el-col>
      <!-- 已通过统计 -->
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card stat-approved" @click="quickFilter(1)">
          <div class="stat-icon"><el-icon><CircleCheck /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.approved }}</div>
            <div class="stat-label">已通过</div>
          </div>
        </el-card>
      </el-col>
      <!-- 已驳回统计 -->
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card stat-rejected" @click="quickFilter(2)">
          <div class="stat-icon"><el-icon><CircleClose /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.rejected }}</div>
            <div class="stat-label">已驳回</div>
          </div>
        </el-card>
      </el-col>
      <!-- 总记录统计 -->
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card stat-total">
          <div class="stat-icon"><el-icon><ChatLineSquare /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.total }}</div>
            <div class="stat-label">总记录</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 主内容卡片 -->
    <el-card class="content-card">
      <!-- 卡片头部 -->
      <template #header>
        <div class="card-header">
          <span class="title">评论审核</span>
          <!-- 搜索和筛选操作区 -->
          <div class="header-actions">
            <!-- 状态筛选 -->
            <el-select v-model="filterStatus" placeholder="审核状态" clearable style="width: 120px; margin-right: 12px" @change="handleFilterChange">
              <el-option label="全部" value="" />
              <el-option label="待审核" :value="0" />
              <el-option label="已通过" :value="1" />
              <el-option label="已驳回" :value="2" />
            </el-select>
            <!-- 搜索输入框 -->
            <el-input v-model="searchKeyword" placeholder="搜索评论内容" prefix-icon="Search" style="width: 200px; margin-right: 12px" clearable @clear="handleSearch" @keyup.enter="handleSearch" />
            <!-- 搜索按钮 -->
            <el-button @click="handleSearch">搜索</el-button>
            <!-- 批量通过按钮 -->
            <el-button type="success" @click="handleBatchApprove" :disabled="pendingCount === 0" style="margin-left: 12px">批量通过</el-button>
            <!-- 批量驳回按钮 -->
            <el-button type="danger" @click="handleBatchReject" :disabled="pendingCount === 0">批量驳回</el-button>
          </div>
        </div>
      </template>

      <!-- 评论审核列表表格 -->
      <el-table
        ref="tableRef"
        :data="commentList"
        v-loading="loading"
        @selection-change="handleSelectionChange"
        stripe
        border
        max-height="calc(100vh - 420px)"
      >
        <!-- 多选列 -->
        <el-table-column type="selection" width="50" />
        <!-- ID列 -->
        <el-table-column prop="id" label="ID" width="70" align="center" />
        <!-- 所属文章列 -->
        <el-table-column prop="articleTitle" label="所属文章" width="200" show-overflow-tooltip />
        <!-- 评论用户列（头像+昵称） -->
        <el-table-column label="评论用户" width="150" align="center">
          <template #default="{ row }">
            <div class="user-info">
              <el-avatar :size="24" :src="row.userAvatar">{{ row.userNickname?.charAt(0) }}</el-avatar>
              <span class="user-name">{{ row.userNickname || '匿名用户' }}</span>
            </div>
          </template>
        </el-table-column>
        <!-- 评论内容列 -->
        <el-table-column prop="content" label="评论内容" min-width="250" show-overflow-tooltip />
        <!-- 状态列 -->
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)" size="small">{{ getStatusText(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <!-- 评论时间列 -->
        <el-table-column prop="createdAt" label="评论时间" width="160" align="center">
          <template #default="{ row }">
            <span class="time-text">{{ formatTime(row.createdAt) }}</span>
          </template>
        </el-table-column>
        <!-- 操作列 -->
        <el-table-column label="操作" width="260" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" type="success" link @click="handleApprove(row)" v-if="row.status === 0">通过</el-button>
            <el-button size="small" type="danger" link @click="handleReject(row)" v-if="row.status === 0">驳回</el-button>
            <el-button size="small" type="danger" link @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页组件 -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>

    <!-- 驳回原因弹窗 -->
    <el-dialog v-model="rejectDialogVisible" title="驳回原因" width="500px">
      <el-form :model="rejectForm" label-width="80px">
        <el-form-item label="驳回原因">
          <el-input v-model="rejectForm.reason" type="textarea" :rows="4" placeholder="请输入驳回原因" maxlength="200" show-word-limit />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="rejectDialogVisible = false">取消</el-button>
        <el-button type="danger" @click="confirmReject">确认驳回</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
/**
 * 评论审核页面组件
 * 审核人员使用的评论审核界面，支持查看、通过、驳回、删除操作
 * 支持批量审核和状态筛选功能
 * 注：后端暂无独立评论审核接口，使用评论管理接口，前端手动分页
 */
import { ref, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { commentApi } from '../api'

// 表格引用（用于全选操作）
const tableRef = ref(null)
// 统计数据（待审核/已通过/已驳回/总记录）
const stats = ref({ pending: 0, approved: 0, rejected: 0, total: 0 })
// 加载状态
const loading = ref(false)
// 评论列表数据
const commentList = ref([])
// 搜索关键词
const searchKeyword = ref('')
// 状态筛选（默认显示待审核）
const filterStatus = ref(0)
// 当前页码
const currentPage = ref(1)
// 每页条数
const pageSize = ref(10)
// 总条数
const total = ref(0)

// 选中的行数据
const selectedRows = ref([])
// 选中的ID列表（计算属性）
const selectedIds = computed(() => selectedRows.value.map(r => r.id))
// 选中的待审核数量（计算属性）
const pendingCount = computed(() => selectedRows.value.filter(c => c.status === 0).length)

// 驳回原因弹窗显示状态
const rejectDialogVisible = ref(false)
// 驳回表单数据（支持单个和批量驳回）
const rejectForm = ref({ reason: '', id: null, ids: [] })

// 状态映射表（评论状态：0=待审核, 1=已通过, 2=已驳回, 3=已删除）
const statusMap = { 0: '待审核', 1: '已通过', 2: '已驳回', 3: '已删除' }
const statusTypeMap = { 0: 'warning', 1: 'success', 2: 'danger', 3: 'info' }

/**
 * 获取状态文本
 * @param {number} status - 状态码
 * @returns {string} 状态名称
 */
const getStatusText = (status) => statusMap[status] || '未知'

/**
 * 获取状态对应的标签类型
 * @param {number} status - 状态码
 * @returns {string} Element Plus标签类型
 */
const getStatusType = (status) => statusTypeMap[status] || 'info'

/**
 * 格式化时间
 * @param {string} time - ISO时间字符串
 * @returns {string} 格式化后的时间（yyyy-MM-dd HH:mm）
 */
const formatTime = (time) => {
  if (!time) return '-'
  const d = new Date(time)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  const hh = String(d.getHours()).padStart(2, '0')
  const mm = String(d.getMinutes()).padStart(2, '0')
  return `${y}-${m}-${day} ${hh}:${mm}`
}

/**
 * 获取评论列表（前端手动分页）
 * 注：后端暂无评论审核接口，使用评论管理接口 /comment/all，前端手动过滤和分页
 */
const getCommentList = async () => {
  loading.value = true
  try {
    // 获取所有评论（后端不分页）
    const allComments = await commentApi.allList()
    let filtered = allComments || []

    // 关键字筛选（搜索评论内容或用户昵称）
    if (searchKeyword.value) {
      filtered = filtered.filter(c =>
        (c.content || '').includes(searchKeyword.value) ||
        (c.userNickname || '').includes(searchKeyword.value)
      )
    }

    // 状态筛选
    if (filterStatus.value !== '' && filterStatus.value !== null) {
      filtered = filtered.filter(c => c.status === filterStatus.value)
    }

    // 手动分页
    total.value = filtered.length
    const start = (currentPage.value - 1) * pageSize.value
    commentList.value = filtered.slice(start, start + pageSize.value)

    // 计算统计数据
    let pending = 0, approved = 0, rejected = 0
    filtered.forEach(c => {
      if (c.status === 0) pending++
      else if (c.status === 1) approved++
      else if (c.status === 2) rejected++
    })
    stats.value = { pending, approved, rejected, total: filtered.length }
  } catch (err) {
    console.error('获取评论列表失败:', err)
    commentList.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

/**
 * 处理搜索
 */
const handleSearch = () => {
  currentPage.value = 1
  getCommentList()
}

/**
 * 处理筛选条件变化
 */
const handleFilterChange = () => {
  currentPage.value = 1
  getCommentList()
}

/**
 * 快速筛选（点击统计卡片）
 * @param {number} status - 状态码
 */
const quickFilter = (status) => {
  filterStatus.value = status
  currentPage.value = 1
  getCommentList()
}

/**
 * 处理表格选择变化
 * @param {Array} rows - 选中的行数据
 */
const handleSelectionChange = (rows) => {
  selectedRows.value = rows
}

/**
 * 处理页码变化
 * @param {number} page - 新页码
 */
const handlePageChange = (page) => {
  currentPage.value = page
  getCommentList()
}

/**
 * 处理每页条数变化
 * @param {number} size - 新的每页条数
 */
const handleSizeChange = (size) => {
  pageSize.value = size
  getCommentList()
}

/**
 * 审核通过（单个）
 * @param {Object} row - 评论数据
 */
const handleApprove = async (row) => {
  try {
    await ElMessageBox.confirm('确定要通过这条评论吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'success'
    })
    // 更新状态：0=待审核, 1=已通过, 2=已驳回
    await commentApi.updateStatus({ id: row.id, status: 1 })
    ElMessage.success('审核通过')
    getCommentList()
  } catch (err) {
    if (err !== 'cancel') {
      console.error('操作失败:', err)
    }
  }
}

/**
 * 驳回评论（单个）- 打开驳回原因弹窗
 * @param {Object} row - 评论数据
 */
const handleReject = (row) => {
  rejectForm.value.id = row.id
  rejectForm.value.ids = []
  rejectForm.value.reason = ''
  rejectDialogVisible.value = true
}

/**
 * 确认驳回（支持单个和批量）
 * 驳回原因必填
 */
const confirmReject = async () => {
  // 验证驳回原因是否填写
  if (!rejectForm.value.reason.trim()) {
    ElMessage.warning('请输入驳回原因')
    return
  }
  try {
    if (rejectForm.value.ids && rejectForm.value.ids.length > 0) {
      // 批量驳回：循环调用更新状态
      for (const id of rejectForm.value.ids) {
        await commentApi.updateStatus({ id, status: 2 })
      }
    } else {
      // 单条驳回：status=2 表示已驳回
      await commentApi.updateStatus({ id: rejectForm.value.id, status: 2 })
    }
    ElMessage.success('已驳回')
    rejectDialogVisible.value = false
    rejectForm.value.ids = []
    getCommentList()
  } catch (err) {
    console.error('驳回失败:', err)
  }
}

/**
 * 删除评论（带确认）
 * @param {Object} row - 评论数据
 */
const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm('确定要删除这条评论吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await commentApi.delete(row.id)
    ElMessage.success('删除成功')
    getCommentList()
  } catch (err) {
    if (err !== 'cancel') {
      console.error('删除失败:', err)
    }
  }
}

/**
 * 批量通过审核
 */
const handleBatchApprove = async () => {
  // 只筛选待审核状态的评论
  const pendingRows = selectedRows.value.filter(r => r.status === 0)
  if (pendingRows.length === 0) {
    ElMessage.warning('请先选择待审核的评论')
    return
  }
  try {
    await ElMessageBox.confirm(`确定要通过选中的 ${pendingRows.length} 条评论吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'success'
    })
    // 批量通过：循环调用更新状态
    for (const row of pendingRows) {
      await commentApi.updateStatus({ id: row.id, status: 1 })
    }
    ElMessage.success('批量通过成功')
    getCommentList()
  } catch (err) {
    if (err !== 'cancel') {
      console.error('操作失败:', err)
    }
  }
}

/**
 * 批量驳回审核（打开驳回原因弹窗）
 */
const handleBatchReject = async () => {
  // 只筛选待审核状态的评论
  const pendingRows = selectedRows.value.filter(r => r.status === 0)
  if (pendingRows.length === 0) {
    ElMessage.warning('请先选择待审核的评论')
    return
  }
  try {
    await ElMessageBox.confirm(`确定要驳回选中的 ${pendingRows.length} 条评论吗？`, '提示', {
      confirmButtonText: '继续',
      cancelButtonText: '取消',
      type: 'warning'
    })
    // 设置批量驳回数据
    rejectForm.value.id = null
    rejectForm.value.ids = pendingRows.map(r => r.id)
    rejectForm.value.reason = ''
    rejectDialogVisible.value = true
  } catch (err) {
    if (err !== 'cancel') {
      console.error('操作失败:', err)
    }
  }
}

/**
 * 页面挂载时获取评论列表
 */
onMounted(() => {
  getCommentList()
})
</script>

<style scoped>
/* 页面容器 */
.review-container {
  padding: 0;
}

/* 统计卡片区域 */
.stat-cards {
  margin-bottom: 16px;
}

/* 统计卡片样式 */
.stat-card {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
}

.stat-card:hover {
  transform: translateY(-2px);
}

/* 统计图标 */
.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  margin-right: 16px;
}

/* 各状态卡片图标颜色（渐变背景） */
.stat-pending .stat-icon { background: linear-gradient(135deg, #fdf6ec, #f5e6c4); color: #e6a23c; }
.stat-approved .stat-icon { background: linear-gradient(135deg, #f0f9eb, #c8e6c9); color: #67c23a; }
.stat-rejected .stat-icon { background: linear-gradient(135deg, #fef0f0, #f5c2c2); color: #f56c6c; }
.stat-total .stat-icon { background: linear-gradient(135deg, #ecf5ff, #bbdefb); color: #409eff; }

/* 统计信息区域 */
.stat-info { flex: 1; }
.stat-value { font-size: 28px; font-weight: bold; color: #303133; }
.stat-label { font-size: 13px; color: #909399; margin-top: 2px; }

/* 主内容卡片 */
.content-card {
  margin-bottom: 16px;
}

/* 卡片头部 */
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* 标题 */
.title {
  font-size: 16px;
  font-weight: 600;
}

/* 头部操作区 */
.header-actions {
  display: flex;
  align-items: center;
}

/* 用户信息区域 */
.user-info {
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 用户名称 */
.user-name {
  margin-left: 8px;
  font-size: 14px;
  color: #303133;
}

/* 时间文本 */
.time-text {
  color: #606266;
  font-size: 13px;
}

/* 分页容器 */
.pagination-wrapper {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>
