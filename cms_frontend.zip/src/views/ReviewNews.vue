<template>
  <!-- 新闻审核页面容器 -->
  <div class="review-container">
    <!-- 统计卡片区域 -->
    <el-row :gutter="16" class="stat-cards">
      <!-- 待审核统计 -->
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card stat-pending" @click="quickFilter(1)">
          <div class="stat-icon"><el-icon><Clock /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.pending }}</div>
            <div class="stat-label">待审核</div>
          </div>
        </el-card>
      </el-col>
      <!-- 已通过统计 -->
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card stat-approved" @click="quickFilter(2)">
          <div class="stat-icon"><el-icon><CircleCheck /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.approved }}</div>
            <div class="stat-label">已通过</div>
          </div>
        </el-card>
      </el-col>
      <!-- 已驳回统计 -->
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card stat-rejected" @click="quickFilter(3)">
          <div class="stat-icon"><el-icon><CircleClose /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.rejected }}</div>
            <div class="stat-label">已驳回</div>
          </div>
        </el-card>
      </el-col>
      <!-- 总记录统计 -->
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card stat-total">
          <div class="stat-icon"><el-icon><Document /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.total }}</div>
            <div class="stat-label">总记录</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 主内容卡片 -->
    <el-card class="content-card">
      <!-- 卡片头部 -->
      <template #header>
        <div class="card-header">
          <span class="title">新闻审核</span>
          <!-- 搜索和筛选操作区 -->
          <div class="header-actions">
            <!-- 搜索输入框 -->
            <el-input
              v-model="searchKeyword"
              placeholder="搜索新闻标题"
              prefix-icon="Search"
              style="width: 180px; margin-right: 12px"
              clearable
              @clear="handleSearch"
              @keyup.enter="handleSearch"
            />
            <!-- 状态筛选 -->
            <el-select v-model="filterStatus" placeholder="状态筛选" clearable style="width: 130px; margin-right: 12px" @change="handleFilterChange">
              <el-option label="全部" :value="''" />
              <el-option label="待审核" :value="1" />
              <el-option label="已通过" :value="2" />
              <el-option label="已驳回" :value="3" />
            </el-select>
            <!-- 重置按钮 -->
            <el-button @click="handleReset">重置</el-button>
          </div>
        </div>
      </template>

      <!-- 批量操作工具栏 -->
      <div class="table-toolbar">
        <el-button type="success" @click="handleBatchApprove" :disabled="pendingCount === 0">
          <el-icon><CircleCheck /></el-icon> 批量通过 ({{ pendingCount }})
        </el-button>
        <el-button type="danger" @click="handleBatchReject" :disabled="pendingCount === 0">
          <el-icon><CircleClose /></el-icon> 批量驳回
        </el-button>
        <el-button type="primary" @click="handleAllCheck" v-if="!allChecked">全选</el-button>
        <el-button @click="handleAllUncheck" v-else>取消全选</el-button>
        <span class="selected-tip">已选 <b>{{ selectedIds.length }}</b> 项</span>
      </div>

      <!-- 新闻审核列表表格 -->
      <el-table
        ref="tableRef"
        :data="newsList"
        v-loading="loading"
        @selection-change="handleSelectionChange"
        stripe
        border
        max-height="calc(100vh - 420px)"
      >
        <!-- 多选列 -->
        <el-table-column type="selection" width="50" />
        <!-- ID列 -->
        <el-table-column prop="id" label="ID" width="70" align="center" />
        <!-- 封面列 -->
        <el-table-column label="封面" width="110" align="center">
          <template #default="{ row }">
            <el-image
              :src="row.coverUrl || getPlaceholder(row.id)"
              fit="cover"
              style="width: 90px; height: 60px; border-radius: 4px"
              :preview-src-list="row.coverUrl ? [row.coverUrl] : []"
            >
              <template #error>
                <div class="image-placeholder">
                  <el-icon><Picture /></el-icon>
                </div>
              </template>
            </el-image>
          </template>
        </el-table-column>
        <!-- 标题列 -->
        <el-table-column prop="title" label="新闻标题" min-width="260" show-overflow-tooltip>
          <template #default="{ row }">
            <span class="news-title" @click="handleView(row)">{{ row.title }}</span>
          </template>
        </el-table-column>
        <!-- 作者列 -->
        <el-table-column prop="authorNickname" label="作者" width="110" align="center" />
        <!-- 栏目列 -->
        <el-table-column prop="categoryName" label="栏目" width="110" align="center" />
        <!-- 状态列 -->
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)" size="small">{{ getStatusText(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <!-- 提交时间列 -->
        <el-table-column prop="submittedAt" label="提交时间" width="160" align="center">
          <template #default="{ row }">
            <span class="time-text">{{ formatTime(row.submittedAt) }}</span>
          </template>
        </el-table-column>
        <!-- 操作列 -->
        <el-table-column label="操作" width="200" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" type="primary" link @click="handleView(row)">查看</el-button>
            <el-button size="small" type="success" link @click="handleApprove(row)" v-if="row.status === 1">通过</el-button>
            <el-button size="small" type="danger" link @click="handleReject(row)" v-if="row.status === 1">驳回</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页组件 -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>

    <!-- 新闻详情弹窗（审核时查看） -->
    <el-dialog v-model="detailDialogVisible" title="新闻详情" width="900px" destroy-on-close>
      <div v-if="currentNews" class="news-detail">
        <h2 class="detail-title">{{ currentNews.title }}</h2>
        <div class="detail-meta">
          <el-tag size="small" type="info" effect="plain">{{ currentNews.categoryName || '未分类' }}</el-tag>
          <span class="meta-item">
            <el-icon><User /></el-icon> {{ currentNews.authorNickname || '匿名' }}
          </span>
          <span class="meta-item">
            <el-icon><Calendar /></el-icon> {{ formatTime(currentNews.submittedAt) }}
          </span>
          <el-tag :type="getStatusType(currentNews.status)" size="small">{{ getStatusText(currentNews.status) }}</el-tag>
        </div>
        <!-- 新闻封面 -->
        <el-image v-if="currentNews.coverUrl" :src="currentNews.coverUrl" class="detail-cover" fit="cover">
          <template #error>
            <div class="image-placeholder-large">
              <el-icon><PictureFilled /></el-icon>
            </div>
          </template>
        </el-image>
        <!-- 新闻内容（富文本渲染） -->
        <div class="detail-content" v-html="currentNews.content || '无内容'"></div>
      </div>
      <!-- 弹窗底部操作按钮 -->
      <template #footer>
        <el-button @click="detailDialogVisible = false">关闭</el-button>
        <el-button type="success" @click="handleApproveFromDetail" v-if="currentNews && currentNews.status === 1">
          <el-icon><CircleCheck /></el-icon> 通过
        </el-button>
        <el-button type="danger" @click="handleRejectFromDetail" v-if="currentNews && currentNews.status === 1">
          <el-icon><CircleClose /></el-icon> 驳回
        </el-button>
      </template>
    </el-dialog>

    <!-- 驳回原因弹窗 -->
    <el-dialog v-model="rejectDialogVisible" title="驳回原因" width="500px">
      <el-form :model="rejectForm" label-width="80px">
        <el-form-item label="驳回原因">
          <el-input v-model="rejectForm.reason" type="textarea" :rows="5" placeholder="请输入驳回原因（可选）" maxlength="200" show-word-limit />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="rejectDialogVisible = false">取消</el-button>
        <el-button type="danger" @click="confirmReject">确认驳回</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
/**
 * 新闻审核页面组件
 * 审核人员使用的新闻审核界面，支持查看详情、通过、驳回操作
 * 支持批量审核和状态筛选功能
 * 注：后端暂无独立新闻审核接口，暂时复用文章审核接口
 */
import { ref, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { reviewApi } from '../api'

// 表格引用（用于全选操作）
const tableRef = ref(null)
// 统计数据（待审核/已通过/已驳回/总记录）
const stats = ref({ pending: 0, approved: 0, rejected: 0, total: 0 })
// 加载状态
const loading = ref(false)
// 新闻列表数据
const newsList = ref([])
// 搜索关键词
const searchKeyword = ref('')
// 状态筛选（默认显示待审核）
const filterStatus = ref(1)
// 当前页码
const currentPage = ref(1)
// 每页条数
const pageSize = ref(10)
// 总条数
const total = ref(0)

// 选中的行数据
const selectedRows = ref([])
// 选中的ID列表（计算属性）
const selectedIds = computed(() => selectedRows.value.map(r => r.id))
// 选中的待审核数量（计算属性）
const pendingCount = computed(() => selectedRows.value.filter(a => a.status === 1).length)
// 是否全选（计算属性）
const allChecked = computed(() => selectedRows.value.length === newsList.value.length && newsList.value.length > 0)

// 详情弹窗显示状态
const detailDialogVisible = ref(false)
// 当前查看的新闻
const currentNews = ref(null)

// 驳回原因弹窗显示状态
const rejectDialogVisible = ref(false)
// 驳回表单数据（支持单个和批量驳回）
const rejectForm = ref({ reason: '', id: null, ids: [] })

// 状态映射表
const statusMap = { 0: '草稿', 1: '待审核', 2: '已通过', 3: '已驳回', 4: '已下架' }
const statusTypeMap = { 0: 'info', 1: 'warning', 2: 'success', 3: 'danger', 4: 'info' }

/**
 * 获取状态文本
 * @param {number} status - 状态码
 * @returns {string} 状态名称
 */
const getStatusText = (status) => statusMap[status] || '未知'

/**
 * 获取状态对应的标签类型
 * @param {number} status - 状态码
 * @returns {string} Element Plus标签类型
 */
const getStatusType = (status) => statusTypeMap[status] || 'info'

/**
 * 格式化时间
 * @param {string} time - ISO时间字符串
 * @returns {string} 格式化后的时间（yyyy-MM-dd HH:mm）
 */
const formatTime = (time) => {
  if (!time) return '-'
  const d = new Date(time)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  const hh = String(d.getHours()).padStart(2, '0')
  const mm = String(d.getMinutes()).padStart(2, '0')
  return `${y}-${m}-${day} ${hh}:${mm}`
}

/**
 * 获取图片占位图（无封面时使用）
 * @param {number} id - 新闻ID
 * @returns {string} 占位图URL
 */
const getPlaceholder = (id) => `https://picsum.photos/seed/${id}/90/60`

/**
 * 获取新闻审核列表
 * 同时计算各状态统计数据
 * 注：后端暂无独立新闻审核接口，暂时复用文章审核接口
 */
const getNewsList = async () => {
  loading.value = true
  try {
    const params = { pageNum: currentPage.value, pageSize: pageSize.value }
    // 添加搜索条件
    if (searchKeyword.value) {
      params.keyword = searchKeyword.value
    }
    // 添加状态筛选条件
    if (filterStatus.value !== '' && filterStatus.value !== null) {
      params.status = filterStatus.value
    }
    // 后端暂无新闻审核接口，暂时复用文章审核接口
    const result = await reviewApi.articleList(params)
    const pageResult = result || {}
    newsList.value = pageResult.records || []
    total.value = pageResult.total || 0

    // 计算统计数据
    let pending = 0, approved = 0, rejected = 0
    newsList.value.forEach(a => {
      if (a.status === 1) pending++
      else if (a.status === 2) approved++
      else if (a.status === 3) rejected++
    })
    stats.value = { pending, approved, rejected, total: total.value }
  } catch (err) {
    console.error('获取新闻审核列表失败:', err)
  } finally {
    loading.value = false
  }
}

/**
 * 处理搜索
 */
const handleSearch = () => {
  currentPage.value = 1
  getNewsList()
}

/**
 * 处理筛选条件变化
 */
const handleFilterChange = () => {
  currentPage.value = 1
  getNewsList()
}

/**
 * 重置筛选条件（恢复默认：显示待审核）
 */
const handleReset = () => {
  searchKeyword.value = ''
  filterStatus.value = 1
  currentPage.value = 1
  getNewsList()
}

/**
 * 快速筛选（点击统计卡片）
 * @param {number} status - 状态码
 */
const quickFilter = (status) => {
  filterStatus.value = status
  currentPage.value = 1
  getNewsList()
}

/**
 * 处理表格选择变化
 * @param {Array} rows - 选中的行数据
 */
const handleSelectionChange = (rows) => {
  selectedRows.value = rows
}

/**
 * 全选所有行
 */
const handleAllCheck = () => {
  tableRef.value?.toggleAllSelection()
}

/**
 * 取消全选
 */
const handleAllUncheck = () => {
  tableRef.value?.clearSelection()
}

/**
 * 处理页码变化
 * @param {number} page - 新页码
 */
const handlePageChange = (page) => {
  currentPage.value = page
  getNewsList()
}

/**
 * 处理每页条数变化
 * @param {number} size - 新的每页条数
 */
const handleSizeChange = (size) => {
  pageSize.value = size
  getNewsList()
}

/**
 * 查看新闻详情
 * @param {Object} row - 新闻数据
 */
const handleView = (row) => {
  currentNews.value = row
  detailDialogVisible.value = true
}

/**
 * 审核通过（单个）
 * @param {Object} row - 新闻数据
 */
const handleApprove = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要通过新闻《${row.title}》吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'success'
    })
    await reviewApi.approveNews(row.id)
    ElMessage.success('审核通过')
    getNewsList()
  } catch (err) {
    if (err !== 'cancel') {
      console.error('审核失败:', err)
    }
  }
}

/**
 * 从详情弹窗审核通过
 */
const handleApproveFromDetail = async () => {
  await handleApprove(currentNews.value)
  detailDialogVisible.value = false
}

/**
 * 驳回新闻（单个）- 打开驳回原因弹窗
 * @param {Object} row - 新闻数据
 */
const handleReject = (row) => {
  rejectForm.value.id = row.id
  rejectForm.value.ids = []
  rejectForm.value.reason = ''
  rejectDialogVisible.value = true
}

/**
 * 从详情弹窗驳回新闻
 */
const handleRejectFromDetail = () => {
  rejectForm.value.id = currentNews.value.id
  rejectForm.value.ids = []
  rejectForm.value.reason = ''
  rejectDialogVisible.value = true
  detailDialogVisible.value = false
}

/**
 * 确认驳回（支持单个和批量）
 */
const confirmReject = async () => {
  try {
    if (rejectForm.value.ids && rejectForm.value.ids.length > 0) {
      // 批量驳回
      await reviewApi.batchReject({ ids: rejectForm.value.ids, reason: rejectForm.value.reason })
    } else {
      // 单个驳回（后端暂无新闻审核接口，暂时复用文章审核接口）
      await reviewApi.rejectArticle({ id: rejectForm.value.id, reason: rejectForm.value.reason })
    }
    ElMessage.success('已驳回')
    rejectDialogVisible.value = false
    rejectForm.value.ids = []
    getNewsList()
  } catch (err) {
    console.error('驳回失败:', err)
  }
}

/**
 * 批量通过审核
 */
const handleBatchApprove = async () => {
  // 只筛选待审核状态的新闻
  const pendingRows = selectedRows.value.filter(r => r.status === 1)
  if (pendingRows.length === 0) {
    ElMessage.warning('请先选择待审核的新闻')
    return
  }
  try {
    await ElMessageBox.confirm(`确定要通过选中的 ${pendingRows.length} 篇新闻吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'success'
    })
    const ids = pendingRows.map(r => r.id)
    await reviewApi.batchApprove({ ids })
    ElMessage.success('批量通过成功')
    getNewsList()
  } catch (err) {
    if (err !== 'cancel') {
      console.error('批量通过失败:', err)
    }
  }
}

/**
 * 批量驳回审核（打开驳回原因弹窗）
 */
const handleBatchReject = async () => {
  // 只筛选待审核状态的新闻
  const pendingRows = selectedRows.value.filter(r => r.status === 1)
  if (pendingRows.length === 0) {
    ElMessage.warning('请先选择待审核的新闻')
    return
  }
  try {
    await ElMessageBox.confirm(`确定要驳回选中的 ${pendingRows.length} 篇新闻吗？`, '提示', {
      confirmButtonText: '继续',
      cancelButtonText: '取消',
      type: 'warning'
    })
    // 设置批量驳回数据
    rejectForm.value.id = null
    rejectForm.value.ids = pendingRows.map(r => r.id)
    rejectForm.value.reason = ''
    rejectDialogVisible.value = true
  } catch (err) {
    if (err !== 'cancel') {
      console.error('批量驳回失败:', err)
    }
  }
}

/**
 * 页面挂载时获取审核列表
 */
onMounted(async () => {
  await getNewsList()
})
</script>

<style scoped>
/* 页面容器 */
.review-container {
  padding: 0;
}

/* 统计卡片区域 */
.stat-cards {
  margin-bottom: 16px;
}

/* 统计卡片 */
.stat-card {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
}

.stat-card:hover {
  transform: translateY(-2px);
}

/* 统计图标 */
.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  margin-right: 16px;
}

/* 各状态统计卡片的图标颜色 */
.stat-pending .stat-icon { background: linear-gradient(135deg, #fdf6ec, #f5e6c4); color: #e6a23c; }
.stat-approved .stat-icon { background: linear-gradient(135deg, #f0f9eb, #c8e6c9); color: #67c23a; }
.stat-rejected .stat-icon { background: linear-gradient(135deg, #fef0f0, #f5c2c2); color: #f56c6c; }
.stat-total .stat-icon { background: linear-gradient(135deg, #ecf5ff, #bbdefb); color: #409eff; }

/* 统计信息 */
.stat-info { flex: 1; }
.stat-value { font-size: 28px; font-weight: bold; color: #303133; }
.stat-label { font-size: 13px; color: #909399; margin-top: 2px; }

/* 主内容卡片 */
.content-card {
  margin-bottom: 16px;
}

/* 卡片头部 */
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.title {
  font-size: 16px;
  font-weight: 600;
}

.header-actions {
  display: flex;
  align-items: center;
}

/* 批量操作工具栏 */
.table-toolbar {
  margin-bottom: 12px;
  padding-bottom: 12px;
  border-bottom: 1px solid #ebeef5;
  display: flex;
  align-items: center;
  gap: 10px;
}

.selected-tip {
  color: #909399;
  font-size: 13px;
  margin-left: 8px;
}

/* 新闻标题（可点击） */
.news-title {
  color: #303133;
  cursor: pointer;
  transition: color 0.2s;
  font-weight: 500;
}

.news-title:hover {
  color: #409eff;
}

/* 图片占位图（小尺寸） */
.image-placeholder {
  width: 90px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  border-radius: 4px;
  color: #c0c4cc;
}

/* 图片占位图（大尺寸） */
.image-placeholder-large {
  width: 100%;
  height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  border-radius: 8px;
  color: #c0c4cc;
  font-size: 48px;
}

.time-text {
  color: #606266;
  font-size: 13px;
}

/* 分页组件 */
.pagination-wrapper {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

/* 新闻详情区域 */
.news-detail {
  max-height: 65vh;
  overflow-y: auto;
  padding-right: 8px;
}

.detail-title {
  font-size: 22px;
  font-weight: 600;
  margin: 0 0 16px 0;
  color: #303133;
}

/* 详情页元信息 */
.detail-meta {
  display: flex;
  align-items: center;
  gap: 16px;
  color: #909399;
  font-size: 14px;
  margin-bottom: 20px;
  padding-bottom: 16px;
  border-bottom: 1px solid #ebeef5;
  flex-wrap: wrap;
}

.detail-meta .meta-item {
  display: flex;
  align-items: center;
  gap: 6px;
}

/* 详情页封面图 */
.detail-cover {
  width: 100%;
  max-height: 400px;
  margin-bottom: 20px;
  border-radius: 8px;
  overflow: hidden;
}

/* 详情页正文内容 */
.detail-content {
  line-height: 2;
  font-size: 15px;
  color: #303133;
}

/* 深度选择器：正文内的图片 */
.detail-content :deep(img) {
  max-width: 100%;
  border-radius: 4px;
}

/* 深度选择器：正文内的段落 */
.detail-content :deep(p) {
  margin: 12px 0;
}

/* 深度选择器：正文内的标题 */
.detail-content :deep(h1), .detail-content :deep(h2), .detail-content :deep(h3) {
  margin: 20px 0 12px 0;
  font-weight: 600;
}
</style>
