<template>
  <!-- 新闻列表页面容器 -->
  <div class="news-list-container">
    <el-card shadow="never" class="main-card">
      <!-- 卡片头部 -->
      <template #header>
        <div class="card-header">
          <!-- 左侧标题区 -->
          <div class="header-left">
            <el-icon class="header-icon"><News /></el-icon>
            <span class="title">新闻列表</span>
            <el-tag size="small" type="info" effect="plain">共 {{ total }} 条</el-tag>
          </div>
          <!-- 右侧操作区 -->
          <div class="header-actions">
            <!-- 搜索输入框 -->
            <el-input
              v-model="searchKeyword"
              placeholder="搜索新闻标题"
              prefix-icon="Search"
              style="width: 200px; margin-right: 12px"
              clearable
              @clear="handleSearch"
              @keyup.enter="handleSearch"
            />
            <!-- 栏目筛选 -->
            <el-select v-model="searchCategory" placeholder="选择栏目" style="width: 150px; margin-right: 12px" clearable @change="handleSearch">
              <el-option v-for="cat in categories" :key="cat.id" :label="cat.name" :value="cat.id" />
            </el-select>
            <!-- 搜索按钮 -->
            <el-button type="primary" @click="handleSearch">
              <el-icon><Search /></el-icon> 搜索
            </el-button>
            <!-- 刷新按钮 -->
            <el-button @click="handleRefresh">
              <el-icon><Refresh /></el-icon> 刷新
            </el-button>
          </div>
        </div>
      </template>

      <!-- 新闻列表表格 -->
      <el-table
        :data="newsList"
        v-loading="loading"
        stripe
        border
        :max-height="tableHeight"
        empty-text="暂无新闻数据"
        @row-click="handleView"
        :row-style="{ cursor: 'pointer' }"
      >
        <!-- 序号列 -->
        <el-table-column type="index" label="#" width="55" align="center" />
        <!-- 封面图列 -->
        <el-table-column label="封面图" width="120" align="center">
          <template #default="{ row }">
            <el-image
              :src="row.coverUrl || getPlaceholder(row.id)"
              fit="cover"
              style="width: 100px; height: 60px; border-radius: 4px"
              :preview-src-list="row.coverUrl ? [row.coverUrl] : []"
              preview-teleported
            >
              <!-- 图片加载失败占位 -->
              <template #error>
                <div class="image-placeholder">
                  <el-icon><Picture /></el-icon>
                </div>
              </template>
            </el-image>
          </template>
        </el-table-column>
        <!-- 标题列 -->
        <el-table-column prop="title" label="新闻标题" min-width="240" show-overflow-tooltip>
          <template #default="{ row }">
            <span class="news-title">{{ row.title }}</span>
            <el-tag v-if="row.isTop" size="small" type="danger" class="ml-2" effect="dark">置顶</el-tag>
          </template>
        </el-table-column>
        <!-- 栏目列 -->
        <el-table-column prop="categoryName" label="所属栏目" width="120" align="center">
          <template #default="{ row }">
            <el-tag v-if="row.categoryName" size="small" effect="plain">{{ row.categoryName }}</el-tag>
            <span v-else>-</span>
          </template>
        </el-table-column>
        <!-- 作者列 -->
        <el-table-column prop="authorNickname" label="作者" width="100" align="center" />
        <!-- 状态列 -->
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)" size="small">{{ getStatusText(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <!-- 数据统计列 -->
        <el-table-column label="数据" width="160" align="center">
          <template #default="{ row }">
            <div class="data-cell">
              <span class="data-item"><el-icon><View /></el-icon> {{ row.viewCount || 0 }}</span>
              <span class="data-item"><el-icon><Star /></el-icon> {{ row.likeCount || 0 }}</span>
            </div>
          </template>
        </el-table-column>
        <!-- 发布时间列 -->
        <el-table-column prop="publishedAt" label="发布时间" width="170" align="center">
          <template #default="{ row }">
            <span class="time-text">{{ formatTime(row.publishedAt) }}</span>
          </template>
        </el-table-column>
        <!-- 操作列 -->
        <el-table-column label="操作" width="180" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" type="primary" link @click.stop="handleView(row)">查看</el-button>
            <el-button size="small" type="success" link @click.stop="handleEdit(row)">编辑</el-button>
            <el-button size="small" type="danger" link @click.stop="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页组件 -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          background
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
/**
 * 新闻列表页面组件
 * 展示新闻列表，支持搜索、分页、查看详情、编辑、删除功能
 */
import { ref, onMounted, onUnmounted, getCurrentInstance } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { format } from 'date-fns'

const { proxy } = getCurrentInstance()
const router = useRouter()

// 搜索关键词
const searchKeyword = ref('')
// 栏目筛选
const searchCategory = ref('')
// 加载状态
const loading = ref(false)
// 新闻列表数据
const newsList = ref([])
// 栏目列表
const categories = ref([])
// 当前页码
const currentPage = ref(1)
// 每页条数
const pageSize = ref(10)
// 总条数
const total = ref(0)
// 表格高度
const tableHeight = ref(500)

/**
 * 更新表格高度（响应窗口大小变化）
 */
const updateTableHeight = () => {
  tableHeight.value = window.innerHeight - 280
}

// 状态映射表
const statusMap = { 0: '草稿', 1: '待审核', 2: '已发布', 3: '已驳回', 4: '已下架' }
const statusTypeMap = { 0: 'info', 1: 'warning', 2: 'success', 3: 'danger', 4: 'warning' }

/**
 * 获取状态文本
 * @param {number} status - 状态码
 * @returns {string} 状态名称
 */
const getStatusText = (status) => statusMap[status] || '未知'

/**
 * 获取状态对应的标签类型
 * @param {number} status - 状态码
 * @returns {string} Element Plus标签类型
 */
const getStatusType = (status) => statusTypeMap[status] || 'info'

/**
 * 格式化时间
 * @param {string} time - ISO时间字符串
 * @returns {string} 格式化后的时间
 */
const formatTime = (time) => {
  return time ? format(new Date(time), 'yyyy-MM-dd HH:mm') : '-'
}

/**
 * 获取图片占位图（无封面时使用）
 * @param {number} id - 新闻ID
 * @returns {string} 占位图URL
 */
const getPlaceholder = (id) => `https://picsum.photos/seed/news${id}/100/60`

/**
 * 获取栏目列表
 */
const getCategories = async () => {
  try {
    const data = await proxy.$api.category.list()
    categories.value = data || []
  } catch (err) {
    console.error('获取栏目失败:', err)
  }
}

/**
 * 获取新闻列表
 */
const getNewsList = async () => {
  loading.value = true
  try {
    const params = {
      pageNum: currentPage.value,
      pageSize: pageSize.value
    }
    // 添加搜索条件
    if (searchKeyword.value) params.keyword = searchKeyword.value
    if (searchCategory.value) params.categoryId = searchCategory.value

    const result = await proxy.$api.article.list(params)
    const pageResult = result || {}
    newsList.value = pageResult.records || []
    total.value = pageResult.total || 0
  } catch (err) {
    console.error('获取新闻列表失败:', err)
  } finally {
    loading.value = false
  }
}

/**
 * 处理搜索
 */
const handleSearch = () => {
  currentPage.value = 1
  getNewsList()
}

/**
 * 处理刷新
 */
const handleRefresh = () => {
  searchKeyword.value = ''
  searchCategory.value = ''
  currentPage.value = 1
  getNewsList()
  ElMessage.success('刷新成功')
}

/**
 * 处理页码变化
 * @param {number} page - 新页码
 */
const handlePageChange = (page) => {
  currentPage.value = page
  getNewsList()
}

/**
 * 处理每页条数变化
 * @param {number} size - 新的每页条数
 */
const handleSizeChange = (size) => {
  pageSize.value = size
  currentPage.value = 1
  getNewsList()
}

/**
 * 查看新闻详情
 * @param {Object} row - 新闻数据
 */
const handleView = (row) => {
  router.push(`/article/${row.id}`)
}

/**
 * 编辑新闻
 * @param {Object} row - 新闻数据
 */
const handleEdit = (row) => {
  router.push(`/article/edit/${row.id}`)
}

/**
 * 删除新闻（带确认）
 * @param {Object} row - 新闻数据
 */
const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要删除新闻《${row.title}》吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await proxy.$api.article.delete(row.id)
    ElMessage.success('删除成功')
    getNewsList()
  } catch (err) {
    if (err !== 'cancel') {
      console.error('删除失败:', err)
    }
  }
}

/**
 * 页面挂载时执行
 */
onMounted(async () => {
  updateTableHeight()
  window.addEventListener('resize', updateTableHeight)
  await Promise.all([getCategories(), getNewsList()])
})

/**
 * 页面卸载时清理
 */
onUnmounted(() => {
  window.removeEventListener('resize', updateTableHeight)
})
</script>

<style scoped>
.news-list-container {
  padding: 0;
}

.main-card {
  border-radius: 8px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-icon {
  font-size: 18px;
  color: #409eff;
}

.title {
  font-size: 16px;
  font-weight: 600;
}

.header-actions {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
}

.news-title {
  color: #303133;
  font-weight: 500;
  transition: color 0.2s;
}

.el-table .el-table__row:hover .news-title {
  color: #409eff;
}

.data-cell {
  display: flex;
  justify-content: center;
  gap: 12px;
}

.data-item {
  display: flex;
  align-items: center;
  gap: 3px;
  font-size: 12px;
  color: #606266;
}

.time-text {
  color: #606266;
  font-size: 13px;
}

.pagination-wrapper {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.image-placeholder {
  width: 100px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  border-radius: 4px;
  color: #c0c4cc;
}

.ml-2 {
  margin-left: 8px;
}
</style>
