<template>
  <!-- 文章详情页面容器 -->
  <div class="article-detail-container">
    <!-- 顶部操作栏 -->
    <div class="detail-toolbar">
      <!-- 返回按钮 -->
      <el-button @click="goBack" size="large" round>
        <el-icon><ArrowLeft /></el-icon> 返回
      </el-button>
      <!-- 右侧操作按钮组 -->
      <div class="toolbar-right">
        <!-- 点赞按钮 -->
        <el-button type="primary" size="large" :icon="isLiked ? 'StarFilled' : 'Star'" @click="handleLike" round>
          {{ isLiked ? '已点赞' : '点赞' }} {{ article.likeCount || 0 }}
        </el-button>
        <!-- 评论按钮 -->
        <el-button type="success" size="large" round @click="scrollToComment">
          <el-icon><ChatLineSquare /></el-icon> 评论 {{ article.commentCount || 0 }}
        </el-button>
      </div>
    </div>

    <!-- 文章主内容卡片 -->
    <el-card shadow="never" class="article-card">
      <!-- 文章头部信息 -->
      <div class="article-header">
        <!-- 文章标题 -->
        <h1 class="article-title">{{ article.title }}</h1>
        <!-- 文章元信息（作者、时间、分类） -->
        <div class="article-meta">
          <el-avatar :size="36" class="meta-avatar">
            {{ (article.authorNickname || '匿').charAt(0) }}
          </el-avatar>
          <div class="meta-info">
            <div class="meta-name">{{ article.authorNickname || '匿名' }}</div>
            <div class="meta-time">
              <el-icon><Clock /></el-icon>
              <span>发布于 {{ formatTime(article.publishedAt) }}</span>
            </div>
          </div>
          <!-- 分类标签 -->
          <el-tag v-if="article.categoryName" type="primary" effect="plain" size="large" class="meta-tag">
            {{ article.categoryName }}
          </el-tag>
        </div>

        <!-- 文章统计数据（浏览、点赞、评论） -->
        <div class="article-stats">
          <div class="stat-item">
            <el-icon><View /></el-icon>
            <span class="stat-num">{{ formatNumber(article.viewCount) }}</span>
            <span class="stat-label">浏览</span>
          </div>
          <div class="stat-item">
            <el-icon color="#f56c6c"><Star /></el-icon>
            <span class="stat-num">{{ formatNumber(article.likeCount) }}</span>
            <span class="stat-label">点赞</span>
          </div>
          <div class="stat-item">
            <el-icon color="#409eff"><ChatDotRound /></el-icon>
            <span class="stat-num">{{ formatNumber(article.commentCount) }}</span>
            <span class="stat-label">评论</span>
          </div>
        </div>
      </div>

      <!-- 文章封面图 -->
      <el-image
        v-if="article.coverUrl"
        :src="article.coverUrl"
        class="article-cover"
        fit="cover"
        :preview-src-list="[article.coverUrl]"
        hide-on-click-modal
        preview-teleported
      >
        <!-- 封面加载失败时的占位图 -->
        <template #error>
          <div class="cover-error">
            <el-icon :size="48"><PictureFilled /></el-icon>
            <span>封面加载失败</span>
          </div>
        </template>
      </el-image>

      <!-- 文章摘要 -->
      <div v-if="article.summary" class="article-summary">
        <el-icon class="summary-icon"><InfoFilled /></el-icon>
        <span>{{ article.summary }}</span>
      </div>

      <!-- 文章正文内容（富文本渲染） -->
      <div class="article-content" v-html="article.content || '<p class=\'empty-content\'>暂无内容</p>'"></div>

      <!-- 文章关键词标签 -->
      <div class="article-keywords" v-if="article.keywords">
        <el-icon><CollectionTag /></el-icon>
        <el-tag v-for="kw in keywordsList" :key="kw" type="info" effect="plain" class="keyword-tag">
          {{ kw }}
        </el-tag>
      </div>

      <!-- 正文结束分割线 -->
      <el-divider>
        <el-icon><Promotion /></el-icon>
        <span class="divider-text">正文结束</span>
      </el-divider>

      <!-- 底部操作按钮 -->
      <div class="article-actions">
        <el-button
          type="danger"
          size="large"
          round
          :icon="isLiked ? 'StarFilled' : 'Star'"
          @click="handleLike"
        >
          {{ isLiked ? '已点赞' : '点赞支持' }}
        </el-button>
        <el-button type="primary" size="large" round @click="scrollToComment">
          <el-icon><ChatLineSquare /></el-icon> 发表评论
        </el-button>
        <el-button size="large" round @click="handleShare">
          <el-icon><Share /></el-icon> 分享
        </el-button>
      </div>
    </el-card>

    <!-- 评论区卡片 -->
    <el-card shadow="never" class="comment-card" id="comment-section">
      <template #header>
        <div class="comment-header">
          <span class="title">
            <el-icon><ChatDotRound /></el-icon>
            评论区 ({{ article.commentCount || 0 }})
          </span>
        </div>
      </template>

      <!-- 评论列表组件 -->
      <CommentList v-if="article.id" :article-id="article.id" />
    </el-card>
  </div>
</template>

<script setup>
/**
 * 文章详情页面组件
 * 展示文章完整内容，包含点赞、评论、分享功能
 * 支持图片预览、关键词标签展示
 */
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { articleApi } from '../api'
import CommentList from '../components/CommentList.vue'

// 路由实例
const route = useRoute()
const router = useRouter()
// 从路由参数获取文章ID
const articleId = route.params.id
// 文章详情数据
const article = ref({})
// 当前用户是否已点赞
const isLiked = ref(false)

/**
 * 关键词列表（计算属性）
 * 将逗号分隔的关键词字符串转换为数组
 */
const keywordsList = computed(() => {
  if (!article.value.keywords) return []
  return article.value.keywords.split(/[,，]/).filter(k => k.trim())
})

/**
 * 数字格式化函数
 * 大于1万时显示为 x.xw 格式，否则显示带千分位的数字
 * @param {number} num - 待格式化的数字
 * @returns {string} 格式化后的数字字符串
 */
const formatNumber = (num) => {
  if (num === null || num === undefined) return 0
  return num >= 10000 ? (num / 10000).toFixed(1) + 'w' : num.toLocaleString()
}

/**
 * 时间格式化函数
 * 将时间戳或ISO字符串转换为中文格式
 * @param {string|number} time - 时间值
 * @returns {string} 格式化后的时间字符串
 */
const formatTime = (time) => {
  if (!time) return '暂无'
  const d = new Date(time)
  return d.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

/**
 * 获取文章详情
 * 同时检查当前用户是否已点赞
 */
const getArticleDetail = async () => {
  try {
    // 调用API获取文章详情
    const data = await articleApi.getDetail(articleId)
    article.value = data || {}
    // 如果用户已登录，检查是否已点赞
    if (localStorage.getItem('token')) {
      const liked = await articleApi.checkLike(articleId)
      isLiked.value = !!liked
    }
  } catch (err) {
    console.error('获取文章详情失败:', err)
  }
}

/**
 * 处理点赞操作
 * 未登录时跳转到登录页
 * 登录后切换点赞状态
 */
const handleLike = async () => {
  // 未登录时提示并跳转登录页
  if (!localStorage.getItem('token')) {
    ElMessage.warning('请先登录后再点赞')
    router.push('/login')
    return
  }
  try {
    // 调用点赞接口
    await articleApi.toggleLike(articleId)
    // 更新点赞数（取消点赞减1，点赞加1）
    article.value.likeCount += isLiked.value ? -1 : 1
    // 切换点赞状态
    isLiked.value = !isLiked.value
    ElMessage.success(isLiked.value ? '点赞成功！' : '已取消点赞')
  } catch (err) {
    console.error('操作失败:', err)
  }
}

/**
 * 滚动到评论区
 */
const scrollToComment = () => {
  const el = document.getElementById('comment-section')
  if (el) {
    el.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }
}

/**
 * 分享功能
 * 优先使用原生分享API，不支持时复制链接到剪贴板
 */
const handleShare = async () => {
  try {
    if (navigator.share) {
      // 浏览器支持原生分享API
      await navigator.share({
        title: article.value.title,
        text: article.value.summary,
        url: window.location.href
      })
    } else {
      // 复制链接到剪贴板
      await navigator.clipboard.writeText(window.location.href)
      ElMessage.success('链接已复制到剪贴板')
    }
  } catch (err) {
    console.error('分享失败:', err)
  }
}

/**
 * 返回上一页
 * 如果没有历史记录则跳转到文章列表页
 */
const goBack = () => {
  if (window.history.length > 1) {
    router.back()
    return
  }
  router.push('/article/list')
}

/**
 * 页面挂载时获取文章详情
 */
onMounted(async () => {
  await getArticleDetail()
})
</script>

<style scoped>
/* 页面容器 */
.article-detail-container {
  max-width: 960px;
  margin: 0 auto;
  padding: 20px 0;
}

/* 顶部操作栏 */
.detail-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  flex-wrap: wrap;
  gap: 12px;
}

.toolbar-right {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}

/* 文章卡片 */
.article-card {
  border-radius: 12px;
  margin-bottom: 20px;
  border: none;
}

/* 文章头部 */
.article-header {
  padding-bottom: 20px;
  border-bottom: 1px dashed #ebeef5;
  margin-bottom: 24px;
}

.article-title {
  font-size: 30px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 20px;
  line-height: 1.4;
  letter-spacing: 0.5px;
}

/* 文章元信息 */
.article-meta {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}

.meta-avatar {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
  font-weight: 600;
  flex-shrink: 0;
}

.meta-info {
  flex: 1;
}

.meta-name {
  font-size: 15px;
  font-weight: 600;
  color: #303133;
}

.meta-time {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  color: #909399;
  margin-top: 2px;
}

.meta-tag {
  flex-shrink: 0;
}

/* 统计数据 */
.article-stats {
  display: flex;
  gap: 24px;
  padding: 12px 16px;
  background: #fafafa;
  border-radius: 8px;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 6px;
  color: #606266;
  font-size: 14px;
}

.stat-num {
  font-weight: 600;
  color: #303133;
}

.stat-label {
  color: #909399;
  font-size: 12px;
}

/* 文章封面 */
.article-cover {
  width: 100%;
  max-height: 480px;
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 24px;
}

.cover-error {
  width: 100%;
  height: 300px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  color: #c0c4cc;
  gap: 8px;
}

/* 文章摘要 */
.article-summary {
  background: #fdf6ec;
  border-left: 4px solid #e6a23c;
  padding: 16px 20px;
  border-radius: 4px;
  margin-bottom: 24px;
  color: #5d4500;
  font-size: 15px;
  line-height: 1.8;
  display: flex;
  align-items: flex-start;
  gap: 10px;
}

.summary-icon {
  color: #e6a23c;
  font-size: 18px;
  flex-shrink: 0;
  margin-top: 2px;
}

/* 文章正文 */
.article-content {
  line-height: 2;
  font-size: 16px;
  color: #303133;
  word-break: break-word;
}

/* 正文内部元素样式 */
.article-content :deep(h1),
.article-content :deep(h2),
.article-content :deep(h3) {
  font-weight: 600;
  margin: 24px 0 16px;
  color: #303133;
}

.article-content :deep(h1) { font-size: 24px; }
.article-content :deep(h2) { font-size: 20px; }
.article-content :deep(h3) { font-size: 18px; }

.article-content :deep(p) {
  margin: 12px 0;
}

.article-content :deep(img) {
  max-width: 100%;
  border-radius: 8px;
  margin: 16px 0;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

.article-content :deep(blockquote) {
  border-left: 4px solid #409eff;
  background: #ecf5ff;
  padding: 12px 20px;
  margin: 16px 0;
  border-radius: 4px;
  color: #5d6c7b;
}

.article-content :deep(code) {
  background: #f5f7fa;
  padding: 2px 6px;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  color: #e6a23c;
  font-size: 0.9em;
}

.article-content :deep(pre) {
  background: #2d3748;
  color: #fff;
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
  margin: 16px 0;
}

.article-content :deep(pre code) {
  background: transparent;
  color: #fff;
  padding: 0;
}

.article-content :deep(ul),
.article-content :deep(ol) {
  margin: 12px 0;
  padding-left: 24px;
}

.article-content :deep(li) {
  margin: 6px 0;
}

/* 空内容提示 */
.empty-content {
  text-align: center;
  color: #c0c4cc;
  padding: 60px 0;
  font-style: italic;
}

/* 关键词标签 */
.article-keywords {
  margin: 24px 0;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  color: #909399;
  font-size: 14px;
}

.keyword-tag {
  margin: 0;
}

/* 分割线 */
.divider-text {
  margin-left: 6px;
  color: #909399;
  font-size: 13px;
}

/* 底部操作按钮 */
.article-actions {
  text-align: center;
  margin-top: 24px;
  display: flex;
  justify-content: center;
  gap: 12px;
  flex-wrap: wrap;
}

/* 评论区卡片 */
.comment-card {
  border-radius: 12px;
  border: none;
}

.comment-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.title {
  font-size: 16px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 6px;
}
</style>
