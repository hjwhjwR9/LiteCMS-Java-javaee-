<template>
  <!-- 登录页面主容器 -->
  <div class="login-page">
    <!-- 左侧品牌展示区 -->
    <div class="brand-section">
      <div class="brand-content">
        <!-- 品牌Logo -->
        <div class="brand-logo">
          <el-icon :size="56" color="#fff"><Promotion /></el-icon>
        </div>
        <!-- 品牌标题 -->
        <h1 class="brand-title">CMS 内容管理系统</h1>
        <!-- 品牌副标题 -->
        <p class="brand-subtitle">高效、专业的新闻内容管理平台</p>
        <!-- 功能特性列表 -->
        <ul class="brand-features">
          <li><el-icon><Check /></el-icon> 智能内容审核工作流</li>
          <li><el-icon><Check /></el-icon> 灵活的多栏目管理</li>
          <li><el-icon><Check /></el-icon> 完善的用户权限体系</li>
          <li><el-icon><Check /></el-icon> 实时的数据统计分析</li>
        </ul>
      </div>
      <!-- 装饰性背景元素 -->
      <div class="brand-decoration">
        <div class="deco-circle circle-1"></div>
        <div class="deco-circle circle-2"></div>
        <div class="deco-circle circle-3"></div>
      </div>
    </div>

    <!-- 右侧登录表单区 -->
    <div class="form-section">
      <el-card class="login-card" shadow="always">
        <!-- 表单头部 -->
        <div class="form-header">
          <h2 class="form-title">欢迎登录</h2>
          <p class="form-tip">请输入您的账号信息</p>
        </div>

        <!-- 登录表单 -->
        <el-form
          :model="loginForm"
          :rules="rules"
          ref="formRef"
          class="login-form"
          size="large"
        >
          <!-- 用户名输入框 -->
          <el-form-item prop="username">
            <el-input
              v-model="loginForm.username"
              placeholder="请输入用户名"
              prefix-icon="User"
              clearable
            />
          </el-form-item>
          <!-- 密码输入框 -->
          <el-form-item prop="password">
            <el-input
              v-model="loginForm.password"
              type="password"
              placeholder="请输入密码"
              prefix-icon="Lock"
              show-password
              @keyup.enter="handleLogin"
            />
          </el-form-item>
          <!-- 记住用户名和忘记密码 -->
          <el-form-item>
            <div class="remember-forgot">
              <el-checkbox v-model="rememberMe">记住用户名</el-checkbox>
              <el-link type="primary" :underline="false">忘记密码？</el-link>
            </div>
          </el-form-item>
          <!-- 登录按钮 -->
          <el-form-item>
            <el-button
              type="primary"
              @click="handleLogin"
              class="login-btn"
              :loading="loading"
              size="large"
            >
              <el-icon v-if="!loading"><Right /></el-icon>
              {{ loading ? '登录中...' : '登 录' }}
            </el-button>
          </el-form-item>
        </el-form>

        <!-- 测试账号分割线 -->
        <el-divider>测试账号</el-divider>

        <!-- 快捷登录标签 -->
        <div class="quick-accounts">
          <el-tag
            v-for="acc in quickAccounts"
            :key="acc.username"
            :type="acc.type"
            effect="plain"
            class="account-tag"
            @click="quickLogin(acc)"
          >
            {{ acc.label }}: {{ acc.username }} / {{ acc.password }}
          </el-tag>
        </div>

        <!-- 页脚版权信息 -->
        <div class="login-footer">
          <span>© 2026 CMS内容管理系统 · All Rights Reserved</span>
        </div>
      </el-card>
    </div>
  </div>
</template>

<script setup>
/**
 * 登录页面组件
 * 负责用户登录验证、Token存储、记住用户名功能
 * 包含快捷登录测试账号功能
 */
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { userApi } from '../api'
import { setUserInfo } from '../utils/auth'

// 路由实例
const router = useRouter()
// 表单引用
const formRef = ref(null)
// 登录按钮loading状态
const loading = ref(false)

// 登录表单数据
const loginForm = ref({
  username: '',  // 用户名
  password: ''   // 密码
})

// 记住用户名开关
const rememberMe = ref(false)

// 测试账号列表（快速登录用）
const quickAccounts = [
  { label: '管理员', username: 'admin', password: '123456', type: 'danger' },
  { label: '审核员', username: 'auditor', password: '123456', type: 'warning' },
  { label: '编辑', username: 'user01', password: '123456', type: 'success' }
]

// 表单校验规则
const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 2, max: 20, message: '用户名长度在 2 到 20 个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度在 6 到 20 个字符', trigger: 'blur' }
  ]
}

/**
 * 处理登录逻辑
 * 流程：表单校验 → 调用登录接口 → 存储Token → 获取用户信息 → 跳转首页
 */
const handleLogin = async () => {
  // 表单校验
  await formRef.value.validate()
  // 设置loading状态
  loading.value = true
  try {
    // 调用登录接口，获取Token
    const token = await userApi.login(loginForm.value)

    // 存储Token到localStorage
    localStorage.setItem('token', token)
    localStorage.setItem('isLogin', 'true')
    localStorage.setItem('username', loginForm.value.username)

    // 获取用户详细信息
    const userInfo = await userApi.info()
    setUserInfo(userInfo)
    localStorage.setItem('nickname', userInfo.nickname || loginForm.value.username)

    // 处理记住用户名功能
    if (rememberMe.value) {
      localStorage.setItem('rememberMe', 'true')
      localStorage.setItem('savedUsername', loginForm.value.username)
    } else {
      localStorage.removeItem('rememberMe')
      localStorage.removeItem('savedUsername')
    }

    // 登录成功提示并跳转首页
    ElMessage.success('登录成功！')
    router.push('/home')
  } catch (err) {
    // 登录失败，错误信息由api拦截器统一处理
  } finally {
    // 无论成功失败，都关闭loading状态
    loading.value = false
  }
}

/**
 * 快捷登录函数
 * 填充测试账号信息并触发登录
 * @param {Object} acc - 测试账号对象
 */
const quickLogin = (acc) => {
  loginForm.value.username = acc.username
  loginForm.value.password = acc.password
  handleLogin()
}

/**
 * 页面挂载时执行
 * 检查是否已登录，已登录则跳转首页
 * 检查是否有记住用户名，有则自动填充
 */
onMounted(() => {
  // 如果已有Token，说明已登录，直接跳转首页
  if (localStorage.getItem('token')) {
    router.push('/home')
    return
  }
  // 如果开启了记住用户名，自动填充用户名
  if (localStorage.getItem('rememberMe') === 'true') {
    const savedUsername = localStorage.getItem('savedUsername')
    if (savedUsername) {
      loginForm.value.username = savedUsername
      rememberMe.value = true
    }
  }
})
</script>

<style scoped>
/* 登录页面整体布局 */
.login-page {
  width: 100vw;
  height: 100vh;
  display: flex;
  background: #f0f2f5;
  overflow: hidden;
}

/* 左侧品牌区 */
.brand-section {
  flex: 1;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  overflow: hidden;
}

.brand-content {
  position: relative;
  z-index: 2;
  text-align: center;
  padding: 60px;
  max-width: 500px;
}

.brand-logo {
  width: 96px;
  height: 96px;
  margin: 0 auto 24px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  backdrop-filter: blur(10px);
}

.brand-title {
  font-size: 36px;
  font-weight: 700;
  margin: 0 0 12px;
  letter-spacing: 1px;
}

.brand-subtitle {
  font-size: 16px;
  opacity: 0.9;
  margin: 0 0 40px;
}

.brand-features {
  list-style: none;
  padding: 0;
  margin: 0;
  text-align: left;
}

.brand-features li {
  padding: 10px 0;
  font-size: 15px;
  display: flex;
  align-items: center;
  gap: 10px;
  opacity: 0.95;
}

/* 装饰背景元素 */
.brand-decoration {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.deco-circle {
  position: absolute;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.1);
}

.circle-1 {
  width: 400px;
  height: 400px;
  top: -100px;
  right: -100px;
  animation: float 6s ease-in-out infinite;
}

.circle-2 {
  width: 300px;
  height: 300px;
  bottom: -50px;
  left: -50px;
  animation: float 8s ease-in-out infinite;
}

.circle-3 {
  width: 200px;
  height: 200px;
  top: 50%;
  right: 10%;
  animation: float 5s ease-in-out infinite;
}

/* 浮动动画 */
@keyframes float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-20px); }
}

/* 右侧表单区 */
.form-section {
  width: 480px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
}

.login-card {
  width: 100%;
  padding: 40px 32px;
  border-radius: 16px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.08);
  border: none;
}

.form-header {
  text-align: center;
  margin-bottom: 32px;
}

.form-title {
  font-size: 26px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 8px;
}

.form-tip {
  color: #909399;
  font-size: 14px;
  margin: 0;
}

.login-form {
  margin-top: 1rem;
}

.remember-forgot {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.login-btn {
  width: 100%;
  height: 48px;
  font-size: 16px;
  font-weight: 600;
  border-radius: 8px;
  letter-spacing: 4px;
}

.quick-accounts {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 16px 0;
}

.account-tag {
  cursor: pointer;
  padding: 8px 12px;
  font-size: 13px;
  transition: all 0.2s;
}

.account-tag:hover {
  transform: translateY(-1px);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.login-footer {
  text-align: center;
  color: #c0c4cc;
  font-size: 12px;
  margin-top: 24px;
}

/* 响应式：移动端隐藏左侧品牌区 */
@media (max-width: 900px) {
  .brand-section { display: none; }
  .form-section { width: 100%; padding: 20px; }
}
</style>
