<template>
  <!-- 栏目管理页面容器 -->
  <el-card shadow="never" class="category-manage-container">
    <!-- 卡片头部 -->
    <template #header>
      <div class="card-header">
        <!-- 左侧标题区 -->
        <div class="header-left">
          <el-icon class="header-icon"><Grid /></el-icon>
          <span class="title">栏目管理</span>
          <el-tag size="small" type="info" effect="plain">共 {{ allCategories.length }} 个</el-tag>
        </div>
        <!-- 新增栏目按钮 -->
        <el-button type="primary" @click="openDialog">
          <el-icon><Plus /></el-icon> 新增栏目
        </el-button>
      </div>
    </template>

    <!-- 空状态提示（无栏目数据时显示） -->
    <el-empty v-if="categoryTree.length === 0" description="暂无栏目" />

    <!-- 栏目树组件 -->
    <el-tree
      v-else
      :data="categoryTree"
      :props="treeProps"
      node-key="id"
      default-expand-all
      class="category-tree"
      :render-after-expand="false"
    >
      <!-- 自定义树节点模板 -->
      <template #default="{ node, data }">
        <div class="tree-node">
          <!-- 节点左侧（图标和名称） -->
          <div class="node-left">
            <!-- 文件夹图标（有子栏目显示关闭状态，无子栏目显示打开状态） -->
            <el-icon class="node-icon" :color="data.children?.length ? '#409eff' : '#909399'">
              <component :is="data.children?.length ? 'Folder' : 'FolderOpened'" />
            </el-icon>
            <!-- 栏目名称 -->
            <span class="node-name">{{ data.name }}</span>
            <!-- 子栏目数量标签 -->
            <el-tag v-if="data.children?.length" size="small" type="primary" effect="plain">
              {{ data.children.length }} 子栏目
            </el-tag>
          </div>
          <!-- 节点右侧操作按钮 -->
          <div class="node-actions">
            <el-button size="small" type="primary" link @click.stop="editCategory(data)">
              <el-icon><Edit /></el-icon> 编辑
            </el-button>
            <el-button size="small" type="success" link @click.stop="addChild(data)">
              <el-icon><Plus /></el-icon> 添加子栏目
            </el-button>
            <el-button size="small" type="danger" link @click.stop="deleteCategory(data.id)">
              <el-icon><Delete /></el-icon> 删除
            </el-button>
          </div>
        </div>
      </template>
    </el-tree>

    <!-- 栏目新增/编辑弹窗 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogTitle"
      width="500px"
      center
      destroy-on-close
    >
      <!-- 栏目表单 -->
      <el-form
        :model="categoryForm"
        :rules="formRules"
        ref="formRef"
        label-width="100px"
        label-position="right"
      >
        <!-- 栏目名称 -->
        <el-form-item label="栏目名称" prop="name">
          <el-input v-model="categoryForm.name" placeholder="请输入栏目名称" maxlength="20" show-word-limit />
        </el-form-item>
        <!-- 父栏目选择 -->
        <el-form-item label="父栏目" prop="parentId">
          <el-select
            v-model="categoryForm.parentId"
            clearable
            placeholder="选择父栏目（不选则为一级栏目）"
            style="width: 100%"
          >
            <el-option
              v-for="item in flatCategories"
              :key="item.id"
              :label="item.prefixName"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <!-- 排序值 -->
        <el-form-item label="排序值" prop="sortOrder">
          <el-input-number v-model="categoryForm.sortOrder" :min="0" :max="999" style="width: 100%" />
          <div class="form-tip">数字越小排序越靠前</div>
        </el-form-item>
        <!-- 状态开关（仅编辑时显示） -->
        <el-form-item label="状态" prop="status" v-if="categoryForm.id">
          <el-switch
            v-model="categoryForm.status"
            :active-value="1"
            :inactive-value="0"
            active-text="启用"
            inactive-text="禁用"
            inline-prompt
          />
        </el-form-item>
      </el-form>
      <!-- 弹窗底部按钮 -->
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveCategory">确定</el-button>
      </template>
    </el-dialog>
  </el-card>
</template>

<script setup>
/**
 * 栏目管理页面组件
 * 管理栏目层级结构，支持新增、编辑、删除栏目和添加子栏目功能
 * 使用el-tree组件展示栏目树，支持无限层级
 */
import { ref, onMounted, computed } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { categoryApi } from '../api'

// 所有栏目数据（扁平化）
const allCategories = ref([])
// 栏目树形数据
const categoryTree = ref([])
// 弹窗显示状态
const dialogVisible = ref(false)
// 弹窗标题
const dialogTitle = ref('新增栏目')
// 表单引用
const formRef = ref(null)
// 栏目表单数据
const categoryForm = ref({ id: null, name: '', parentId: null, sortOrder: 0, status: 1 })
// 树组件属性配置（指定children、label、value字段）
const treeProps = { children: 'children', label: 'name', value: 'id' }
// 表单验证规则
const formRules = {
  name: [{ required: true, message: '请输入栏目名称', trigger: 'blur' }],
  sortOrder: [{ required: true, message: '请输入排序值', trigger: 'blur' }]
}

/**
 * 扁平化栏目列表（计算属性）
 * 将树形结构转换为扁平列表，为每个栏目添加层级前缀（如：└─ 子栏目）
 * 用于父栏目选择下拉框显示层级关系
 */
const flatCategories = computed(() => {
  const result = []
  const walk = (items, level = 0) => {
    for (const item of items || []) {
      // 根据层级添加前缀标识
      const prefix = level > 0 ? '└─'.repeat(level) + ' ' : ''
      result.push({
        ...item,
        prefixName: prefix + item.name  // 带层级标识的名称
      })
      // 递归处理子栏目
      if (item.children && item.children.length) {
        walk(item.children, level + 1)
      }
    }
  }
  walk(categoryTree.value)
  return result
})

/**
 * 获取栏目列表
 * 同时获取树形结构和扁平化结构
 */
const getCategories = async () => {
  try {
    const data = await categoryApi.list()
    const list = data || []
    allCategories.value = flatten(list)  // 扁平化数据用于统计总数
    categoryTree.value = list            // 树形数据用于展示
  } catch (err) {
    console.error('获取栏目失败:', err)
  }
}

/**
 * 递归扁平化树形数据
 * @param {Array} list - 树形数据列表
 * @returns {Array} 扁平化后的列表
 */
const flatten = (list) => {
  const result = []
  const walk = (items) => {
    for (const item of items || []) {
      result.push(item)
      if (item.children && item.children.length) walk(item.children)
    }
  }
  walk(list)
  return result
}

/**
 * 打开新增栏目弹窗
 */
const openDialog = () => {
  // 重置表单数据
  categoryForm.value = { id: null, name: '', parentId: null, sortOrder: 0, status: 1 }
  dialogTitle.value = '新增栏目'
  dialogVisible.value = true
}

/**
 * 添加子栏目
 * @param {Object} data - 父栏目数据
 */
const addChild = (data) => {
  // 设置父栏目ID，其他字段重置
  categoryForm.value = { id: null, name: '', parentId: data.id, sortOrder: 0, status: 1 }
  dialogTitle.value = `为「${data.name}」添加子栏目`
  dialogVisible.value = true
}

/**
 * 编辑栏目
 * @param {Object} data - 栏目数据
 */
const editCategory = (data) => {
  // 填充表单数据
  categoryForm.value = {
    id: data.id,
    name: data.name,
    parentId: data.parentId || null,
    sortOrder: data.sortOrder ?? 0,
    status: data.status ?? 1
  }
  dialogTitle.value = '编辑栏目'
  dialogVisible.value = true
}

/**
 * 保存栏目（新增或编辑）
 */
const saveCategory = async () => {
  // 表单验证
  await formRef.value.validate()
  try {
    if (categoryForm.value.id) {
      // 编辑模式
      await categoryApi.update(categoryForm.value)
      ElMessage.success('编辑成功')
    } else {
      // 新增模式
      await categoryApi.add(categoryForm.value)
      ElMessage.success('新增成功')
    }
    // 关闭弹窗并刷新数据
    dialogVisible.value = false
    getCategories()
  } catch (err) {
    // 错误由拦截器处理
  }
}

/**
 * 删除栏目（带确认）
 * 删除父栏目时会级联删除所有子栏目
 * @param {number} id - 栏目ID
 */
const deleteCategory = async (id) => {
  try {
    await ElMessageBox.confirm('确定删除该栏目吗？子栏目也会被删除', '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await categoryApi.delete(id)
    ElMessage.success('删除成功')
    getCategories()
  } catch (err) {
    // 取消操作或请求失败由拦截器处理
  }
}

/**
 * 页面挂载时获取栏目列表
 */
onMounted(async () => {
  await getCategories()
})
</script>

<style scoped>
/* 页面容器 */
.category-manage-container {
  border-radius: 8px;
}

/* 卡片头部 */
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
}

.header-icon {
  font-size: 18px;
  color: #409eff;
}

.title {
  font-size: 16px;
  font-weight: 600;
}

/* 栏目树容器 */
.category-tree {
  padding: 8px;
  background: #fafafa;
  border-radius: 6px;
  border: 1px solid #ebeef5;
}

/* 树节点内容样式（深度选择器穿透） */
.category-tree :deep(.el-tree-node__content) {
  height: 44px;
  border-radius: 4px;
  transition: background 0.2s;
}

/* 树节点悬停效果 */
.category-tree :deep(.el-tree-node__content:hover) {
  background: #ecf5ff;
}

/* 自定义树节点 */
.tree-node {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding-right: 16px;
}

/* 节点左侧（图标和名称） */
.node-left {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  min-width: 0;
}

.node-icon {
  font-size: 16px;
}

.node-name {
  font-size: 14px;
  color: #303133;
  font-weight: 500;
}

/* 节点右侧操作按钮 */
.node-actions {
  display: flex;
  align-items: center;
  gap: 4px;
  opacity: 0.7;          /* 默认半透明 */
  transition: opacity 0.2s;
}

/* 悬停时显示完整操作按钮 */
.category-tree :deep(.el-tree-node__content:hover) .node-actions {
  opacity: 1;
}

/* 表单提示文字 */
.form-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}
</style>
