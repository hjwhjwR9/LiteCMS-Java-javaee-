<template>
  <!-- 新闻管理页面容器 -->
  <div class="news-manage-container">
    <el-card shadow="never" class="main-card">
      <!-- 卡片头部 -->
      <template #header>
        <div class="card-header">
          <!-- 左侧标题区 -->
          <div class="header-left">
            <el-icon class="header-icon"><Management /></el-icon>
            <span class="title">新闻管理</span>
            <el-tag size="small" type="info" effect="plain">{{ total }} 条</el-tag>
          </div>
          <!-- 发布新闻按钮 -->
          <el-button type="primary" @click="router.push('/news/publish')">
            <el-icon><Plus /></el-icon> 发布新闻
          </el-button>
        </div>
      </template>

      <!-- 统计卡片 -->
      <el-row :gutter="16" class="stat-row">
        <!-- 草稿统计 -->
        <el-col :span="6">
          <div class="stat-card stat-0" @click="quickFilter(0)">
            <el-icon class="stat-icon"><DocumentCopy /></el-icon>
            <div class="stat-content">
              <div class="stat-value">{{ stats.draft }}</div>
              <div class="stat-label">草稿</div>
            </div>
          </div>
        </el-col>
        <!-- 待审核统计 -->
        <el-col :span="6">
          <div class="stat-card stat-1" @click="quickFilter(1)">
            <el-icon class="stat-icon"><Clock /></el-icon>
            <div class="stat-content">
              <div class="stat-value">{{ stats.pending }}</div>
              <div class="stat-label">待审核</div>
            </div>
          </div>
        </el-col>
        <!-- 已发布统计 -->
        <el-col :span="6">
          <div class="stat-card stat-2" @click="quickFilter(2)">
            <el-icon class="stat-icon"><CircleCheck /></el-icon>
            <div class="stat-content">
              <div class="stat-value">{{ stats.published }}</div>
              <div class="stat-label">已发布</div>
            </div>
          </div>
        </el-col>
        <!-- 已驳回统计 -->
        <el-col :span="6">
          <div class="stat-card stat-3" @click="quickFilter(3)">
            <el-icon class="stat-icon"><CircleClose /></el-icon>
            <div class="stat-content">
              <div class="stat-value">{{ stats.rejected }}</div>
              <div class="stat-label">已驳回</div>
            </div>
          </div>
        </el-col>
      </el-row>

      <!-- 筛选条件 -->
      <div class="filter-bar">
        <!-- 搜索输入框 -->
        <el-input
          v-model="searchKeyword"
          placeholder="搜索新闻标题"
          prefix-icon="Search"
          style="width: 220px; margin-right: 12px"
          clearable
          @clear="handleFilterChange"
          @keyup.enter="handleFilterChange"
        />
        <!-- 状态筛选 -->
        <el-select v-model="filterStatus" placeholder="状态筛选" clearable style="width: 120px; margin-right: 12px" @change="handleFilterChange">
          <el-option label="草稿" :value="0" />
          <el-option label="待审核" :value="1" />
          <el-option label="已发布" :value="2" />
          <el-option label="已驳回" :value="3" />
          <el-option label="已下架" :value="4" />
        </el-select>
        <!-- 栏目筛选 -->
        <el-select v-model="filterCategory" placeholder="栏目筛选" clearable style="width: 150px; margin-right: 12px" @change="handleFilterChange">
          <el-option v-for="cat in categories" :key="cat.id" :label="cat.name" :value="cat.id" />
        </el-select>
        <!-- 重置按钮 -->
        <el-button @click="handleReset">
          <el-icon><RefreshLeft /></el-icon> 重置
        </el-button>
        <!-- 已选数量提示 -->
        <span class="filter-tip">已选 <b>{{ selectedIds.length }}</b> 项</span>
      </div>

      <!-- 批量操作工具栏（选择后显示） -->
      <div class="table-toolbar" v-if="selectedIds.length > 0">
        <el-button type="success" @click="handleBatchPublish">批量提交审核</el-button>
        <el-button type="warning" @click="handleBatchOffline">批量下架</el-button>
        <el-button type="danger" @click="handleBatchDelete">批量删除</el-button>
      </div>

      <!-- 新闻列表表格 -->
      <el-table
        :data="newsList"
        v-loading="loading"
        stripe
        border
        :max-height="tableHeight"
        @selection-change="handleSelectionChange"
      >
        <!-- 多选列 -->
        <el-table-column type="selection" width="50" />
        <!-- 序号列 -->
        <el-table-column type="index" label="#" width="55" align="center" />
        <!-- 封面列 -->
        <el-table-column label="封面" width="100" align="center">
          <template #default="{ row }">
            <el-image
              :src="row.coverUrl || getPlaceholder(row.id)"
              fit="cover"
              style="width: 80px; height: 50px; border-radius: 4px"
              :preview-src-list="row.coverUrl ? [row.coverUrl] : []"
              preview-teleported
            >
              <template #error>
                <div class="image-placeholder">
                  <el-icon><Picture /></el-icon>
                </div>
              </template>
            </el-image>
          </template>
        </el-table-column>
        <!-- 标题列 -->
        <el-table-column prop="title" label="标题" min-width="220" show-overflow-tooltip>
          <template #default="{ row }">
            <span class="news-title" @click="handleView(row)">{{ row.title }}</span>
            <el-tag v-if="row.isTop" size="small" type="danger" class="ml-2" effect="dark">置顶</el-tag>
            <el-tag v-if="row.isHot" size="small" type="warning" class="ml-2" effect="dark">热门</el-tag>
          </template>
        </el-table-column>
        <!-- 栏目列 -->
        <el-table-column prop="categoryName" label="栏目" width="110" align="center">
          <template #default="{ row }">
            <el-tag v-if="row.categoryName" size="small" effect="plain">{{ row.categoryName }}</el-tag>
            <span v-else>-</span>
          </template>
        </el-table-column>
        <!-- 状态列 -->
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)" size="small">{{ getStatusText(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <!-- 数据统计列 -->
        <el-table-column label="数据" width="170" align="center">
          <template #default="{ row }">
            <div class="data-cell">
              <span class="data-item"><el-icon><View /></el-icon> {{ row.viewCount || 0 }}</span>
              <span class="data-item"><el-icon><Star /></el-icon> {{ row.likeCount || 0 }}</span>
              <span class="data-item"><el-icon><ChatDotRound /></el-icon> {{ row.commentCount || 0 }}</span>
            </div>
          </template>
        </el-table-column>
        <!-- 创建时间列 -->
        <el-table-column prop="createdAt" label="创建时间" width="170" align="center">
          <template #default="{ row }">
            <span class="time-text">{{ formatTime(row.createdAt) }}</span>
          </template>
        </el-table-column>
        <!-- 操作列 -->
        <el-table-column label="操作" width="240" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" type="primary" link @click="handleView(row)">查看</el-button>
            <el-button size="small" type="success" link @click="handleEdit(row)">编辑</el-button>
            <el-button size="small" type="warning" link @click="handlePublish(row)" v-if="row.status === 0 || row.status === 3">提交审核</el-button>
            <el-button size="small" type="info" link @click="handleOffline(row)" v-if="row.status === 2">下架</el-button>
            <el-button size="small" type="danger" link @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页组件 -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          background
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>

    <!-- 删除确认弹窗 -->
    <el-dialog v-model="deleteDialogVisible" title="确认删除" width="400px" center>
      <div class="delete-dialog">
        <el-icon class="warning-icon" :size="48" color="#f56c6c"><WarningFilled /></el-icon>
        <p class="delete-title">确定要删除新闻《{{ currentNews?.title }}》吗？</p>
        <p class="delete-tip">删除后无法恢复，相关评论也会一并删除</p>
      </div>
      <template #footer>
        <el-button @click="deleteDialogVisible = false">取消</el-button>
        <el-button type="danger" @click="confirmDelete">确认删除</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
/**
 * 新闻管理页面组件
 * 管理自己发布的新闻，支持发布、编辑、提交审核、下架、删除等操作
 * 包含统计卡片、批量操作、状态筛选等功能
 */
import { ref, computed, onMounted, onUnmounted, getCurrentInstance } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { format } from 'date-fns'

const { proxy } = getCurrentInstance()
const router = useRouter()

// 搜索关键词
const searchKeyword = ref('')
// 状态筛选
const filterStatus = ref('')
// 栏目筛选
const filterCategory = ref('')
// 加载状态
const loading = ref(false)
// 新闻列表数据
const newsList = ref([])
// 栏目列表
const categories = ref([])
// 当前页码
const currentPage = ref(1)
// 每页条数
const pageSize = ref(10)
// 总条数
const total = ref(0)
// 表格高度
const tableHeight = ref(500)

// 选中的行数据
const selectedRows = ref([])
// 选中的ID列表（计算属性）
const selectedIds = computed(() => selectedRows.value.map(r => r.id))

// 统计数据（草稿/待审核/已发布/已驳回）
const stats = ref({ draft: 0, pending: 0, published: 0, rejected: 0 })

// 删除弹窗显示状态
const deleteDialogVisible = ref(false)
// 当前待删除的新闻
const currentNews = ref(null)

/**
 * 更新表格高度（响应窗口大小变化）
 */
const updateTableHeight = () => {
  tableHeight.value = window.innerHeight - 380
}

// 状态映射表
const statusMap = { 0: '草稿', 1: '待审核', 2: '已发布', 3: '已驳回', 4: '已下架' }
const statusTypeMap = { 0: 'info', 1: 'warning', 2: 'success', 3: 'danger', 4: 'warning' }

/**
 * 获取状态文本
 * @param {number} status - 状态码
 * @returns {string} 状态名称
 */
const getStatusText = (status) => statusMap[status] || '未知'

/**
 * 获取状态对应的标签类型
 * @param {number} status - 状态码
 * @returns {string} Element Plus标签类型
 */
const getStatusType = (status) => statusTypeMap[status] || 'info'

/**
 * 获取图片占位图（无封面时使用）
 * @param {number} id - 新闻ID
 * @returns {string} 占位图URL
 */
const getPlaceholder = (id) => `https://picsum.photos/seed/news${id}/80/50`

/**
 * 格式化时间
 * @param {string} time - ISO时间字符串
 * @returns {string} 格式化后的时间
 */
const formatTime = (time) => {
  return time ? format(new Date(time), 'yyyy-MM-dd HH:mm') : '-'
}

/**
 * 获取栏目列表
 */
const getCategories = async () => {
  try {
    const data = await proxy.$api.category.list()
    categories.value = data || []
  } catch (err) {
    console.error('获取栏目失败:', err)
  }
}

/**
 * 计算统计数据（从新闻列表中统计各状态数量）
 */
const calculateStats = () => {
  const s = { draft: 0, pending: 0, published: 0, rejected: 0 }
  newsList.value.forEach(item => {
    if (item.status === 0) s.draft++
    else if (item.status === 1) s.pending++
    else if (item.status === 2) s.published++
    else if (item.status === 3) s.rejected++
  })
  stats.value = s
}

/**
 * 获取新闻列表（只获取当前用户发布的新闻）
 */
const getNewsList = async () => {
  loading.value = true
  try {
    const params = {
      pageNum: currentPage.value,
      pageSize: pageSize.value
    }
    if (searchKeyword.value) params.keyword = searchKeyword.value
    if (filterStatus.value !== '' && filterStatus.value !== null) params.status = filterStatus.value
    if (filterCategory.value) params.categoryId = filterCategory.value

    const result = await proxy.$api.article.myList(params)
    const pageResult = result || {}
    newsList.value = pageResult.records || []
    total.value = pageResult.total || 0
    calculateStats()
  } catch (err) {
    console.error('获取新闻列表失败:', err)
  } finally {
    loading.value = false
  }
}

/**
 * 处理筛选条件变化
 */
const handleFilterChange = () => {
  currentPage.value = 1
  getNewsList()
}

/**
 * 重置筛选条件
 */
const handleReset = () => {
  searchKeyword.value = ''
  filterStatus.value = ''
  filterCategory.value = ''
  currentPage.value = 1
  getNewsList()
}

/**
 * 快速筛选（点击统计卡片）
 * @param {number} status - 状态码
 */
const quickFilter = (status) => {
  filterStatus.value = status
  currentPage.value = 1
  getNewsList()
}

/**
 * 处理页码变化
 * @param {number} page - 新页码
 */
const handlePageChange = (page) => {
  currentPage.value = page
  getNewsList()
}

/**
 * 处理每页条数变化
 * @param {number} size - 新的每页条数
 */
const handleSizeChange = (size) => {
  pageSize.value = size
  currentPage.value = 1
  getNewsList()
}

/**
 * 处理表格选择变化
 * @param {Array} rows - 选中的行数据
 */
const handleSelectionChange = (rows) => {
  selectedRows.value = rows
}

/**
 * 查看新闻详情
 * @param {Object} row - 新闻数据
 */
const handleView = (row) => {
  router.push(`/article/${row.id}`)
}

/**
 * 编辑新闻
 * @param {Object} row - 新闻数据
 */
const handleEdit = (row) => {
  router.push(`/article/edit/${row.id}`)
}

/**
 * 提交审核（草稿/驳回状态才能提交）
 * @param {Object} row - 新闻数据
 */
const handlePublish = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要提交新闻《${row.title}》进行审核吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'info'
    })
    await proxy.$api.article.update({ ...row, status: 1 })
    ElMessage.success('提交成功，请等待审核')
    getNewsList()
  } catch (err) {
    if (err !== 'cancel') console.error('提交失败:', err)
  }
}

/**
 * 下架新闻（已发布状态才能下架）
 * @param {Object} row - 新闻数据
 */
const handleOffline = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要下架新闻《${row.title}》吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await proxy.$api.article.update({ ...row, status: 4 })
    ElMessage.success('下架成功')
    getNewsList()
  } catch (err) {
    if (err !== 'cancel') console.error('下架失败:', err)
  }
}

/**
 * 打开删除确认弹窗
 * @param {Object} row - 新闻数据
 */
const handleDelete = (row) => {
  currentNews.value = row
  deleteDialogVisible.value = true
}

/**
 * 确认删除新闻
 */
const confirmDelete = async () => {
  try {
    await proxy.$api.article.delete(currentNews.value.id)
    ElMessage.success('删除成功')
    deleteDialogVisible.value = false
    getNewsList()
  } catch (err) {
    console.error('删除失败:', err)
  }
}

/**
 * 批量提交审核
 */
const handleBatchPublish = async () => {
  try {
    await ElMessageBox.confirm(`确定要批量提交 ${selectedIds.value.length} 条新闻进行审核吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'info'
    })
    await Promise.all(selectedRows.value.map(row =>
      proxy.$api.article.update({ ...row, status: 1 })
    ))
    ElMessage.success('批量提交成功')
    getNewsList()
  } catch (err) {
    if (err !== 'cancel') console.error('批量提交失败:', err)
  }
}

/**
 * 批量下架
 */
const handleBatchOffline = async () => {
  try {
    await ElMessageBox.confirm(`确定要批量下架 ${selectedIds.value.length} 条新闻吗？`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await Promise.all(selectedRows.value.map(row =>
      proxy.$api.article.update({ ...row, status: 4 })
    ))
    ElMessage.success('批量下架成功')
    getNewsList()
  } catch (err) {
    if (err !== 'cancel') console.error('批量下架失败:', err)
  }
}

/**
 * 批量删除
 */
const handleBatchDelete = async () => {
  try {
    await ElMessageBox.confirm(`确定要批量删除 ${selectedIds.value.length} 条新闻吗？此操作不可恢复！`, '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'error'
    })
    await Promise.all(selectedIds.value.map(id => proxy.$api.article.delete(id)))
    ElMessage.success('批量删除成功')
    getNewsList()
  } catch (err) {
    if (err !== 'cancel') console.error('批量删除失败:', err)
  }
}

/**
 * 页面挂载时执行
 */
onMounted(async () => {
  updateTableHeight()
  window.addEventListener('resize', updateTableHeight)
  await Promise.all([getCategories(), getNewsList()])
})

/**
 * 页面卸载时清理
 */
onUnmounted(() => {
  window.removeEventListener('resize', updateTableHeight)
})
</script>

<style scoped>
.news-manage-container {
  padding: 0;
}

.main-card {
  border-radius: 8px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
}

.header-icon {
  font-size: 18px;
  color: #409eff;
}

.title {
  font-size: 16px;
  font-weight: 600;
}

/* 统计卡片 */
.stat-row {
  margin-bottom: 20px;
}

.stat-card {
  display: flex;
  align-items: center;
  padding: 16px 20px;
  background: #fff;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  border: 1px solid #ebeef5;
}

.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.stat-icon {
  font-size: 32px;
  margin-right: 16px;
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
}

.stat-0 .stat-icon { background: #f4f4f5; color: #909399; }
.stat-1 .stat-icon { background: #fdf6ec; color: #e6a23c; }
.stat-2 .stat-icon { background: #f0f9eb; color: #67c23a; }
.stat-3 .stat-icon { background: #fef0f0; color: #f56c6c; }

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-label {
  font-size: 13px;
  color: #909399;
  margin-top: 4px;
}

/* 筛选 */
.filter-bar {
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
}

.filter-tip {
  margin-left: 8px;
  color: #909399;
  font-size: 13px;
}

.filter-tip b {
  color: #409eff;
  font-weight: 600;
}

/* 工具栏 */
.table-toolbar {
  margin-bottom: 12px;
  padding: 12px 16px;
  background: #ecf5ff;
  border-radius: 6px;
  display: flex;
  align-items: center;
  gap: 10px;
}

.news-title {
  cursor: pointer;
  color: #303133;
  font-weight: 500;
  transition: color 0.2s;
}

.news-title:hover {
  color: #409eff;
}

.data-cell {
  display: flex;
  justify-content: center;
  gap: 10px;
}

.data-item {
  display: flex;
  align-items: center;
  gap: 3px;
  font-size: 12px;
  color: #606266;
}

.time-text {
  color: #606266;
  font-size: 13px;
}

.pagination-wrapper {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.image-placeholder {
  width: 80px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  border-radius: 4px;
  color: #c0c4cc;
}

.ml-2 {
  margin-left: 8px;
}

.delete-dialog {
  text-align: center;
  padding: 20px 0;
}

.warning-icon {
  margin-bottom: 16px;
}

.delete-title {
  font-size: 16px;
  color: #303133;
  margin: 0 0 8px;
}

.delete-tip {
  font-size: 13px;
  color: #909399;
  margin: 0;
}
</style>
